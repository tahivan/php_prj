-- NUKEVIET 3.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: localhost
-- Generation Time: December 20, 2014, 08:35 AM GMT
-- Server version: 5.6.22
-- PHP Version: 5.3.29

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8';
SET SESSION `character_set_results`='utf8';
SET SESSION `character_set_connection`='utf8';
SET SESSION `collation_connection`='utf8_general_ci';
SET NAMES 'utf8';
ALTER DATABASE DEFAULT CHARACTER SET `utf8` COLLATE `utf8_general_ci`;

--
-- Database: `levietpr_web`
--


-- ---------------------------------------


--
-- Table structure for table `vt_authors`
--

DROP TABLE IF EXISTS `vt_authors`;
CREATE TABLE `vt_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100) NOT NULL,
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` mediumtext NOT NULL,
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_authors`
--

INSERT INTO `vt_authors` VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', '9966ae1fe6a59a42602ad5a02df6158b697534cb', 1418956546, '117.7.237.94', 'Mozilla/5.0 (Windows NT 6.1; rv:34.0) Gecko/20100101 Firefox/34.0 AlexaToolbar/alxf-2.21');


-- ---------------------------------------


--
-- Table structure for table `vt_authors_config`
--

DROP TABLE IF EXISTS `vt_authors_config`;
CREATE TABLE `vt_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_banip`
--

DROP TABLE IF EXISTS `vt_banip`;
CREATE TABLE `vt_banip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_banners_click`
--

DROP TABLE IF EXISTS `vt_banners_click`;
CREATE TABLE `vt_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15) NOT NULL,
  `click_country` varchar(10) NOT NULL,
  `click_browse_key` varchar(100) NOT NULL,
  `click_browse_name` varchar(100) NOT NULL,
  `click_os_key` varchar(100) NOT NULL,
  `click_os_name` varchar(100) NOT NULL,
  `click_ref` varchar(255) NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_banners_click`
--

INSERT INTO `vt_banners_click` VALUES
(17, 1418289334, 0, '14.163.13.135', 'VN', '', 'Mobile', '', 'Linux', 'http://levietpro.com/demo/dulich/'), 
(16, 1418441527, 0, '113.167.157.229', 'VN', '', 'firefox', '', 'Windows 7', 'http://levietpro.com/demo/dulich/vi/');


-- ---------------------------------------


--
-- Table structure for table `vt_banners_clients`
--

DROP TABLE IF EXISTS `vt_banners_clients`;
CREATE TABLE `vt_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  `uploadtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_banners_plans`
--

DROP TABLE IF EXISTS `vt_banners_plans`;
CREATE TABLE `vt_banners_plans` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `form` varchar(100) NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_banners_plans`
--

INSERT INTO `vt_banners_plans` VALUES
(2, '', 'Slide home', '', 'sequential', 750, 350, 1), 
(3, '', 'banner-home', '', 'sequential', 1200, 300, 1);


-- ---------------------------------------


--
-- Table structure for table `vt_banners_rows`
--

DROP TABLE IF EXISTS `vt_banners_rows`;
CREATE TABLE `vt_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255) NOT NULL,
  `file_ext` varchar(100) NOT NULL,
  `file_mime` varchar(100) NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255) NOT NULL,
  `click_url` varchar(255) NOT NULL,
  `file_name_tmp` varchar(255) NOT NULL,
  `file_alt_tmp` varchar(255) NOT NULL,
  `click_url_tmp` varchar(255) NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=21  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_banners_rows`
--

INSERT INTO `vt_banners_rows` VALUES
(18, 'Du lịch Nhật Bản', 2, 0, 'banner_2.jpg', 'jpg', 'image/jpeg', 1000, 360, '', '', '', '', '', 1418186805, 1418186805, 0, 0, 1, 3), 
(19, 'Du lịch biển', 2, 0, '1342955525du-lich-bai-bien.jpg', 'jpg', 'image/jpeg', 956, 370, '', '', '', '', '', 1418186825, 1418186825, 0, 0, 1, 2), 
(20, 'Du lịch Vòng quanh thế giới', 2, 0, 'images_1.jpg', 'jpg', 'image/jpeg', 1280, 600, '', '', '', '', '', 1418186856, 1418186856, 0, 0, 1, 1), 
(7, 'test', 2, 0, 'banner.jpg', 'jpg', 'image/jpeg', 958, 369, '', '', '', '', '', 1418012869, 1418012869, 0, 0, 1, 4), 
(12, 'Du lịch châu Âu', 3, 0, 'banner-du-lich-chau-au_itour-travel.jpg', 'jpg', 'image/jpeg', 1200, 356, '', '', '', '', '', 1418131422, 1418131422, 0, 0, 1, 6), 
(13, 'Du lịch Phú Quốc', 3, 0, 'banner-salinda-2-07.png', 'png', 'image/png', 1200, 267, '', '', '', '', '', 1418131447, 1418131447, 0, 0, 1, 5), 
(14, 'Du lịch biển', 3, 0, 'banner7.png', 'png', 'image/png', 1200, 241, '', '', '', '', '', 1418131480, 1418131480, 0, 0, 1, 4), 
(15, 'Du lịch Đà Nẵng', 3, 0, 'da-nang-giau-dep-van-minh-87e29.jpg', 'jpg', 'image/jpeg', 1200, 559, '', '', '', '', '', 1418131518, 1418131518, 0, 0, 1, 3), 
(16, 'Du lịch Hạ Long', 3, 0, 'banner-02-1080x349.jpg', 'jpg', 'image/jpeg', 1080, 349, '', 'http://levietpro.com', '', '', '', 1418131552, 1418131552, 0, 1, 1, 2), 
(17, 'Du lịch Sapa', 3, 0, 'sapa7.jpg', 'jpg', 'image/jpeg', 956, 291, '', 'http://levietpro.com', '', '', '', 1418131581, 1418131581, 0, 1, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `vt_config`
--

DROP TABLE IF EXISTS `vt_config`;
CREATE TABLE `vt_config` (
  `lang` char(3) NOT NULL DEFAULT 'sys',
  `module` varchar(25) NOT NULL DEFAULT 'global',
  `config_name` varchar(30) NOT NULL DEFAULT '',
  `config_value` mediumtext NOT NULL,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_config`
--

INSERT INTO `vt_config` VALUES
('sys', 'global', 'closed_site', '0'), 
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'), 
('sys', 'global', 'site_phone', ''), 
('sys', 'global', 'site_lang', 'vi'), 
('sys', 'global', 'admin_theme', 'admin_full'), 
('sys', 'global', 'date_pattern', 'l, d-m-Y'), 
('sys', 'global', 'time_pattern', 'H&#x3A;i'), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'online_upd', '1'), 
('sys', 'global', 'statistic', '1'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'gfx_chk', '3'), 
('sys', 'global', 'file_allowed_ext', 'adobe,archives,audio,documents,flash,images,real,video'), 
('sys', 'global', 'forbid_extensions', 'php,php3,php4,php5,phtml,inc'), 
('sys', 'global', 'forbid_mimes', ''), 
('sys', 'global', 'nv_max_size', '2684354'), 
('sys', 'global', 'upload_checking_mode', 'strong'), 
('sys', 'global', 'upload_logo', 'images/logo.png'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'getloadavg', '0'), 
('sys', 'global', 'mailer_mode', ''), 
('sys', 'global', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'global', 'smtp_ssl', '1'), 
('sys', 'global', 'smtp_port', '465'), 
('sys', 'global', 'smtp_username', 'user@gmail.com'), 
('sys', 'global', 'smtp_password', 'userpass'), 
('sys', 'global', 'allowuserreg', '1'), 
('sys', 'global', 'allowuserlogin', '1'), 
('sys', 'global', 'allowloginchange', '0'), 
('sys', 'global', 'allowquestion', '1'), 
('sys', 'global', 'allowuserpublic', '0'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allowmailchange', '1'), 
('sys', 'global', 'allow_sitelangs', 'vi'), 
('sys', 'global', 'allow_adminlangs', 'en,vi'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'is_url_rewrite', '1'), 
('sys', 'global', 'rewrite_optional', '0'), 
('sys', 'global', 'rewrite_endurl', '/'), 
('sys', 'global', 'rewrite_exturl', '.html'), 
('sys', 'global', 'autocheckupdate', '1'), 
('sys', 'global', 'autologomod', ''), 
('sys', 'global', 'autologosize1', '50'), 
('sys', 'global', 'autologosize2', '40'), 
('sys', 'global', 'autologosize3', '30'), 
('sys', 'global', 'autoupdatetime', '24'), 
('sys', 'global', 'gzip_method', '0'), 
('sys', 'global', 'is_user_forum', '0'), 
('sys', 'global', 'openid_mode', '1'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'openid_servers', 'yahoo,google,myopenid'), 
('sys', 'global', 'optActive', '0'), 
('sys', 'global', 'timestamp', '21'), 
('sys', 'global', 'googleAnalyticsID', ''), 
('sys', 'global', 'googleAnalyticsSetDomainName', '0'), 
('sys', 'global', 'searchEngineUniqueID', ''), 
('sys', 'global', 'captcha_type', '0'), 
('sys', 'global', 'revision', '1929'), 
('sys', 'global', 'version', '3.4.02'), 
('sys', 'global', 'whoviewuser', '2'), 
('vi', 'global', 'site_name', 'Việt Nam - Vẻ đẹp bất tận &#33;'), 
('vi', 'global', 'site_logo', 'images/logo.png'), 
('vi', 'global', 'site_description', 'Website Dịch Vụ Du Lịch'), 
('vi', 'global', 'site_keywords', ''), 
('vi', 'global', 'site_theme', 'default'), 
('vi', 'global', 'site_home_module', 'home'), 
('vi', 'global', 'switch_mobi_des', '1'), 
('vi', 'global', 'disable_site_content', 'Vì lý do kỹ thuật website tạm ngưng hoạt động. Thành thật xin lỗi các bạn vì sự bất tiện này!'), 
('vi', 'news', 'indexfile', 'viewcat_main_bottom'), 
('vi', 'news', 'per_page', '20'), 
('vi', 'news', 'st_links', '10'), 
('vi', 'news', 'auto_postcomm', '0'), 
('vi', 'news', 'homewidth', '150'), 
('vi', 'news', 'homeheight', '200'), 
('vi', 'news', 'blockwidth', '200'), 
('vi', 'news', 'blockheight', '229'), 
('vi', 'news', 'imagefull', '460'), 
('vi', 'news', 'setcomm', '1'), 
('vi', 'news', 'copyright', 'Chú ý&#x3A; Việc đăng lại bài viết trên ở website hoặc các phương tiện truyền thông khác mà không ghi rõ nguồn http&#x3A;&#x002F;&#x002F;nukeviet.vn là vi phạm bản quyền'), 
('vi', 'news', 'showhometext', '1'), 
('vi', 'news', 'activecomm', '1'), 
('vi', 'news', 'emailcomm', '0'), 
('vi', 'news', 'timecheckstatus', '0'), 
('vi', 'news', 'config_source', '0'), 
('sys', 'global', 'site_email', 'leviet.vnuahy@gmail.com'), 
('sys', 'global', 'error_send_email', 'leviet.vnuahy@gmail.com'), 
('sys', 'global', 'my_domains', 'levietpro.com'), 
('sys', 'global', 'cookie_prefix', 'nv3c_Ojclj'), 
('sys', 'global', 'session_prefix', 'nv3s_Hskmtm'), 
('sys', 'global', 'site_timezone', 'byCountry'), 
('sys', 'global', 'statistics_timezone', 'America/New_York'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'lang_multi', '1'), 
('sys', 'global', 'lang_geo', '0'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', ''), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0'), 
('vi', 'shops', 'per_row', '2'), 
('vi', 'shops', 'image_size', '100x100'), 
('vi', 'shops', 'auto_check_order', '1'), 
('vi', 'shops', 'per_page', '20'), 
('vi', 'shops', 'home_view', 'view_home_cat'), 
('vi', 'shops', 'format_order_id', 'S%06s'), 
('vi', 'shops', 'comment', '1'), 
('vi', 'shops', 'comment_auto', '0'), 
('vi', 'shops', 'who_comment', '0'), 
('vi', 'shops', 'groups_comment', ''), 
('vi', 'shops', 'money_unit', 'VND'), 
('vi', 'shops', 'post_auto_member', '0'), 
('vi', 'news', 'module_logo', 'images/logo.png'), 
('vi', 'news', 'structure_upload', 'Ym'), 
('vi', 'shops', 'format_code_id', 'S%06s'), 
('vi', 'shops', 'active_showhomtext', '1'), 
('vi', 'shops', 'active_order', '1'), 
('vi', 'shops', 'active_price', '1'), 
('vi', 'shops', 'active_order_number', '0'), 
('vi', 'shops', 'active_payment', '1'), 
('vi', 'shops', 'active_tooltip', '1'), 
('vi', 'shops', 'timecheckstatus', '0'), 
('vi', 'shops', 'show_product_code', '1'), 
('vi', 'shops', 'homewidth', '100'), 
('vi', 'shops', 'homeheight', '100');


-- ---------------------------------------


--
-- Table structure for table `vt_cronjobs`
--

DROP TABLE IF EXISTS `vt_cronjobs`;
CREATE TABLE `vt_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `interval` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255) NOT NULL,
  `run_func` varchar(255) NOT NULL,
  `params` varchar(255) NOT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vi_cron_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_cronjobs`
--

INSERT INTO `vt_cronjobs` VALUES
(1, 1351857075, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1419064514, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL'), 
(2, 1351857075, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1418949405, 1, 'Tự động lưu CSDL'), 
(3, 1351857075, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1418976413, 1, 'Xóa các file tạm trong thư mục tmp'), 
(4, 1351857075, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1418976413, 1, 'Xóa IP log files Xóa các file logo truy cập'), 
(5, 1351857075, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1418949405, 1, 'Xóa các file error_log quá hạn'), 
(6, 1351857075, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Gửi email các thông báo lỗi cho admin'), 
(7, 1351857075, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1418976413, 1, 'Xóa các referer quá hạn'), 
(8, 1351857075, 1440, 'siteDiagnostic_update.php', 'cron_siteDiagnostic_update', '', 0, 1, 1, 1418949405, 1, 'Cập nhật đánh giá site từ các máy chủ tìm kiếm'), 
(9, 1351857075, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 1418976413, 1, 'Kiểm tra phiên bản NukeViet');


-- ---------------------------------------


--
-- Table structure for table `vt_groups`
--

DROP TABLE IF EXISTS `vt_groups`;
CREATE TABLE `vt_groups` (
  `group_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `users` mediumtext NOT NULL,
  `public` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `title` (`title`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_ipcountry`
--

DROP TABLE IF EXISTS `vt_ipcountry`;
CREATE TABLE `vt_ipcountry` (
  `ip_from` int(11) unsigned NOT NULL,
  `ip_to` int(11) unsigned NOT NULL,
  `country` char(2) NOT NULL,
  `ip_file` smallint(5) unsigned NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `ip_from` (`ip_from`,`ip_to`),
  KEY `ip_file` (`ip_file`),
  KEY `country` (`country`),
  KEY `time` (`time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_ipcountry`
--

INSERT INTO `vt_ipcountry` VALUES
(3232235520, 3232301055, 'US', 192, 1351857138), 
(2064842752, 2064908287, 'VN', 123, 1353288531), 
(1906376704, 1906442239, 'VN', 113, 1353310252), 
(1906638848, 1906671615, 'VN', 113, 1353372401), 
(2883584000, 2885681151, 'VN', 171, 1353435877), 
(20258816, 20262911, 'VN', 1, 1353435935), 
(3438018560, 3438084095, 'US', 204, 1353491843), 
(1984249856, 1984253951, 'VN', 118, 1353554360), 
(2065039360, 2065104895, 'VN', 123, 1363521112), 
(1907503104, 1907507199, 'VN', 113, 1366823004), 
(2130706432, 2130771967, 'ZZ', 127, 1418003511), 
(1962934272, 1963458559, 'VN', 117, 1418289091), 
(245563392, 245628927, 'VN', 14, 1418289326), 
(1908080640, 1908113407, 'VN', 113, 1418289870), 
(2149449728, 2149515263, 'US', 128, 1418372360), 
(1906802688, 1906835455, 'VN', 113, 1418387833), 
(2918973440, 2919038975, 'US', 173, 1418389566), 
(2065367040, 2065432575, 'VN', 123, 1418553597), 
(457441280, 457703423, 'VN', 27, 1418708079), 
(1908015104, 1908080639, 'ZZ', 113, 1418954949), 
(3706126336, 3706191871, 'ZZ', 220, 1419064498);


-- ---------------------------------------


--
-- Table structure for table `vt_language`
--

DROP TABLE IF EXISTS `vt_language`;
CREATE TABLE `vt_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_language_file`
--

DROP TABLE IF EXISTS `vt_language_file`;
CREATE TABLE `vt_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `admin_file` varchar(255) NOT NULL DEFAULT '0',
  `langtype` varchar(50) NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_logs`
--

DROP TABLE IF EXISTS `vt_logs`;
CREATE TABLE `vt_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10) NOT NULL,
  `module_name` varchar(150) NOT NULL,
  `name_key` varchar(255) NOT NULL,
  `note_action` text NOT NULL,
  `link_acess` varchar(255) NOT NULL,
  `userid` int(11) NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=778  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_logs`
--

INSERT INTO `vt_logs` VALUES
(1, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1352896336), 
(2, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1352896828), 
(3, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1352897517), 
(4, 'vi', 'themes', 'Thêm block', 'Name : global html', 'Name : global html', 1, 1352898933), 
(5, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1352899470), 
(6, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1352899492), 
(7, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1352899512), 
(8, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1352899549), 
(9, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1352899565), 
(10, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1352899617), 
(11, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1352899664), 
(12, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1352899684), 
(13, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1352900062), 
(14, 'vi', 'modules', 'Thiết lập module mới shops\"', '', '', 1, 1352906426), 
(15, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1352906478), 
(16, 'vi', 'shops', 'log_add_catalog', 'id 1', 'id 1', 1, 1352906660), 
(17, 'vi', 'shops', 'log_add_catalog', 'id 2', 'id 2', 1, 1352906670), 
(18, 'vi', 'themes', 'Thêm block', 'Name : module block catalogs', 'Name : module block catalogs', 1, 1352906877), 
(19, 'vi', 'themes', 'Thêm block', 'Name : global block group', 'Name : global block group', 1, 1352906897), 
(20, 'vi', 'shops', 'Thêm nhóm sản phẩm', 'TỪ HỒ CHÍ MINH', 'TỪ HỒ CHÍ MINH', 1, 1352907056), 
(21, 'vi', 'shops', 'Thêm nhóm sản phẩm', 'TỪ HÀ NỘI', 'TỪ HÀ NỘI', 1, 1352907075), 
(22, 'vi', 'shops', 'Thêm nhóm sản phẩm', 'TỪ ĐÀ NẴNG', 'TỪ ĐÀ NẴNG', 1, 1352907091), 
(23, 'vi', 'shops', 'log_add_product', 'id 1', 'id 1', 1, 1352982947), 
(24, 'vi', 'shops', 'log_edit_product', 'id 1', 'id 1', 1, 1352983079), 
(25, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1352983118), 
(26, 'vi', 'shops', 'log_add_catalog', 'id 3', 'id 3', 1, 1352983236), 
(27, 'vi', 'shops', 'log_add_catalog', 'id 4', 'id 4', 1, 1352983245), 
(28, 'vi', 'shops', 'log_add_catalog', 'id 5', 'id 5', 1, 1352983251), 
(29, 'vi', 'shops', 'log_add_catalog', 'id 6', 'id 6', 1, 1352983280), 
(30, 'vi', 'shops', 'log_add_catalog', 'id 7', 'id 7', 1, 1352983287), 
(31, 'vi', 'shops', 'log_add_catalog', 'id 8', 'id 8', 1, 1352983295), 
(32, 'vi', 'themes', 'Thêm block', 'Name : global block group', 'Name : global block group', 1, 1352983622), 
(33, 'vi', 'shops', 'Cấu hình module', 'setting', 'setting', 1, 1352983680), 
(34, 'vi', 'modules', 'Thiết lập module mới tour\"', '', '', 1, 1352984671), 
(35, 'vi', 'modules', 'Sửa module &ldquo;tour&rdquo;', '', '', 1, 1352984718), 
(36, 'vi', 'themes', 'Thêm block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1352984740), 
(37, 'vi', 'modules', 'Xóa module \"shops\"', '', '', 1, 1352984796), 
(38, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1352984820), 
(39, 'vi', 'tour', 'log_add_catalog', 'id 1', 'id 1', 1, 1352984872), 
(40, 'vi', 'tour', 'log_add_catalog', 'id 2', 'id 2', 1, 1352984878), 
(41, 'vi', 'tour', 'log_add_catalog', 'id 3', 'id 3', 1, 1352984886), 
(42, 'vi', 'tour', 'log_add_catalog', 'id 4', 'id 4', 1, 1352984892), 
(43, 'vi', 'tour', 'log_add_catalog', 'id 5', 'id 5', 1, 1352984904), 
(44, 'vi', 'tour', 'log_add_catalog', 'id 6', 'id 6', 1, 1352984917), 
(45, 'vi', 'tour', 'log_add_catalog', 'id 7', 'id 7', 1, 1352984921), 
(46, 'vi', 'tour', 'log_add_catalog', 'id 8', 'id 8', 1, 1352984925), 
(47, 'vi', 'tour', 'Cấu hình module', 'setting', 'setting', 1, 1352985341), 
(48, 'vi', 'tour', 'Thêm nhóm tour', 'TRONG NƯỚC', 'TRONG NƯỚC', 1, 1352985436), 
(49, 'vi', 'tour', 'Thêm nhóm tour', 'Tour miền Bắc', 'Tour miền Bắc', 1, 1352985446), 
(50, 'vi', 'tour', 'Thêm nhóm tour', 'Tour miền Trung', 'Tour miền Trung', 1, 1352985453), 
(51, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Tây Nguyên', 'Tour Tây Nguyên', 1, 1352985463), 
(52, 'vi', 'tour', 'Thêm nhóm tour', 'Tour miền Tây Nam Bộ', 'Tour miền Tây Nam Bộ', 1, 1352985472), 
(53, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Nha Trang', 'Tour Nha Trang', 1, 1352985479), 
(54, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Phan Thiết', 'Tour Phan Thiết', 1, 1352985495), 
(55, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Vũng Tàu', 'Tour Vũng Tàu', 1, 1352985502), 
(56, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Đà Nẵng', 'Tour Đà Nẵng', 1, 1352985510), 
(57, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Cần Thơ', 'Tour Cần Thơ', 1, 1352985518), 
(58, 'vi', 'tour', 'Thêm nhóm tour', 'NƯỚC NGOÀI', 'NƯỚC NGOÀI', 1, 1352985531), 
(59, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Campuchia', 'Tour Campuchia', 1, 1352985539), 
(60, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Thái Lan', 'Tour Thái Lan', 1, 1352985546), 
(61, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Singapore', 'Tour Singapore', 1, 1352985552), 
(62, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Nhật Bản', 'Tour Nhật Bản', 1, 1352985557), 
(63, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Mỹ', 'Tour Mỹ', 1, 1352985563), 
(64, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Châu Âu', 'Tour Châu Âu', 1, 1352985568), 
(65, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Ấn Độ', 'Tour Ấn Độ', 1, 1352985577), 
(66, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Lào', 'Tour Lào', 1, 1352985584), 
(67, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Đông Nam Á', 'Tour Đông Nam Á', 1, 1352985590), 
(68, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Châu Mỹ', 'Tour Châu Mỹ', 1, 1352985596), 
(69, 'vi', 'themes', 'Sửa block', 'Name : global block group', 'Name : global block group', 1, 1352985641), 
(70, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1352990155), 
(71, 'vi', 'upload', 'Upload file', 'uploads/sologan.png', 'uploads/sologan.png', 1, 1352990945), 
(72, 'vi', 'upload', 'Upload file', 'uploads/tour/2012_11/2101bephiendai_timnhanh-4.jpg', 'uploads/tour/2012_11/2101bephiendai_timnhanh-4.jpg', 1, 1352992782), 
(73, 'vi', 'tour', 'log_add_product', 'id 1', 'id 1', 1, 1352993046), 
(74, 'vi', 'tour', 'log_edit_product', 'id 1', 'id 1', 1, 1352993407), 
(75, 'vi', 'themes', 'Thêm block', 'Name : global block group', 'Name : global block group', 1, 1352993490), 
(76, 'vi', 'themes', 'Sửa block', 'Name : global block group', 'Name : global block group', 1, 1352993517), 
(77, 'vi', 'tour', 'Cấu hình module', 'setting', 'setting', 1, 1352996069), 
(78, 'vi', 'upload', 'Upload file', 'uploads/tour/2012_11/phong-thuy-nha-bep-va-nu-chu-nhan.jpg', 'uploads/tour/2012_11/phong-thuy-nha-bep-va-nu-chu-nhan.jpg', 1, 1352996125), 
(79, 'vi', 'tour', 'log_add_product', 'id 2', 'id 2', 1, 1352996149), 
(80, 'vi', 'tour', 'log_add_product', 'id 3', 'id 3', 1, 1352999690), 
(81, 'vi', 'tour', 'log_add_product', 'id 4', 'id 4', 1, 1352999814), 
(82, 'vi', 'tour', 'log_edit_product', 'id 4', 'id 4', 1, 1353001047), 
(83, 'vi', 'tour', 'Cấu hình module', 'setting', 'setting', 1, 1353074313), 
(84, 'vi', 'tour', 'Cấu hình module', 'setting', 'setting', 1, 1353074445), 
(85, 'vi', 'tour', 'Cấu hình module', 'setting', 'setting', 1, 1353074529), 
(86, 'vi', 'tour', 'Cấu hình module', 'setting', 'setting', 1, 1353074554), 
(87, 'vi', 'tour', 'Thêm nhóm tour', 'LOẠI HÌNH TOUR', 'LOẠI HÌNH TOUR', 1, 1353074610), 
(88, 'vi', 'tour', 'Thêm nhóm tour', 'THEO NGÀY', 'THEO NGÀY', 1, 1353074633), 
(89, 'vi', 'tour', 'Thêm nhóm tour', 'Du lịch biển', 'Du lịch biển', 1, 1353074646), 
(90, 'vi', 'tour', 'Thêm nhóm tour', 'Du lịch trăng mật', 'Du lịch trăng mật', 1, 1353074654), 
(91, 'vi', 'tour', 'Thêm nhóm tour', 'Du lịch dã ngoại', 'Du lịch dã ngoại', 1, 1353074661), 
(92, 'vi', 'tour', 'Thêm nhóm tour', 'Du lịch xuyên Việt', 'Du lịch xuyên Việt', 1, 1353074667), 
(93, 'vi', 'tour', 'Thêm nhóm tour', 'Du lịch cao cấp', 'Du lịch cao cấp', 1, 1353074674), 
(94, 'vi', 'tour', 'Thêm nhóm tour', 'Du lịch cuối tuần', 'Du lịch cuối tuần', 1, 1353074680), 
(95, 'vi', 'tour', 'Thêm nhóm tour', 'Du lịch lễ hội', 'Du lịch lễ hội', 1, 1353074688), 
(96, 'vi', 'tour', 'Thêm nhóm tour', 'Du lịch mạo hiểm', 'Du lịch mạo hiểm', 1, 1353074694), 
(97, 'vi', 'tour', 'Thêm nhóm tour', '1 Ngày', '1 Ngày', 1, 1353074706), 
(98, 'vi', 'tour', 'Thêm nhóm tour', '2 Ngày 1 Đêm', '2 Ngày 1 Đêm', 1, 1353074712), 
(99, 'vi', 'tour', 'Thêm nhóm tour', '3 Ngày 2 Đêm', '3 Ngày 2 Đêm', 1, 1353074717), 
(100, 'vi', 'tour', 'Thêm nhóm tour', '4 Ngày 3 Đêm', '4 Ngày 3 Đêm', 1, 1353074725), 
(101, 'vi', 'tour', 'Thêm nhóm tour', '5 Ngày 4 Đêm', '5 Ngày 4 Đêm', 1, 1353074731), 
(102, 'vi', 'tour', 'Thêm nhóm tour', '7 Ngày 6 Đêm', '7 Ngày 6 Đêm', 1, 1353074738), 
(103, 'vi', 'tour', 'Thêm nhóm tour', '8 Ngày 7 Đêm', '8 Ngày 7 Đêm', 1, 1353074744), 
(104, 'vi', 'tour', 'Thêm nhóm tour', '9 Ngày 8 Đêm', '9 Ngày 8 Đêm', 1, 1353074750), 
(105, 'vi', 'tour', 'Thêm nhóm tour', '10 Ngày 9 Đêm', '10 Ngày 9 Đêm', 1, 1353074755), 
(106, 'vi', 'tour', 'Thêm nhóm tour', '12 Ngày 11 Đêm', '12 Ngày 11 Đêm', 1, 1353074762), 
(107, 'vi', 'tour', 'log_edit_product', 'id 3', 'id 3', 1, 1353078310), 
(108, 'vi', 'tour', 'log_edit_product', 'id 2', 'id 2', 1, 1353078454), 
(109, 'vi', 'tour', 'log_edit_product', 'id 4', 'id 4', 1, 1353078466), 
(110, 'vi', 'tour', 'log_edit_product', 'id 4', 'id 4', 1, 1353079869), 
(111, 'vi', 'tour', 'log_edit_product', 'id 4', 'id 4', 1, 1353079965), 
(112, 'vi', 'tour', 'log_edit_product', 'id 4', 'id 4', 1, 1353080006), 
(113, 'vi', 'themes', 'Sửa block', 'Name : global block group', 'Name : global block group', 1, 1353084793), 
(114, 'vi', 'themes', 'Sửa block', 'Name : global block group', 'Name : global block group', 1, 1353084810), 
(115, 'vi', 'themes', 'Thêm block', 'Name : global block cart', 'Name : global block cart', 1, 1353085303), 
(116, 'vi', 'themes', 'Thêm block', 'Name : global block group', 'Name : global block group', 1, 1353085737), 
(117, 'vi', 'themes', 'Sửa block', 'Name : global block group', 'Name : global block group', 1, 1353085988), 
(118, 'vi', 'modules', 'Thiết lập module mới shops\"', '', '', 1, 1353165131), 
(119, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1353165136), 
(120, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1353165168), 
(121, 'vi', 'themes', 'Thêm block', 'Name : global block search', 'Name : global block search', 1, 1353165186), 
(122, 'vi', 'themes', 'Sửa block', 'Name : global block search', 'Name : global block search', 1, 1353165407), 
(123, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1353165470), 
(124, 'vi', 'themes', 'Thêm block', 'Name : global block group', 'Name : global block group', 1, 1353165524), 
(125, 'vi', 'themes', 'Sửa block', 'Name : global block group', 'Name : global block group', 1, 1353165561), 
(126, 'vi', 'modules', 'Cài lại module \"tour\"', '', '', 1, 1353165606), 
(127, 'vi', 'themes', 'Thêm block', 'Name : global block group', 'Name : global block group', 1, 1353165635), 
(128, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'TRONG NƯỚC', 'TRONG NƯỚC', 1, 1353165660), 
(129, 'vi', 'tour', 'log_add_catalog', 'id 1', 'id 1', 1, 1353165679), 
(130, 'vi', 'tour', 'log_add_catalog', 'id 2', 'id 2', 1, 1353165684), 
(131, 'vi', 'tour', 'log_add_catalog', 'id 3', 'id 3', 1, 1353165689), 
(132, 'vi', 'tour', 'log_add_catalog', 'id 4', 'id 4', 1, 1353165694), 
(133, 'vi', 'tour', 'log_add_catalog', 'id 5', 'id 5', 1, 1353165700), 
(134, 'vi', 'tour', 'log_add_catalog', 'id 6', 'id 6', 1, 1353165707), 
(135, 'vi', 'tour', 'log_add_catalog', 'id 7', 'id 7', 1, 1353165711), 
(136, 'vi', 'tour', 'log_add_catalog', 'id 8', 'id 8', 1, 1353165714), 
(137, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour miền Bắc', 'Tour miền Bắc', 1, 1353165845), 
(138, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour miền Trung', 'Tour miền Trung', 1, 1353165861), 
(139, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Đà Lạt', 'Tour Đà Lạt', 1, 1353165869), 
(140, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Phan Thiết', 'Tour Phan Thiết', 1, 1353165874), 
(141, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Vũng Tàu', 'Tour Vũng Tàu', 1, 1353165879), 
(142, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Đà Nẵng', 'Tour Đà Nẵng', 1, 1353165889), 
(143, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Hội An', 'Tour Hội An', 1, 1353165897), 
(144, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'NƯỚC NGOÀI', 'NƯỚC NGOÀI', 1, 1353165916), 
(145, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'NƯỚC NGOÀI', 'NƯỚC NGOÀI', 1, 1353165959), 
(146, 'vi', 'tour', 'Xóa nhóm và các sản phẩm', 'NƯỚC NGOÀI', 'NƯỚC NGOÀI', 1, 1353165964), 
(147, 'vi', 'tour', 'Xóa nhóm và các sản phẩm', 'NƯỚC NGOÀI', 'NƯỚC NGOÀI', 1, 1353165981), 
(148, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'NƯỚC NGOÀI', 'NƯỚC NGOÀI', 1, 1353166002), 
(149, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Thái Lan', 'Tour Thái Lan', 1, 1353166013), 
(150, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Singapore', 'Tour Singapore', 1, 1353166017), 
(151, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Hong Kong', 'Tour Hong Kong', 1, 1353166022), 
(152, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Trung Quốc', 'Tour Trung Quốc', 1, 1353166027), 
(153, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Hàn Quốc', 'Tour Hàn Quốc', 1, 1353166032), 
(154, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Châu Âu', 'Tour Châu Âu', 1, 1353166038), 
(155, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Ấn Độ', 'Tour Ấn Độ', 1, 1353166044), 
(156, 'vi', 'tour', 'Cấu hình module', 'Setting', 'Setting', 1, 1353166103), 
(157, 'vi', 'tour', 'Add A Product', 'ID: 1', 'ID: 1', 1, 1353166160), 
(158, 'vi', 'themes', 'Sửa block', 'Name : global block group', 'Name : global block group', 1, 1353166263), 
(159, 'vi', 'tour', 'Sửa nhóm sản phẩm', 'NGOÀI NƯỚC', 'NGOÀI NƯỚC', 1, 1353166296), 
(160, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1353166348), 
(161, 'vi', 'themes', 'Thêm block', 'Name : global block group', 'Name : global block group', 1, 1353166500), 
(162, 'vi', 'tour', 'Cấu hình module', 'Setting', 'Setting', 1, 1353166751), 
(163, 'vi', 'tour', 'Xóa nhóm và các sản phẩm', 'Tour Thái Lan', 'Tour Thái Lan', 1, 1353166854), 
(164, 'vi', 'tour', 'Xóa nhóm và các sản phẩm', 'Tour Singapore', 'Tour Singapore', 1, 1353166856), 
(165, 'vi', 'tour', 'Xóa nhóm và các sản phẩm', 'Tour Hong Kong', 'Tour Hong Kong', 1, 1353166857), 
(166, 'vi', 'tour', 'Xóa nhóm và các sản phẩm', 'Tour Trung Quốc', 'Tour Trung Quốc', 1, 1353166858), 
(167, 'vi', 'tour', 'Xóa nhóm và các sản phẩm', 'Tour Hàn Quốc', 'Tour Hàn Quốc', 1, 1353166859), 
(168, 'vi', 'tour', 'Xóa nhóm và các sản phẩm', 'Tour Châu Âu', 'Tour Châu Âu', 1, 1353166861), 
(169, 'vi', 'tour', 'Xóa nhóm và các sản phẩm', 'Tour Ấn Độ', 'Tour Ấn Độ', 1, 1353166862), 
(170, 'vi', 'tour', 'Xóa nhóm và các sản phẩm', 'NGOÀI NƯỚC', 'NGOÀI NƯỚC', 1, 1353166866), 
(171, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'NGOÀI NƯỚC', 'NGOÀI NƯỚC', 1, 1353166882), 
(172, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Campuchia', 'Tour Campuchia', 1, 1353167071), 
(173, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Thái Lan', 'Tour Thái Lan', 1, 1353167078), 
(174, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Singapore', 'Tour Singapore', 1, 1353167084), 
(175, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Hong Kong', 'Tour Hong Kong', 1, 1353167091), 
(176, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Hàn Quốc', 'Tour Hàn Quốc', 1, 1353167097), 
(177, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Nhật Bản', 'Tour Nhật Bản', 1, 1353167104), 
(178, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Châu Âu', 'Tour Châu Âu', 1, 1353167112), 
(179, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Bali', 'Tour Bali', 1, 1353167118), 
(180, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Lào', 'Tour Lào', 1, 1353167125), 
(181, 'vi', 'tour', 'Edit A Product', 'ID: 1', 'ID: 1', 1, 1353167246), 
(182, 'vi', 'tour', 'Add A Product', 'ID: 2', 'ID: 2', 1, 1353167433), 
(183, 'vi', 'upload', 'Upload file', 'uploads/tour/2012_11/tubep.jpg', 'uploads/tour/2012_11/tubep.jpg', 1, 1353167463), 
(184, 'vi', 'tour', 'Add A Product', 'ID: 3', 'ID: 3', 1, 1353167491), 
(185, 'vi', 'upload', 'Upload file', 'uploads/tour/2012_11/phong-thuy-nha-bep-va-nu-chu-nhan_1.jpg', 'uploads/tour/2012_11/phong-thuy-nha-bep-va-nu-chu-nhan_1.jpg', 1, 1353167546), 
(186, 'vi', 'tour', 'Add A Product', 'ID: 4', 'ID: 4', 1, 1353167566), 
(187, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1353168404), 
(188, 'vi', 'tour', 'Add A Product', 'ID: 5', 'ID: 5', 1, 1353168809), 
(189, 'vi', 'tour', 'Cấu hình module', 'Setting', 'Setting', 1, 1353169405), 
(190, 'vi', 'tour', 'Cấu hình module', 'Setting', 'Setting', 1, 1353169507), 
(191, 'vi', 'upload', 'Upload file', 'uploads/tour/2012_11/bep-1.jpg', 'uploads/tour/2012_11/bep-1.jpg', 1, 1353169695), 
(192, 'vi', 'tour', 'Add A Product', 'ID: 6', 'ID: 6', 1, 1353169705), 
(193, 'vi', 'tour', 'Edit A Product', 'ID: 5', 'ID: 5', 1, 1353169945), 
(194, 'vi', 'tour', 'Cấu hình module', 'Setting', 'Setting', 1, 1353172331), 
(195, 'vi', 'tour', 'Edit A Product', 'ID: 6', 'ID: 6', 1, 1353173789), 
(196, 'vi', 'tour', 'Edit A Product', 'ID: 1', 'ID: 1', 1, 1353173836), 
(197, 'vi', 'tour', 'Edit A Product', 'ID: 4', 'ID: 4', 1, 1353174157), 
(198, 'vi', 'tour', 'Edit A Product', 'ID: 3', 'ID: 3', 1, 1353174178), 
(199, 'vi', 'tour', 'Edit A Product', 'ID: 5', 'ID: 5', 1, 1353174207), 
(200, 'vi', 'tour', 'Cấu hình module', 'Setting', 'Setting', 1, 1353179211), 
(201, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1353179473), 
(202, 'vi', 'modules', 'Sửa module &ldquo;tour&rdquo;', '', '', 1, 1353179491), 
(203, 'vi', 'modules', 'Kích hoạt module \"tour\"', 'Có', 'Có', 1, 1353179501), 
(204, 'vi', 'tour', 'Cấu hình module', 'Setting', 'Setting', 1, 1353179646), 
(205, 'vi', 'tour', 'Cấu hình module', 'Setting', 'Setting', 1, 1353179668), 
(206, 'vi', 'tour', 'Cấu hình module', 'Setting', 'Setting', 1, 1353179679), 
(207, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'LOẠI HÌNH TOUR', 'LOẠI HÌNH TOUR', 1, 1353181642), 
(208, 'vi', 'themes', 'Thêm block', 'Name : global block catalogs', 'Name : global block catalogs', 1, 1353212931), 
(209, 'vi', 'themes', 'Sửa block', 'Name : global block catalogs', 'Name : global block catalogs', 1, 1353212944), 
(210, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Du lịch biển', 'Du lịch biển', 1, 1353217271), 
(211, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Du lịch trăng mật', 'Du lịch trăng mật', 1, 1353217277), 
(212, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Du lịch dã ngoại', 'Du lịch dã ngoại', 1, 1353217284), 
(213, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Du lịch xuyên Việt', 'Du lịch xuyên Việt', 1, 1353217291), 
(214, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Du lịch hè', 'Du lịch hè', 1, 1353217297), 
(215, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Du lịch cao cấp', 'Du lịch cao cấp', 1, 1353217302), 
(216, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Du lịch cuối tuần', 'Du lịch cuối tuần', 1, 1353217309), 
(217, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'THEO NGÀY', 'THEO NGÀY', 1, 1353217322), 
(218, 'vi', 'tour', 'Thêm nhóm sản phẩm', '3 Ngày 2 Đêm', '3 Ngày 2 Đêm', 1, 1353217337), 
(219, 'vi', 'tour', 'Thêm nhóm sản phẩm', '4 Ngày 3 Đêm', '4 Ngày 3 Đêm', 1, 1353217344), 
(220, 'vi', 'tour', 'Thêm nhóm sản phẩm', '5 Ngày 4 Đêm', '5 Ngày 4 Đêm', 1, 1353217349), 
(221, 'vi', 'tour', 'Thêm nhóm sản phẩm', '7 Ngày 6 Đêm', '7 Ngày 6 Đêm', 1, 1353217354), 
(222, 'vi', 'tour', 'Thêm nhóm sản phẩm', '8 Ngày 7 Đêm', '8 Ngày 7 Đêm', 1, 1353217360), 
(223, 'vi', 'tour', 'Thêm nhóm sản phẩm', '9 Ngày 8 Đêm', '9 Ngày 8 Đêm', 1, 1353217365), 
(224, 'vi', 'tour', 'Thêm nhóm sản phẩm', '10 Ngày 9 Đêm', '10 Ngày 9 Đêm', 1, 1353217371), 
(225, 'vi', 'tour', 'Thêm nhóm sản phẩm', '11 Ngày 10 Đêm', '11 Ngày 10 Đêm', 1, 1353217376), 
(226, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Xuyên Việt', 'Tour Xuyên Việt', 1, 1353217569), 
(227, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Tour Miền Nam', 'Tour Miền Nam', 1, 1353217580), 
(228, 'vi', 'tour', 'Thêm nhóm sản phẩm', '1 Ngày', '1 Ngày', 1, 1353217610), 
(229, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Du lịch lễ hội', 'Du lịch lễ hội', 1, 1353217633), 
(230, 'vi', 'tour', 'Thêm nhóm sản phẩm', 'Du lịch Mice', 'Du lịch Mice', 1, 1353217650), 
(231, 'vi', 'tour', 'Edit A Product', 'ID: 5', 'ID: 5', 1, 1353218763), 
(232, 'vi', 'themes', 'Sửa block', 'Name : global block group', 'Name : global block group', 1, 1353219397), 
(233, 'vi', 'modules', 'Sửa module &ldquo;news&rdquo;', '', '', 1, 1353220923), 
(234, 'vi', 'modules', 'Sửa module &ldquo;news&rdquo;', '', '', 1, 1353220932), 
(235, 'vi', 'themes', 'Sửa block', 'Name : global block cart', 'Name : global block cart', 1, 1353221988), 
(236, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1353222575), 
(237, 'vi', 'themes', 'Thêm block', 'Name : global block tophits', 'Name : global block tophits', 1, 1353223021), 
(238, 'vi', 'themes', 'Sửa block', 'Name : global block tophits', 'Name : global block tophits', 1, 1353223454), 
(239, 'vi', 'themes', 'Sửa block', 'Name : global block tophits', 'Name : global block tophits', 1, 1353223466), 
(240, 'vi', 'themes', 'Sửa block', 'Name : global block tophits', 'Name : global block tophits', 1, 1353223489), 
(241, 'vi', 'themes', 'Sửa block', 'Name : global block tophits', 'Name : global block tophits', 1, 1353223535), 
(242, 'vi', 'themes', 'Sửa block', 'Name : global block tophits', 'Name : global block tophits', 1, 1353223615), 
(243, 'vi', 'themes', 'Sửa block', 'Name : global block tophits', 'Name : global block tophits', 1, 1353223634), 
(244, 'vi', 'themes', 'Sửa block', 'Name : global block tophits', 'Name : global block tophits', 1, 1353223652), 
(245, 'vi', 'themes', 'Sửa block', 'Name : global block tophits', 'Name : global block tophits', 1, 1353223686), 
(246, 'vi', 'themes', 'Sửa block', 'Name : global block tophits', 'Name : global block tophits', 1, 1353223755), 
(247, 'vi', 'themes', 'Thêm block', 'Name : global block catid', 'Name : global block catid', 1, 1353223800), 
(248, 'vi', 'themes', 'Sửa block', 'Name : global block catid', 'Name : global block catid', 1, 1353223810), 
(249, 'vi', 'themes', 'Sửa block', 'Name : global block tophits', 'Name : global block tophits', 1, 1353224309), 
(250, 'vi', 'themes', 'Sửa block', 'Name : global block catid', 'Name : global block catid', 1, 1353224317), 
(251, 'vi', 'themes', 'Sửa block', 'Name : TEAM BUILDING', 'Name : TEAM BUILDING', 1, 1353224403), 
(252, 'vi', 'themes', 'Sửa block', 'Name : global block tophits', 'Name : global block tophits', 1, 1353224693), 
(253, 'vi', 'themes', 'Thêm block', 'Name : global news style catid', 'Name : global news style catid', 1, 1353225578), 
(254, 'vi', 'themes', 'Sửa block', 'Name : global news style catid', 'Name : global news style catid', 1, 1353225608), 
(255, 'vi', 'themes', 'Sửa block', 'Name : global news style catid', 'Name : global news style catid', 1, 1353225634), 
(256, 'vi', 'themes', 'Sửa block', 'Name : global news style catid', 'Name : global news style catid', 1, 1353225658), 
(257, 'vi', 'themes', 'Sửa block', 'Name : CHO THUÊ XE', 'Name : CHO THUÊ XE', 1, 1353225768), 
(258, 'vi', 'themes', 'Sửa block', 'Name : global block cart', 'Name : global block cart', 1, 1353225990), 
(259, 'vi', 'themes', 'Sửa block', 'Name : global news style catid', 'Name : global news style catid', 1, 1353226478), 
(260, 'vi', 'themes', 'Sửa block', 'Name : TEAM BUILDING', 'Name : TEAM BUILDING', 1, 1353226500), 
(261, 'vi', 'themes', 'Sửa block', 'Name : CHO THUÊ XE', 'Name : CHO THUÊ XE', 1, 1353226704), 
(262, 'vi', 'themes', 'Sửa block', 'Name : CHO THUÊ XE', 'Name : CHO THUÊ XE', 1, 1353226718), 
(263, 'vi', 'themes', 'Sửa block', 'Name : TEAM BUILDING', 'Name : TEAM BUILDING', 1, 1353226733), 
(264, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1353226874), 
(265, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.19.120.164', ' Client IP:123.19.120.164', 0, 1353228954), 
(266, 'vi', 'tour', 'Thêm nhóm tour', 'Nơi khởi hành', 'Nơi khởi hành', 1, 1353229063), 
(267, 'vi', 'tour', 'Thêm nhóm tour', 'Hà nội', 'Hà nội', 1, 1353229087), 
(268, 'vi', 'tour', 'Thêm nhóm tour', 'Hồ chí minh', 'Hồ chí minh', 1, 1353229100), 
(269, 'vi', 'tour', 'Thêm nhóm tour', 'Đà nẵng', 'Đà nẵng', 1, 1353229113), 
(270, 'vi', 'tour', 'Thêm nhóm tour', 'Nơi đến', 'Nơi đến', 1, 1353229130), 
(271, 'vi', 'tour', 'Thêm nhóm tour', 'Tour miền Bắc', 'Tour miền Bắc', 1, 1353229251), 
(272, 'vi', 'tour', 'Thêm nhóm tour', 'Tour miền Trung', 'Tour miền Trung', 1, 1353229257), 
(273, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Tây Nguyên', 'Tour Tây Nguyên', 1, 1353229262), 
(274, 'vi', 'tour', 'Thêm nhóm tour', 'Tour miền Tây Nam Bộ', 'Tour miền Tây Nam Bộ', 1, 1353229271), 
(275, 'vi', 'tour', 'Thêm nhóm tour', 'Tour Nha Trang', 'Tour Nha Trang', 1, 1353229279), 
(276, 'vi', 'tour', 'Sửa nhóm tour', 'Tour Tây Nam Bộ', 'Tour Tây Nam Bộ', 1, 1353229320), 
(277, 'vi', 'menu', 'De-lete menu item', 'Item ID  22', 'Item ID  22', 1, 1353229635), 
(278, 'vi', 'modules', 'Sửa module &ldquo;news&rdquo;', '', '', 1, 1353230066), 
(279, 'vi', 'news', 'Thêm chuyên mục', 'XE 12 - 16 CHỖ', 'XE 12 - 16 CHỖ', 1, 1353230549), 
(280, 'vi', 'news', 'Thêm chuyên mục', 'XE 24 - 30 CHỖ', 'XE 24 - 30 CHỖ', 1, 1353230560), 
(281, 'vi', 'news', 'Thêm chuyên mục', 'XE 35 - 45 CHỖ', 'XE 35 - 45 CHỖ', 1, 1353230574), 
(282, 'vi', 'news', 'Sửa bài viết', 'Webnhanh.vn - website dịch vụ chuyên nghiệp cho NukeViet chính thức ra mắt', 'Webnhanh.vn - website dịch vụ chuyên nghiệp cho NukeViet chính thức ra mắt', 1, 1353230671), 
(283, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.19.119.200', ' Client IP:123.19.119.200', 0, 1353293872), 
(284, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:123.19.119.200', ' Client IP:123.19.119.200', 0, 1353296422), 
(285, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.19.123.159', ' Client IP:123.19.123.159', 0, 1353340009), 
(286, 'vi', 'modules', 'Cài đặt gói Module + Block', 'nv3_module_rental.zip', 'nv3_module_rental.zip', 1, 1353340096), 
(287, 'vi', 'modules', 'Thiết lập module mới rental\"', '', '', 1, 1353340131), 
(288, 'vi', 'modules', 'Sửa module &ldquo;rental&rdquo;', '', '', 1, 1353340151), 
(289, 'vi', 'modules', 'Xóa module \"shops\"', '', '', 1, 1353340156), 
(290, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1353340196), 
(291, 'vi', 'modules', 'Thứ tự module \"tour\"', '12 -> 1', '12 -> 1', 1, 1353340215), 
(292, 'vi', 'modules', 'Thứ tự module \"rental\"', '12 -> 2', '12 -> 2', 1, 1353340218), 
(293, 'vi', 'rental', 'log_add_catalog', 'id 1', 'id 1', 1, 1353340239), 
(294, 'vi', 'rental', 'log_add_catalog', 'id 2', 'id 2', 1, 1353340244), 
(295, 'vi', 'rental', 'log_add_catalog', 'id 3', 'id 3', 1, 1353340251), 
(296, 'vi', 'rental', 'Thêm nhóm sản phẩm', 'Xe Hyundai', 'Xe Hyundai', 1, 1353340282), 
(297, 'vi', 'rental', 'Thêm nhóm sản phẩm', 'Xe Mercedes', 'Xe Mercedes', 1, 1353340287), 
(298, 'vi', 'rental', 'Thêm nhóm sản phẩm', 'Xe Mitsubishi', 'Xe Mitsubishi', 1, 1353340292), 
(299, 'vi', 'rental', 'Thêm nhóm sản phẩm', 'Xe Ford', 'Xe Ford', 1, 1353340298), 
(300, 'vi', 'rental', 'Thêm nhóm sản phẩm', 'Xe Toyota', 'Xe Toyota', 1, 1353340304), 
(301, 'vi', 'rental', 'Thêm nhóm sản phẩm', 'Xe Honda', 'Xe Honda', 1, 1353340311), 
(302, 'vi', 'rental', 'Thêm nhóm sản phẩm', 'Xe ISUZU', 'Xe ISUZU', 1, 1353340315), 
(303, 'vi', 'rental', 'Thêm nhóm sản phẩm', 'Xe Daewoo', 'Xe Daewoo', 1, 1353340321), 
(304, 'vi', 'rental', 'Thêm nhóm sản phẩm', 'Xe Suzuki', 'Xe Suzuki', 1, 1353340328), 
(305, 'vi', 'rental', 'Thêm nhóm sản phẩm', 'Xe BMW', 'Xe BMW', 1, 1353340334), 
(306, 'vi', 'rental', 'Thêm nhóm sản phẩm', 'Xe Kia', 'Xe Kia', 1, 1353340341), 
(307, 'vi', 'rental', 'Thêm nhóm sản phẩm', 'Xe Lexus', 'Xe Lexus', 1, 1353340348), 
(308, 'vi', 'rental', 'Thêm nhóm sản phẩm', 'Xe Nissan', 'Xe Nissan', 1, 1353340354), 
(309, 'vi', 'upload', 'Upload file', 'uploads/rental/2012_11/toyo.jpg', 'uploads/rental/2012_11/toyo.jpg', 1, 1353340454), 
(310, 'vi', 'rental', 'Add A Product', 'ID: 1', 'ID: 1', 1, 1353340477), 
(311, 'vi', 'upload', 'Upload file', 'uploads/rental/2012_11/toino.jpg', 'uploads/rental/2012_11/toino.jpg', 1, 1353340514), 
(312, 'vi', 'rental', 'Add A Product', 'ID: 2', 'ID: 2', 1, 1353340531), 
(313, 'vi', 'rental', 'Cấu hình module', 'Setting', 'Setting', 1, 1353340582), 
(314, 'vi', 'upload', 'Upload file', 'uploads/rental/2012_11/yyyo.jpg', 'uploads/rental/2012_11/yyyo.jpg', 1, 1353340639), 
(315, 'vi', 'rental', 'Add A Product', 'ID: 3', 'ID: 3', 1, 1353340654), 
(316, 'vi', 'upload', 'Upload file', 'uploads/rental/2012_11/eoro.jpg', 'uploads/rental/2012_11/eoro.jpg', 1, 1353340692), 
(317, 'vi', 'rental', 'Add A Product', 'ID: 4', 'ID: 4', 1, 1353340704), 
(318, 'vi', 'upload', 'Upload file', 'uploads/rental/2012_11/luxy.jpg', 'uploads/rental/2012_11/luxy.jpg', 1, 1353340727), 
(319, 'vi', 'rental', 'Add A Product', 'ID: 5', 'ID: 5', 1, 1353340738), 
(320, 'vi', 'rental', 'Edit A Product', 'ID: 5', 'ID: 5', 1, 1353340762), 
(321, 'vi', 'themes', 'Thêm block', 'Name : THUÊ XE THEO CHỖ', 'Name : THUÊ XE THEO CHỖ', 1, 1353340799), 
(322, 'vi', 'themes', 'Thêm block', 'Name : THUÊ XE THEO HÃNG', 'Name : THUÊ XE THEO HÃNG', 1, 1353340834), 
(323, 'vi', 'themes', 'Sửa block', 'Name : CHO THUÊ XE', 'Name : CHO THUÊ XE', 1, 1353340932), 
(324, 'vi', 'themes', 'Sửa block', 'Name : CHO THUÊ XE', 'Name : CHO THUÊ XE', 1, 1353341029), 
(325, 'vi', 'themes', 'Sửa block', 'Name : CHO THUÊ XE', 'Name : CHO THUÊ XE', 1, 1353341835), 
(326, 'vi', 'themes', 'Sửa block', 'Name : TEAM BUILDING', 'Name : TEAM BUILDING', 1, 1353342608), 
(327, 'vi', 'themes', 'Sửa block', 'Name : TEAM BUILDING', 'Name : TEAM BUILDING', 1, 1353342621), 
(328, 'vi', 'themes', 'Sửa block', 'Name : TEAM BUILDING', 'Name : TEAM BUILDING', 1, 1353342646), 
(329, 'vi', 'themes', 'Sửa block', 'Name : TEAM BUILDING', 'Name : TEAM BUILDING', 1, 1353342716), 
(330, 'vi', 'tour', 'log_add_catalog', 'id 9', 'id 9', 1, 1353342859), 
(331, 'vi', 'modules', 'Cài đặt gói Module + Block', 'nv3_module_silide.zip', 'nv3_module_silide.zip', 1, 1353343342), 
(332, 'vi', 'modules', 'Thiết lập module mới silide\"', '', '', 1, 1353343349), 
(333, 'vi', 'modules', 'Sửa module &ldquo;silide&rdquo;', '', '', 1, 1353343359), 
(334, 'vi', 'upload', 'Upload file', 'uploads/silide/slide-nha-trang.jpg', 'uploads/silide/slide-nha-trang.jpg', 1, 1353343433), 
(335, 'vi', 'themes', 'Thêm block', 'Name : global html', 'Name : global html', 1, 1353345449), 
(336, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1353345491), 
(337, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1353345513), 
(338, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1353345532), 
(339, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1353345548), 
(340, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1353347374), 
(341, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1353347421), 
(342, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1353347449), 
(343, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.165.107.117', ' Client IP:113.165.107.117', 0, 1353374400), 
(344, 'vi', 'tour', 'Edit A Product', 'ID: 3', 'ID: 3', 1, 1353374575), 
(345, 'vi', 'tour', 'Edit A Product', 'ID: 6', 'ID: 6', 1, 1353374605), 
(346, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:113.165.107.117', ' Client IP:113.165.107.117', 0, 1353383465), 
(347, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.165.107.117', ' Client IP:113.165.107.117', 0, 1353393901), 
(348, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1353393945), 
(349, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:113.165.97.226', ' Client IP:113.165.97.226', 0, 1353469128), 
(350, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.165.102.106', ' Client IP:113.165.102.106', 0, 1353508331), 
(351, 'vi', 'modules', 'Thiết lập module mới shops\"', '', '', 1, 1353508387), 
(352, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1353508406), 
(353, 'vi', 'themes', 'Thêm block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1353508441), 
(354, 'vi', 'shops', 'log_add_catalog', 'id 1', 'id 1', 1, 1353508516), 
(355, 'vi', 'shops', 'log_add_catalog', 'id 2', 'id 2', 1, 1353508525), 
(356, 'vi', 'shops', 'log_add_catalog', 'id 3', 'id 3', 1, 1353508551), 
(357, 'vi', 'shops', 'log_add_catalog', 'id 4', 'id 4', 1, 1353508562), 
(358, 'vi', 'shops', 'log_add_catalog', 'id 5', 'id 5', 1, 1353508572), 
(359, 'vi', 'shops', 'log_add_catalog', 'id 6', 'id 6', 1, 1353508608), 
(360, 'vi', 'shops', 'log_add_catalog', 'id 7', 'id 7', 1, 1353508644), 
(361, 'vi', 'shops', 'log_add_catalog', 'id 8', 'id 8', 1, 1353508655), 
(362, 'vi', 'shops', 'log_add_catalog', 'id 9', 'id 9', 1, 1353508676), 
(363, 'vi', 'shops', 'log_add_catalog', 'id 10', 'id 10', 1, 1353508682), 
(364, 'vi', 'shops', 'log_add_catalog', 'id 11', 'id 11', 1, 1353508690), 
(365, 'vi', 'shops', 'log_add_catalog', 'id 12', 'id 12', 1, 1353508704), 
(366, 'vi', 'shops', 'log_add_catalog', 'id 13', 'id 13', 1, 1353508721), 
(367, 'vi', 'shops', 'log_add_catalog', 'id 14', 'id 14', 1, 1353508750), 
(368, 'vi', 'shops', 'log_add_catalog', 'id 15', 'id 15', 1, 1353508778), 
(369, 'vi', 'shops', 'log_add_catalog', 'id 16', 'id 16', 1, 1353508789), 
(370, 'vi', 'shops', 'log_add_catalog', 'id 17', 'id 17', 1, 1353508796), 
(371, 'vi', 'shops', 'log_add_catalog', 'id 18', 'id 18', 1, 1353508807), 
(372, 'vi', 'shops', 'log_add_catalog', 'id 19', 'id 19', 1, 1353508813), 
(373, 'vi', 'shops', 'log_add_catalog', 'id 20', 'id 20', 1, 1353508822), 
(374, 'vi', 'shops', 'log_add_catalog', 'id 21', 'id 21', 1, 1353508837), 
(375, 'vi', 'shops', 'log_add_catalog', 'id 22', 'id 22', 1, 1353508843), 
(376, 'vi', 'shops', 'log_add_catalog', 'id 23', 'id 23', 1, 1353508846), 
(377, 'vi', 'shops', 'log_add_catalog', 'id 24', 'id 24', 1, 1353508859), 
(378, 'vi', 'shops', 'log_add_catalog', 'id 25', 'id 25', 1, 1353508866), 
(379, 'vi', 'shops', 'log_add_catalog', 'id 26', 'id 26', 1, 1353508872), 
(380, 'vi', 'shops', 'log_add_catalog', 'id 27', 'id 27', 1, 1353508893), 
(381, 'vi', 'shops', 'log_add_catalog', 'id 28', 'id 28', 1, 1353508900), 
(382, 'vi', 'shops', 'log_add_catalog', 'id 29', 'id 29', 1, 1353508907), 
(383, 'vi', 'shops', 'log_add_catalog', 'id 30', 'id 30', 1, 1353508917), 
(384, 'vi', 'shops', 'log_add_catalog', 'id 31', 'id 31', 1, 1353508924), 
(385, 'vi', 'shops', 'log_add_catalog', 'id 32', 'id 32', 1, 1353508930), 
(386, 'vi', 'shops', 'log_add_catalog', 'id 33', 'id 33', 1, 1353508945), 
(387, 'vi', 'shops', 'log_add_catalog', 'id 34', 'id 34', 1, 1353508951), 
(388, 'vi', 'shops', 'log_add_catalog', 'id 35', 'id 35', 1, 1353508956), 
(389, 'vi', 'shops', 'Cấu hình module', 'Setting', 'Setting', 1, 1353509144), 
(390, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1353509172), 
(391, 'vi', 'themes', 'Sửa block', 'Name : global block search', 'Name : global block search', 1, 1353509209), 
(392, 'vi', 'shops', 'Thêm nhóm tour', 'TRONG NƯỚC', 'TRONG NƯỚC', 1, 1353509447), 
(393, 'vi', 'shops', 'Thêm nhóm tour', 'NƯỚC NGOÀI', 'NƯỚC NGOÀI', 1, 1353509475), 
(394, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Phan Thiết', 'Tour Phan Thiết', 1, 1353509771), 
(395, 'vi', 'shops', 'Thêm nhóm tour', 'Tour miền Trung', 'Tour miền Trung', 1, 1353509780), 
(396, 'vi', 'shops', 'Thêm nhóm tour', 'Tour miền Bắc', 'Tour miền Bắc', 1, 1353509785), 
(397, 'vi', 'shops', 'Thêm nhóm tour', 'Tour miền Tây Nam Bộ', 'Tour miền Tây Nam Bộ', 1, 1353509792), 
(398, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Đà Lạt', 'Tour Đà Lạt', 1, 1353509799), 
(399, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Phú Quốc', 'Tour Phú Quốc', 1, 1353509807), 
(400, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Hạ Long', 'Tour Hạ Long', 1, 1353509817), 
(401, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Sa Pa', 'Tour Sa Pa', 1, 1353509825), 
(402, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Đà Nẵng', 'Tour Đà Nẵng', 1, 1353509832), 
(403, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Hội An', 'Tour Hội An', 1, 1353509838), 
(404, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Campuchia', 'Tour Campuchia', 1, 1353509849), 
(405, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Thái Lan', 'Tour Thái Lan', 1, 1353509857), 
(406, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Malaysia', 'Tour Malaysia', 1, 1353509863), 
(407, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Singapore', 'Tour Singapore', 1, 1353509867), 
(408, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Hong Kong', 'Tour Hong Kong', 1, 1353509873), 
(409, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Trung Quốc', 'Tour Trung Quốc', 1, 1353509884), 
(410, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Hàn Quốc', 'Tour Hàn Quốc', 1, 1353509893), 
(411, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Nhật Bản', 'Tour Nhật Bản', 1, 1353509899), 
(412, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Mỹ', 'Tour Mỹ', 1, 1353509907), 
(413, 'vi', 'shops', 'Thêm nhóm tour', 'Tour Châu Âu', 'Tour Châu Âu', 1, 1353509913), 
(414, 'vi', 'shops', 'Thêm nhóm tour', 'THEO NGÀY', 'THEO NGÀY', 1, 1353509948), 
(415, 'vi', 'shops', 'Thêm nhóm tour', 'LOẠI HÌNH TOUR', 'LOẠI HÌNH TOUR', 1, 1353509953), 
(416, 'vi', 'shops', 'Thêm nhóm tour', '1 Ngày', '1 Ngày', 1, 1353509961), 
(417, 'vi', 'shops', 'Thêm nhóm tour', '2 Ngày 1 Đêm', '2 Ngày 1 Đêm', 1, 1353510049), 
(418, 'vi', 'shops', 'Thêm nhóm tour', '3 Ngày 2 Đêm', '3 Ngày 2 Đêm', 1, 1353510064), 
(419, 'vi', 'shops', 'Thêm nhóm tour', '4 Ngày 3 Đêm', '4 Ngày 3 Đêm', 1, 1353510069), 
(420, 'vi', 'shops', 'Thêm nhóm tour', '5 Ngày 4 Đêm', '5 Ngày 4 Đêm', 1, 1353510074), 
(421, 'vi', 'shops', 'Thêm nhóm tour', '6 Ngày 5 Đêm', '6 Ngày 5 Đêm', 1, 1353510080), 
(422, 'vi', 'shops', 'Thêm nhóm tour', '7 Ngày 6 Đêm', '7 Ngày 6 Đêm', 1, 1353510098), 
(423, 'vi', 'shops', 'Thêm nhóm tour', 'Du lịch biển', 'Du lịch biển', 1, 1353510130), 
(424, 'vi', 'shops', 'Thêm nhóm tour', 'Du lịch trăng mật', 'Du lịch trăng mật', 1, 1353510137), 
(425, 'vi', 'shops', 'Thêm nhóm tour', 'Du lịch dã ngoại', 'Du lịch dã ngoại', 1, 1353510145), 
(426, 'vi', 'shops', 'Thêm nhóm tour', 'Du lịch xuyên Việt', 'Du lịch xuyên Việt', 1, 1353510150), 
(427, 'vi', 'shops', 'Thêm nhóm tour', 'Du lịch hè', 'Du lịch hè', 1, 1353510157), 
(428, 'vi', 'shops', 'Thêm nhóm tour', 'Du lịch cao cấp', 'Du lịch cao cấp', 1, 1353510162), 
(429, 'vi', 'shops', 'Thêm nhóm tour', 'Du lịch cuối tuần', 'Du lịch cuối tuần', 1, 1353510169), 
(430, 'vi', 'upload', 'Upload file', 'uploads/shops/source/2101bephiendai_timnhanh-4.jpg', 'uploads/shops/source/2101bephiendai_timnhanh-4.jpg', 1, 1353510305), 
(431, 'vi', 'upload', 'Upload file', 'uploads/shops/2012_11/19-nha-bep-1345569741_480x0.jpg', 'uploads/shops/2012_11/19-nha-bep-1345569741_480x0.jpg', 1, 1353510411), 
(432, 'vi', 'shops', 'Add A Product', 'ID: 1', 'ID: 1', 1, 1353510482), 
(433, 'vi', 'themes', 'Thêm block', 'Name : global block group', 'Name : global block group', 1, 1353510565), 
(434, 'vi', 'upload', 'Upload file', 'uploads/shops/2012_11/2101bephiendai_timnhanh-4.jpg', 'uploads/shops/2012_11/2101bephiendai_timnhanh-4.jpg', 1, 1353510639), 
(435, 'vi', 'shops', 'Add A Product', 'ID: 2', 'ID: 2', 1, 1353510701), 
(436, 'vi', 'shops', 'log_add_catalog', 'id 36', 'id 36', 1, 1353511573), 
(437, 'vi', 'shops', 'Add A Product', 'ID: 3', 'ID: 3', 1, 1353512677), 
(438, 'vi', 'shops', 'Add A Product', 'ID: 4', 'ID: 4', 1, 1353512940), 
(439, 'vi', 'shops', 'Add A Product', 'ID: 5', 'ID: 5', 1, 1353513293), 
(440, 'vi', 'shops', 'Add A Product', 'ID: 6', 'ID: 6', 1, 1353513410), 
(441, 'vi', 'shops', 'Add A Product', 'ID: 7', 'ID: 7', 1, 1353513520), 
(442, 'vi', 'shops', 'Edit A Product', 'ID: 7', 'ID: 7', 1, 1353513550), 
(443, 'vi', 'shops', 'Add A Product', 'ID: 8', 'ID: 8', 1, 1353513629), 
(444, 'vi', 'shops', 'Add A Product', 'ID: 9', 'ID: 9', 1, 1353513715), 
(445, 'vi', 'shops', 'Add A Product', 'ID: 10', 'ID: 10', 1, 1353513783), 
(446, 'vi', 'shops', 'Add A Product', 'ID: 11', 'ID: 11', 1, 1353513830), 
(447, 'vi', 'themes', 'Thêm block', 'Name : THUÊ XE', 'Name : THUÊ XE', 1, 1353513904), 
(448, 'vi', 'shops', 'Add A Product', 'ID: 12', 'ID: 12', 1, 1353513976), 
(449, 'vi', 'shops', 'Add A Product', 'ID: 13', 'ID: 13', 1, 1353514017), 
(450, 'vi', 'themes', 'Sửa block', 'Name : CHO THUÊ XE', 'Name : CHO THUÊ XE', 1, 1353514072), 
(451, 'vi', 'themes', 'Sửa block', 'Name : TEAM BUILDING', 'Name : TEAM BUILDING', 1, 1353514090), 
(452, 'vi', 'themes', 'Sửa block', 'Name : CHO THUÊ XE', 'Name : CHO THUÊ XE', 1, 1353514115), 
(453, 'vi', 'shops', 'Add A Product', 'ID: 14', 'ID: 14', 1, 1353514188), 
(454, 'vi', 'menu', 'De-lete menu item', 'Item ID  13', 'Item ID  13', 1, 1353514566), 
(455, 'vi', 'menu', 'De-lete menu item', 'Item ID  14', 'Item ID  14', 1, 1353514569), 
(456, 'vi', 'modules', 'Cài lại module \"tour\"', '', '', 1, 1353515158), 
(457, 'vi', 'modules', 'Thứ tự module \"shops\"', '14 -> 1', '14 -> 1', 1, 1353515165), 
(458, 'vi', 'modules', 'Sửa module &ldquo;tour&rdquo;', '', '', 1, 1353515217), 
(459, 'vi', 'themes', 'Thêm block', 'Name : TIN DU LỊCH', 'Name : TIN DU LỊCH', 1, 1353515294), 
(460, 'vi', 'themes', 'Sửa block', 'Name : TIN DU LỊCH', 'Name : TIN DU LỊCH', 1, 1353515307), 
(461, 'vi', 'themes', 'Sửa block', 'Name : global block group', 'Name : global block group', 1, 1353515670), 
(462, 'vi', 'themes', 'Sửa block', 'Name : TIN DU LỊCH', 'Name : TIN DU LỊCH', 1, 1353515781), 
(463, 'vi', 'themes', 'Sửa block', 'Name : global block search', 'Name : global block search', 1, 1353515800), 
(464, 'vi', 'themes', 'Sửa block', 'Name : CHO THUÊ XE', 'Name : CHO THUÊ XE', 1, 1353515877), 
(465, 'vi', 'themes', 'Sửa block', 'Name : global block search', 'Name : global block search', 1, 1353515937), 
(466, 'vi', 'themes', 'Thêm block', 'Name : THUÊ XE', 'Name : THUÊ XE', 1, 1353516029), 
(467, 'vi', 'themes', 'Sửa block', 'Name : THUÊ XE', 'Name : THUÊ XE', 1, 1353516155), 
(468, 'vi', 'themes', 'Sửa block', 'Name : THUÊ XE', 'Name : THUÊ XE', 1, 1353516215), 
(469, 'vi', 'themes', 'Sửa block', 'Name : THUÊ XE', 'Name : THUÊ XE', 1, 1353516260), 
(470, 'vi', 'themes', 'Sửa block', 'Name : global block group', 'Name : global block group', 1, 1353516365), 
(471, 'vi', 'themes', 'Sửa block', 'Name : THUÊ XE', 'Name : THUÊ XE', 1, 1353516515), 
(472, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.19.118.12', ' Client IP:123.19.118.12', 0, 1354108466), 
(473, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.165.107.220', ' Client IP:113.165.107.220', 0, 1354349092), 
(474, 'vi', 'themes', 'Thêm block', 'Name : global block product center', 'Name : global block product center', 1, 1354349152), 
(475, 'vi', 'themes', 'Sửa block', 'Name : global block product center', 'Name : global block product center', 1, 1354349209), 
(476, 'vi', 'themes', 'Sửa block', 'Name : global block product center', 'Name : global block product center', 1, 1354349346), 
(477, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.19.113.239', ' Client IP:123.19.113.239', 0, 1354427622), 
(478, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1375539489), 
(479, 'vi', 'banners', 'log_del_banner', 'bannerid 3', 'bannerid 3', 1, 1375539519), 
(480, 'vi', 'banners', 'log_del_banner', 'bannerid 2', 'bannerid 2', 1, 1375539521), 
(481, 'vi', 'banners', 'log_del_banner', 'bannerid 1', 'bannerid 1', 1, 1375539524), 
(482, 'vi', 'banners', 'log_del_plan', 'planid 1', 'planid 1', 1, 1375539529), 
(483, 'vi', 'banners', 'log_edit_plan', 'planid 2', 'planid 2', 1, 1375539550), 
(484, 'vi', 'banners', 'log_add_banner', 'bannerid 4', 'bannerid 4', 1, 1375539875), 
(485, 'vi', 'banners', 'log_add_banner', 'bannerid 5', 'bannerid 5', 1, 1375539907), 
(486, 'vi', 'themes', 'Sửa block', 'Name : global banners slide', 'Name : global banners slide', 1, 1375539945), 
(487, 'vi', 'themes', 'Sửa block', 'Name : global banners slide', 'Name : global banners slide', 1, 1375540009), 
(488, 'vi', 'banners', 'log_add_banner', 'bannerid 6', 'bannerid 6', 1, 1375540124), 
(489, 'vi', 'themes', 'Sửa block', 'Name : global banners slide', 'Name : global banners slide', 1, 1375540377), 
(490, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1375540418), 
(491, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1375540453), 
(492, 'vi', 'themes', 'Đóng gói theo tên theme', 'file name : anhmai_datviet.zip', 'file name : anhmai_datviet.zip', 1, 1375541876), 
(493, 'vi', 'users', 'log_edit_user', 'userid 1', 'userid 1', 1, 1375542624), 
(494, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1417055027), 
(495, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1417055148), 
(496, 'vi', 'shops', 'Cấu hình module', 'Setting', 'Setting', 1, 1417060828), 
(497, 'vi', 'shops', 'Cấu hình module', 'Setting', 'Setting', 1, 1417060846), 
(498, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1417855755), 
(499, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1417855770), 
(500, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1417855837), 
(501, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1417855889), 
(502, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1417855908), 
(503, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1417872450), 
(504, 'vi', 'themes', 'Sửa block', 'Name : global block search', 'Name : global block search', 1, 1417872592), 
(505, 'vi', 'themes', 'Sửa block', 'Name : global block group', 'Name : global block group', 1, 1417872625), 
(506, 'vi', 'themes', 'Sửa block', 'Name : TIN DU LỊCH', 'Name : TIN DU LỊCH', 1, 1417872649), 
(507, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1417872752), 
(508, 'vi', 'banners', 'log_edit_banner', 'bannerid 6', 'bannerid 6', 1, 1417872986), 
(509, 'vi', 'banners', 'log_edit_banner', 'bannerid 5', 'bannerid 5', 1, 1417873016), 
(510, 'vi', 'banners', 'log_edit_banner', 'bannerid 4', 'bannerid 4', 1, 1417873037), 
(511, 'vi', 'banners', 'log_edit_banner', 'bannerid 6', 'bannerid 6', 1, 1417873053), 
(512, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1417875886), 
(513, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1417875905), 
(514, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1417875923), 
(515, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1417875935), 
(516, 'vi', 'menu', 'De-lete menu item', 'Item ID  26', 'Item ID  26', 1, 1417876881), 
(517, 'vi', 'menu', 'De-lete menu item', 'Item ID  25', 'Item ID  25', 1, 1417876928), 
(518, 'vi', 'menu', 'De-lete menu item', 'Item ID  21', 'Item ID  21', 1, 1417876938), 
(519, 'vi', 'menu', 'De-lete menu item', 'Item ID  27', 'Item ID  27', 1, 1417876946), 
(520, 'vi', 'upload', 'Xóa file', 'uploads/sologan.png', 'uploads/sologan.png', 1, 1417878405), 
(521, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1417878436), 
(522, 'vi', 'themes', 'Thêm block', 'Name : global html', 'Name : global html', 1, 1417879962), 
(523, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1417879974), 
(524, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1417880039), 
(525, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1417880054), 
(526, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1417880084), 
(527, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1417959488), 
(528, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1418003934), 
(529, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1418004242), 
(530, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1418005677), 
(531, 'vi', 'menu', 'De-lete menu item', 'Item ID  24', 'Item ID  24', 1, 1418006862), 
(532, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1418008100), 
(533, 'vi', 'banners', 'log_edit_plan', 'planid 2', 'planid 2', 1, 1418012736), 
(534, 'vi', 'banners', 'log_edit_plan', 'planid 2', 'planid 2', 1, 1418012758), 
(535, 'vi', 'banners', 'log_edit_plan', 'planid 2', 'planid 2', 1, 1418012803), 
(536, 'vi', 'banners', 'log_add_banner', 'bannerid 7', 'bannerid 7', 1, 1418012869), 
(537, 'vi', 'banners', 'log_edit_plan', 'planid 2', 'planid 2', 1, 1418012907), 
(538, 'vi', 'banners', 'log_edit_plan', 'planid 2', 'planid 2', 1, 1418012937), 
(539, 'vi', 'themes', 'Sửa block', 'Name : Xe dịch vụ', 'Name : Xe dịch vụ', 1, 1418013709), 
(540, 'vi', 'themes', 'Thêm block', 'Name : global plugin sticky navbar', 'Name : global plugin sticky navbar', 1, 1418028407), 
(541, 'vi', 'themes', 'Sửa block', 'Name : global plugin sticky navbar', 'Name : global plugin sticky navbar', 1, 1418028485), 
(542, 'vi', 'themes', 'Sửa block', 'Name : global plugin sticky navbar', 'Name : global plugin sticky navbar', 1, 1418028500), 
(543, 'vi', 'modules', 'Cài đặt gói Module + Block', 'nv3-module-home.zip', 'nv3-module-home.zip', 1, 1418097666), 
(544, 'vi', 'modules', 'Thiết lập module mới home\"', '', '', 1, 1418097685), 
(545, 'vi', 'modules', 'Sửa module &ldquo;home&rdquo;', '', '', 1, 1418097700), 
(546, 'vi', 'modules', 'Thứ tự module \"home\"', '15 -> 1', '15 -> 1', 1, 1418097705), 
(547, 'vi', 'menu', 'De-lete menu item', 'Item ID  47', 'Item ID  47', 1, 1418098143), 
(548, 'vi', 'themes', 'Sửa block', 'Name : global block search', 'Name : global block search', 1, 1418098741), 
(549, 'vi', 'themes', 'Sửa block', 'Name : TIN DU LỊCH', 'Name : TIN DU LỊCH', 1, 1418098754), 
(550, 'vi', 'upload', 'Upload file', 'uploads/silide/du-lich-tet-2015-dd97d284d1.jpg', 'uploads/silide/du-lich-tet-2015-dd97d284d1.jpg', 1, 1418099209), 
(551, 'vi', 'upload', 'Upload file', 'uploads/silide/du-lich-tet-duong-lich-2015-16657f3fe0.png', 'uploads/silide/du-lich-tet-duong-lich-2015-16657f3fe0.png', 1, 1418099213), 
(552, 'vi', 'upload', 'Upload file', 'uploads/silide/thue-xe-du-lich-tet1-43efc4f6c7.jpg', 'uploads/silide/thue-xe-du-lich-tet1-43efc4f6c7.jpg', 1, 1418099218), 
(553, 'vi', 'upload', 'Upload file', 'uploads/silide/banner.jpg', 'uploads/silide/banner.jpg', 1, 1418099226), 
(554, 'vi', 'themes', 'Thêm block', 'Name : Slide home', 'Name : Slide home', 1, 1418099597), 
(555, 'vi', 'themes', 'Sửa block', 'Name : Slide home', 'Name : Slide home', 1, 1418099614), 
(556, 'vi', 'themes', 'Sửa block', 'Name : Slide home', 'Name : Slide home', 1, 1418099721), 
(557, 'vi', 'modules', 'Cài lại module \"silide\"', '', '', 1, 1418100607), 
(558, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1418100736), 
(559, 'vi', 'modules', 'Cài đặt gói Module + Block', 'nv3_module_silide.zip', 'nv3_module_silide.zip', 1, 1418100806), 
(560, 'vi', 'modules', 'Kích hoạt module \"silide\"', 'Có', 'Có', 1, 1418100964), 
(561, 'vi', 'modules', 'Cài lại module \"silide\"', '', '', 1, 1418100981), 
(562, 'vi', 'modules', 'Sửa module &ldquo;silide&rdquo;', '', '', 1, 1418101000), 
(563, 'vi', 'themes', 'Sửa block', 'Name : Slide home', 'Name : Slide home', 1, 1418101095), 
(564, 'vi', 'upload', 'Upload file', 'uploads/silide/du-lich-tet-2015-dd97d284d1.jpg', 'uploads/silide/du-lich-tet-2015-dd97d284d1.jpg', 1, 1418101119), 
(565, 'vi', 'upload', 'Upload file', 'uploads/silide/du-lich-tet-duong-lich-2015-16657f3fe0.png', 'uploads/silide/du-lich-tet-duong-lich-2015-16657f3fe0.png', 1, 1418101122), 
(566, 'vi', 'upload', 'Upload file', 'uploads/silide/thue-xe-du-lich-tet1-43efc4f6c7.jpg', 'uploads/silide/thue-xe-du-lich-tet1-43efc4f6c7.jpg', 1, 1418101126), 
(567, 'vi', 'upload', 'Upload file', 'uploads/silide/banner.jpg', 'uploads/silide/banner.jpg', 1, 1418101135), 
(568, 'vi', 'themes', 'Sửa block', 'Name : Slide home', 'Name : Slide home', 1, 1418101188), 
(569, 'vi', 'themes', 'Sửa block', 'Name : Slide home', 'Name : Slide home', 1, 1418101241), 
(570, 'vi', 'themes', 'Sửa block', 'Name : Slide home', 'Name : Slide home', 1, 1418103615), 
(571, 'vi', 'themes', 'Sửa block', 'Name : Slide home', 'Name : Slide home', 1, 1418104101), 
(572, 'vi', 'banners', 'log_add_plan', 'planid 3', 'planid 3', 1, 1418104185), 
(573, 'vi', 'banners', 'log_add_banner', 'bannerid 8', 'bannerid 8', 1, 1418104218), 
(574, 'vi', 'banners', 'log_add_banner', 'bannerid 9', 'bannerid 9', 1, 1418104233), 
(575, 'vi', 'banners', 'log_add_banner', 'bannerid 10', 'bannerid 10', 1, 1418104251), 
(576, 'vi', 'banners', 'log_add_banner', 'bannerid 11', 'bannerid 11', 1, 1418104274), 
(577, 'vi', 'themes', 'Thêm block', 'Name : banner-home', 'Name : banner-home', 1, 1418104413), 
(578, 'vi', 'themes', 'Sửa block', 'Name : banner-home', 'Name : banner-home', 1, 1418104427), 
(579, 'vi', 'banners', 'log_edit_plan', 'planid 3', 'planid 3', 1, 1418104982), 
(580, 'vi', 'banners', 'log_edit_plan', 'planid 3', 'planid 3', 1, 1418105000), 
(581, 'vi', 'banners', 'log_edit_plan', 'planid 3', 'planid 3', 1, 1418105032), 
(582, 'vi', 'banners', 'log_edit_plan', 'planid 3', 'planid 3', 1, 1418105059), 
(583, 'vi', 'banners', 'log_edit_plan', 'planid 3', 'planid 3', 1, 1418105093), 
(584, 'vi', 'themes', 'Sửa block', 'Name : banner-home', 'Name : banner-home', 1, 1418105643), 
(585, 'vi', 'banners', 'log_del_banner', 'bannerid 10', 'bannerid 10', 1, 1418107117), 
(586, 'vi', 'banners', 'log_edit_banner', 'bannerid 11', 'bannerid 11', 1, 1418107706), 
(587, 'vi', 'modules', 'Cài đặt gói Module + Block', 'block group marquee.zip', 'block group marquee.zip', 1, 1418130902), 
(588, 'vi', 'themes', 'Sửa block', 'Name : banner-home', 'Name : banner-home', 1, 1418131042), 
(589, 'vi', 'banners', 'log_del_banner', 'bannerid 11', 'bannerid 11', 1, 1418131303), 
(590, 'vi', 'banners', 'log_del_banner', 'bannerid 9', 'bannerid 9', 1, 1418131308), 
(591, 'vi', 'banners', 'log_del_banner', 'bannerid 8', 'bannerid 8', 1, 1418131313), 
(592, 'vi', 'banners', 'log_add_banner', 'bannerid 12', 'bannerid 12', 1, 1418131422), 
(593, 'vi', 'banners', 'log_add_banner', 'bannerid 13', 'bannerid 13', 1, 1418131447), 
(594, 'vi', 'banners', 'log_add_banner', 'bannerid 14', 'bannerid 14', 1, 1418131480), 
(595, 'vi', 'banners', 'log_add_banner', 'bannerid 15', 'bannerid 15', 1, 1418131518), 
(596, 'vi', 'banners', 'log_add_banner', 'bannerid 16', 'bannerid 16', 1, 1418131552), 
(597, 'vi', 'banners', 'log_add_banner', 'bannerid 17', 'bannerid 17', 1, 1418131581), 
(598, 'vi', 'themes', 'Thêm block', 'Name : global news style catid', 'Name : global news style catid', 1, 1418137188), 
(599, 'vi', 'modules', 'Sửa module &ldquo;news&rdquo;', '', '', 1, 1418137223), 
(600, 'vi', 'modules', 'Thứ tự module \"voting\"', '15 -> 11', '15 -> 11', 1, 1418137235), 
(601, 'vi', 'modules', 'Thứ tự module \"banners\"', '15 -> 7', '15 -> 7', 1, 1418137242), 
(602, 'vi', 'news', 'Sửa bài viết', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1418137339), 
(603, 'vi', 'themes', 'Sửa block', 'Name : global news style catid', 'Name : global news style catid', 1, 1418137346), 
(604, 'vi', 'news', 'Sửa bài viết', 'NukeViet - Công cụ mã nguồn mở cho cộng đồng thiết kế website Việt Nam', 'NukeViet - Công cụ mã nguồn mở cho cộng đồng thiết kế website Việt Nam', 1, 1418137360), 
(605, 'vi', 'themes', 'Sửa block', 'Name : global news style catid', 'Name : global news style catid', 1, 1418137388), 
(606, 'vi', 'modules', 'Cài đặt gói Module + Block', 'nv3_module_silide.zip', 'nv3_module_silide.zip', 1, 1418138482), 
(607, 'vi', 'themes', 'Sửa block', 'Name : banner-home', 'Name : banner-home', 1, 1418138618), 
(608, 'vi', 'themes', 'Sửa block', 'Name : banner-home', 'Name : banner-home', 1, 1418138662), 
(609, 'vi', 'modules', 'Thứ tự module \"silide\"', '15 -> 9', '15 -> 9', 1, 1418138672), 
(610, 'vi', 'themes', 'Thêm block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418138778), 
(611, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418138812), 
(612, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418138841), 
(613, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418138879), 
(614, 'vi', 'themes', 'Thêm block', 'Name : global block group', 'Name : global block group', 1, 1418138941), 
(615, 'vi', 'themes', 'Sửa block', 'Name : global block group', 'Name : global block group', 1, 1418139004), 
(616, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418139095), 
(617, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418139114), 
(618, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418139129), 
(619, 'vi', 'themes', 'Thêm block', 'Name : Giỏ hàng', 'Name : Giỏ hàng', 1, 1418139185), 
(620, 'vi', 'modules', 'Thứ tự module \"about\"', '15 -> 1', '15 -> 1', 1, 1418139195), 
(621, 'vi', 'shops', 'Cấu hình module', 'Setting', 'Setting', 1, 1418139310), 
(622, 'vi', 'shops', 'Cấu hình module', 'Setting', 'Setting', 1, 1418139324), 
(623, 'vi', 'themes', 'Sửa block', 'Name : Giỏ hàng', 'Name : Giỏ hàng', 1, 1418139411), 
(624, 'vi', 'themes', 'Thêm block', 'Name : left-footer', 'Name : left-footer', 1, 1418140595), 
(625, 'vi', 'themes', 'Sửa block', 'Name : left-footer', 'Name : left-footer', 1, 1418140636), 
(626, 'vi', 'themes', 'Thêm block', 'Name : right-footer', 'Name : right-footer', 1, 1418140996), 
(627, 'vi', 'themes', 'Sửa block', 'Name : right-footer', 'Name : right-footer', 1, 1418141008), 
(628, 'vi', 'modules', 'Xóa module \"tour\"', '', '', 1, 1418176810), 
(629, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1418176878), 
(630, 'vi', 'modules', 'Sửa module &ldquo;rental&rdquo;', '', '', 1, 1418176905), 
(631, 'vi', 'modules', 'Sửa module &ldquo;news&rdquo;', '', '', 1, 1418176920), 
(632, 'vi', 'modules', 'Kích hoạt module \"silide\"', 'Không', 'Không', 1, 1418176954), 
(633, 'vi', 'modules', 'Sửa module &ldquo;users&rdquo;', '', '', 1, 1418176993), 
(634, 'vi', 'banners', 'log_del_banner', 'bannerid 6', 'bannerid 6', 1, 1418186754), 
(635, 'vi', 'banners', 'log_del_banner', 'bannerid 5', 'bannerid 5', 1, 1418186760), 
(636, 'vi', 'banners', 'log_del_banner', 'bannerid 4', 'bannerid 4', 1, 1418186765), 
(637, 'vi', 'banners', 'log_add_banner', 'bannerid 18', 'bannerid 18', 1, 1418186805), 
(638, 'vi', 'banners', 'log_add_banner', 'bannerid 19', 'bannerid 19', 1, 1418186825), 
(639, 'vi', 'banners', 'log_add_banner', 'bannerid 20', 'bannerid 20', 1, 1418186856), 
(640, 'vi', 'banners', 'log_edit_banner', 'bannerid 20', 'bannerid 20', 1, 1418186921), 
(641, 'vi', 'banners', 'log_edit_plan', 'planid 2', 'planid 2', 1, 1418186950), 
(642, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'KHÁCH SẠN', 'KHÁCH SẠN', 1, 1418199298), 
(643, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'KHÁCH HÀNG', 'KHÁCH HÀNG', 1, 1418199309), 
(644, 'vi', 'themes', 'Thêm block', 'Name : News center', 'Name : News center', 1, 1418199485), 
(645, 'vi', 'themes', 'Sửa block', 'Name : News center', 'Name : News center', 1, 1418199855), 
(646, 'vi', 'shops', 'log_edit_catalog', 'id 1', 'id 1', 1, 1418201728), 
(647, 'vi', 'shops', 'log_edit_catalog', 'id 1', 'id 1', 1, 1418201741), 
(648, 'vi', 'shops', 'log_edit_catalog', 'id 2', 'id 2', 1, 1418201765), 
(649, 'vi', 'upload', 'Xóa file', 'uploads/footer_right.png', 'uploads/footer_right.png', 1, 1418215963), 
(650, 'vi', 'upload', 'Xóa file', 'uploads/footer_mid.png', 'uploads/footer_mid.png', 1, 1418215966), 
(651, 'vi', 'upload', 'Xóa file', 'uploads/logo-vinades.jpg', 'uploads/logo-vinades.jpg', 1, 1418215968), 
(652, 'vi', 'upload', 'Xóa file', 'uploads/footer_left.png', 'uploads/footer_left.png', 1, 1418215971), 
(653, 'vi', 'upload', 'Tạo folder', 'uploads/silide/social', 'uploads/silide/social', 1, 1418215984), 
(654, 'vi', 'upload', 'Xóa folder', 'uploads/silide/social', 'uploads/silide/social', 1, 1418215990), 
(655, 'vi', 'upload', 'Tạo folder', 'uploads/about/social', 'uploads/about/social', 1, 1418216003), 
(656, 'vi', 'upload', 'Xóa folder', 'uploads/about/social', 'uploads/about/social', 1, 1418216018), 
(657, 'vi', 'upload', 'Tạo folder', 'uploads/social', 'uploads/social', 1, 1418216029), 
(658, 'vi', 'upload', 'Upload file', 'uploads/social/facebook.gif', 'uploads/social/facebook.gif', 1, 1418216039), 
(659, 'vi', 'upload', 'Upload file', 'uploads/social/google-plus.jpg', 'uploads/social/google-plus.jpg', 1, 1418216042), 
(660, 'vi', 'upload', 'Upload file', 'uploads/social/tweeter.gif', 'uploads/social/tweeter.gif', 1, 1418216045), 
(661, 'vi', 'upload', 'Upload file', 'uploads/social/youtube.gif', 'uploads/social/youtube.gif', 1, 1418216049), 
(662, 'vi', 'upload', 'Upload file', 'uploads/social/rss-feed-icon.png', 'uploads/social/rss-feed-icon.png', 1, 1418216357), 
(663, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1418216707), 
(664, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1418216756), 
(665, 'vi', 'themes', 'Sửa block', 'Name : right-footer', 'Name : right-footer', 1, 1418216991), 
(666, 'vi', 'shops', 'log_edit_catalog', 'id 27', 'id 27', 1, 1418217154), 
(667, 'vi', 'shops', 'log_edit_catalog', 'id 30', 'id 30', 1, 1418217199), 
(668, 'vi', 'shops', 'log_edit_catalog', 'id 27', 'id 27', 1, 1418217215), 
(669, 'vi', 'shops', 'log_edit_catalog', 'id 33', 'id 33', 1, 1418217253), 
(670, 'vi', 'menu', 'De-lete menu item', 'Item ID  9', 'Item ID  9', 1, 1418217596), 
(671, 'vi', 'menu', 'De-lete menu item', 'Item ID  17', 'Item ID  17', 1, 1418217660), 
(672, 'vi', 'menu', 'De-lete menu item', 'Item ID  18', 'Item ID  18', 1, 1418217664), 
(673, 'vi', 'menu', 'De-lete menu item', 'Item ID  28', 'Item ID  28', 1, 1418217716), 
(674, 'vi', 'menu', 'De-lete menu item', 'Item ID  31', 'Item ID  31', 1, 1418217728), 
(675, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1418220000), 
(676, 'vi', 'themes', 'Sửa block', 'Name : global news style catid', 'Name : global news style catid', 1, 1418220461), 
(677, 'vi', 'themes', 'Sửa block', 'Name : global news style catid', 'Name : global news style catid', 1, 1418220491), 
(678, 'vi', 'themes', 'Sửa block', 'Name : global news style catid', 'Name : global news style catid', 1, 1418220506), 
(679, 'vi', 'themes', 'Thêm block', 'Name : global block tophits', 'Name : global block tophits', 1, 1418221160), 
(680, 'vi', 'themes', 'Sửa block', 'Name : global block tophits', 'Name : global block tophits', 1, 1418221175), 
(681, 'vi', 'themes', 'Thêm block', 'Name : tin home', 'Name : tin home', 1, 1418221720), 
(682, 'vi', 'themes', 'Thêm block', 'Name : tin home', 'Name : tin home', 1, 1418221796), 
(683, 'vi', 'themes', 'Thêm block', 'Name : tin home', 'Name : tin home', 1, 1418221906), 
(684, 'vi', 'themes', 'Sửa block', 'Name : tin home', 'Name : tin home', 1, 1418222066), 
(685, 'vi', 'modules', 'Cài đặt gói Module + Block', 'block-groups-slider.zip', 'block-groups-slider.zip', 1, 1418222191), 
(686, 'vi', 'modules', 'Cài đặt gói Module + Block', 'popupmodule.zip', 'popupmodule.zip', 1, 1418222225), 
(687, 'vi', 'modules', 'Cài đặt gói Module + Block', 'global-slide-content.zip', 'global-slide-content.zip', 1, 1418222250), 
(688, 'vi', 'modules', 'Cài đặt gói Module + Block', 'block-news-showbiz.zip', 'block-news-showbiz.zip', 1, 1418222294), 
(689, 'vi', 'modules', 'Thiết lập module mới popup\"', '', '', 1, 1418222396), 
(690, 'vi', 'modules', 'Sửa module &ldquo;popup&rdquo;', '', '', 1, 1418222416), 
(691, 'vi', 'modules', 'Thứ tự module \"popup\"', '15 -> 7', '15 -> 7', 1, 1418222425), 
(692, 'vi', 'themes', 'Sửa block', 'Name : tin home', 'Name : tin home', 1, 1418222605), 
(693, 'vi', 'news', 'Sửa bài viết', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1418222681), 
(694, 'vi', 'themes', 'Sửa block', 'Name : tin home', 'Name : tin home', 1, 1418222714), 
(695, 'vi', 'themes', 'Sửa block', 'Name : tin home', 'Name : tin home', 1, 1418223966), 
(696, 'vi', 'upload', 'Upload file', 'uploads/shops/2014_12/da-nang-giau-dep-van-minh-87e29.jpg', 'uploads/shops/2014_12/da-nang-giau-dep-van-minh-87e29.jpg', 1, 1418226056), 
(697, 'vi', 'shops', 'Edit A Product', 'ID: 14', 'ID: 14', 1, 1418226109), 
(698, 'vi', 'shops', 'log_del_product', 'id 11', 'id 11', 1, 1418226133), 
(699, 'vi', 'upload', 'Upload file', 'uploads/shops/2014_12/hongkongboat.jpg', 'uploads/shops/2014_12/hongkongboat.jpg', 1, 1418226211), 
(700, 'vi', 'shops', 'Edit A Product', 'ID: 10', 'ID: 10', 1, 1418226239), 
(701, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418226297), 
(702, 'vi', 'shops', 'Edit A Product', 'ID: 14', 'ID: 14', 1, 1418226305), 
(703, 'vi', 'shops', 'Edit A Product', 'ID: 10', 'ID: 10', 1, 1418226319), 
(704, 'vi', 'upload', 'Upload file', 'uploads/shops/2014_12/du-lich-hong-kong-kham-pha-khu-giai-tri-dineyland-11.jpg', 'uploads/shops/2014_12/du-lich-hong-kong-kham-pha-khu-giai-tri-dineyland-11.jpg', 1, 1418226452), 
(705, 'vi', 'shops', 'Edit A Product', 'ID: 9', 'ID: 9', 1, 1418226489), 
(706, 'vi', 'shops', 'Edit A Product', 'ID: 8', 'ID: 8', 1, 1418226510), 
(707, 'vi', 'shops', 'Edit A Product', 'ID: 7', 'ID: 7', 1, 1418226523), 
(708, 'vi', 'shops', 'Edit A Product', 'ID: 7', 'ID: 7', 1, 1418226539), 
(709, 'vi', 'upload', 'Upload file', 'uploads/shops/2014_12/images.jpg', 'uploads/shops/2014_12/images.jpg', 1, 1418226560), 
(710, 'vi', 'shops', 'Edit A Product', 'ID: 8', 'ID: 8', 1, 1418226570), 
(711, 'vi', 'shops', 'Edit A Product', 'ID: 9', 'ID: 9', 1, 1418226586), 
(712, 'vi', 'shops', 'Edit A Product', 'ID: 8', 'ID: 8', 1, 1418226596), 
(713, 'vi', 'upload', 'Upload file', 'uploads/shops/2014_12/hanoi-is-in-the-top-ten-most-favourite-places-for-cultural-tours.jpg', 'uploads/shops/2014_12/hanoi-is-in-the-top-ten-most-favourite-places-for-cultural-tours.jpg', 1, 1418226655), 
(714, 'vi', 'shops', 'Edit A Product', 'ID: 6', 'ID: 6', 1, 1418226695), 
(715, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418226777), 
(716, 'vi', 'shops', 'log_del_product', 'id 5', 'id 5', 1, 1418227012), 
(717, 'vi', 'upload', 'Upload file', 'uploads/shops/2014_12/banner-02-1080x349.jpg', 'uploads/shops/2014_12/banner-02-1080x349.jpg', 1, 1418227026), 
(718, 'vi', 'shops', 'Edit A Product', 'ID: 2', 'ID: 2', 1, 1418227052), 
(719, 'vi', 'upload', 'Upload file', 'uploads/shops/2014_12/sapa7.jpg', 'uploads/shops/2014_12/sapa7.jpg', 1, 1418227102), 
(720, 'vi', 'shops', 'Edit A Product', 'ID: 1', 'ID: 1', 1, 1418227140), 
(721, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418229257), 
(722, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418229272), 
(723, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418229605), 
(724, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418229628), 
(725, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418229735), 
(726, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418229965), 
(727, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418229979), 
(728, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418229995), 
(729, 'vi', 'themes', 'Sửa block', 'Name : Ẩm thực - văn hoá', 'Name : Ẩm thực - văn hoá', 1, 1418262995), 
(730, 'vi', 'themes', 'Sửa block', 'Name : Việt Nam - Đất nước - Con người', 'Name : Việt Nam - Đất nước - Con người', 1, 1418263131), 
(731, 'vi', 'themes', 'Sửa block', 'Name : Việt Nam - Đất nước - Con người', 'Name : Việt Nam - Đất nước - Con người', 1, 1418263251), 
(732, 'vi', 'themes', 'Sửa block', 'Name : Việt Nam - Đất nước - Con người', 'Name : Việt Nam - Đất nước - Con người', 1, 1418263285), 
(733, 'vi', 'themes', 'Sửa block', 'Name : Dịch vụ xe du lịch', 'Name : Dịch vụ xe du lịch', 1, 1418263477), 
(734, 'vi', 'themes', 'Sửa block', 'Name : global block relates product', 'Name : global block relates product', 1, 1418263582), 
(735, 'vi', 'themes', 'Sửa block', 'Name : global block search', 'Name : global block search', 1, 1418264144), 
(736, 'vi', 'themes', 'Thêm block', 'Name : Tìm xe', 'Name : Tìm xe', 1, 1418264180), 
(737, 'vi', 'themes', 'Sửa block', 'Name : Tìm xe', 'Name : Tìm xe', 1, 1418264394), 
(738, 'vi', 'themes', 'Sửa block', 'Name : block tour home', 'Name : block tour home', 1, 1418275098), 
(739, 'vi', 'themes', 'Sửa block', 'Name : block tour home', 'Name : block tour home', 1, 1418275254), 
(740, 'vi', 'rental', 'Edit A Product', 'ID: 3', 'ID: 3', 1, 1418281648), 
(741, 'vi', 'rental', 'Edit A Product', 'ID: 5', 'ID: 5', 1, 1418281971), 
(742, 'vi', 'themes', 'Sửa block', 'Name : right-footer', 'Name : right-footer', 1, 1418285975), 
(743, 'vi', 'themes', 'Sửa block', 'Name : right-footer', 'Name : right-footer', 1, 1418286628), 
(744, 'vi', 'themes', 'Thêm block', 'Name : Giỏ hàng - tour', 'Name : Giỏ hàng - tour', 1, 1418286853), 
(745, 'vi', 'themes', 'Thêm block', 'Name : Giỏ hàng - xe', 'Name : Giỏ hàng - xe', 1, 1418286918), 
(746, 'vi', 'themes', 'Sửa block', 'Name : Giỏ hàng - xe', 'Name : Giỏ hàng - xe', 1, 1418286936), 
(747, 'vi', 'rental', 'Edit A Product', 'ID: 5', 'ID: 5', 1, 1418287769), 
(748, 'vi', 'shops', 'Edit A Product', 'ID: 14', 'ID: 14', 1, 1418287862), 
(749, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1418287903), 
(750, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1418288047), 
(751, 'vi', 'users', 'log_edit_user', 'userid 1', 'userid 1', 1, 1418288125), 
(752, 'vi', 'users', 'log_edit_user', 'userid 1', 'userid 1', 1, 1418288153), 
(753, 'vi', 'modules', 'Sửa module &ldquo;rental&rdquo;', '', '', 1, 1418288201), 
(754, 'vi', 'themes', 'Sửa block', 'Name : Giỏ hàng - tour', 'Name : Giỏ hàng - tour', 1, 1418288324), 
(755, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1418288449), 
(756, 'vi', 'login', '[levietadmin] Đăng nhập', ' Client IP:117.7.237.94', ' Client IP:117.7.237.94', 0, 1418289121), 
(757, 'vi', 'themes', 'Sửa block', 'Name : global html', 'Name : global html', 1, 1418289298), 
(758, 'vi', 'themes', 'Sửa block', 'Name : right-footer', 'Name : right-footer', 1, 1418289496), 
(759, 'vi', 'themes', 'Sửa block', 'Name : right-footer', 'Name : right-footer', 1, 1418289532), 
(760, 'vi', 'login', '[levietadmin] Đăng nhập', ' Client IP:117.7.237.94', ' Client IP:117.7.237.94', 0, 1418344460), 
(761, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1418355796), 
(762, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1418356036), 
(763, 'vi', 'login', '[levietadmin] thoát khỏi tài khoản quản trị', ' Client IP:117.7.237.94', ' Client IP:117.7.237.94', 0, 1418364230), 
(764, 'vi', 'login', '[levietadmin] Đăng nhập', ' Client IP:117.7.237.94', ' Client IP:117.7.237.94', 0, 1418371514), 
(765, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1418371662), 
(766, 'vi', 'login', '[levietadmin] thoát khỏi tài khoản quản trị', ' Client IP:117.7.237.94', ' Client IP:117.7.237.94', 0, 1418371882), 
(767, 'vi', 'login', '[levietadmin] Đăng nhập', ' Client IP:117.7.237.94', ' Client IP:117.7.237.94', 0, 1418371926), 
(768, 'vi', 'themes', 'Sửa block', 'Name : right-footer', 'Name : right-footer', 1, 1418372305), 
(769, 'vi', 'login', '[levietadmin] Đăng nhập', ' Client IP:113.167.157.229', ' Client IP:113.167.157.229', 0, 1418474341), 
(770, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1418474920), 
(771, 'vi', 'login', '[levietadmin] Đăng nhập', ' Client IP:117.7.237.94', ' Client IP:117.7.237.94', 0, 1418612427), 
(772, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1418612592), 
(773, 'vi', 'login', '[levietadmin] Đăng nhập', ' Client IP:117.7.237.94', ' Client IP:117.7.237.94', 0, 1418956546), 
(774, 'vi', 'modules', 'Xóa module \"popup\"', '', '', 1, 1418956561), 
(775, 'vi', 'modules', 'Xóa module \"rental\"', '', '', 1, 1418956574), 
(776, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1418956695), 
(777, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1418956833);


-- ---------------------------------------


--
-- Table structure for table `vt_sessions`
--

DROP TABLE IF EXISTS `vt_sessions`;
CREATE TABLE `vt_sessions` (
  `session_id` varchar(50) DEFAULT NULL,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(100) NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_sessions`
--

INSERT INTO `vt_sessions` VALUES
('44b2798baf871fda1f3e613296489a883706153859', 0, 'guest', 1419064513);


-- ---------------------------------------


--
-- Table structure for table `vt_setup`
--

DROP TABLE IF EXISTS `vt_setup`;
CREATE TABLE `vt_setup` (
  `lang` char(2) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tables` varchar(255) NOT NULL,
  `version` varchar(100) NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_setup_language`
--

DROP TABLE IF EXISTS `vt_setup_language`;
CREATE TABLE `vt_setup_language` (
  `lang` char(2) NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_setup_language`
--

INSERT INTO `vt_setup_language` VALUES
('vi', 1);


-- ---------------------------------------


--
-- Table structure for table `vt_setup_modules`
--

DROP TABLE IF EXISTS `vt_setup_modules`;
CREATE TABLE `vt_setup_modules` (
  `title` varchar(55) NOT NULL,
  `is_sysmod` tinyint(1) NOT NULL DEFAULT '0',
  `virtual` tinyint(1) NOT NULL DEFAULT '0',
  `module_file` varchar(50) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `mod_version` varchar(50) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_setup_modules`
--

INSERT INTO `vt_setup_modules` VALUES
('about', 0, 1, 'about', 'about', '3.0.01 1287532800', 1351857075, 'VINADES (contact@vinades.vn)', ''), 
('banners', 1, 0, 'banners', 'banners', '3.0.01 1287532800', 1351857075, 'VINADES (contact@vinades.vn)', ''), 
('contact', 0, 1, 'contact', 'contact', '3.0.01 1287532800', 1351857075, 'VINADES (contact@vinades.vn)', ''), 
('news', 0, 1, 'news', 'news', '3.0.01 1287532800', 1351857075, 'VINADES (contact@vinades.vn)', ''), 
('voting', 0, 0, 'voting', 'voting', '3.1.01 1287532800', 1351857075, 'VINADES (contact@vinades.vn)', ''), 
('forum', 0, 0, 'forum', 'forum', '3.0.01 1287532800', 1351857075, 'VINADES (contact@vinades.vn)', ''), 
('search', 1, 0, 'search', 'search', '3.0.01 1287532800', 1351857075, 'VINADES (contact@vinades.vn)', ''), 
('users', 1, 0, 'users', 'users', '3.0.01 1287532800', 1351857075, 'VINADES (contact@vinades.vn)', ''), 
('download', 0, 1, 'download', 'download', '3.0.01 1287532800', 1351857075, 'VINADES (contact@vinades.vn)', ''), 
('weblinks', 0, 1, 'weblinks', 'weblinks', '3.0.01 1287532800', 1351857075, 'VINADES (contact@vinades.vn)', ''), 
('statistics', 0, 0, 'statistics', 'statistics', '3.0.01 1287532800', 1351857075, 'VINADES (contact@vinades.vn)', ''), 
('faq', 0, 1, 'faq', 'faq', '3.0.01 1287532800', 1351857075, 'VINADES (contact@vinades.vn)', ''), 
('menu', 0, 1, 'menu', 'menu', '3.1.00 1273225635', 1351857075, 'VINADES (contact@vinades.vn)', ''), 
('rss', 1, 0, 'rss', 'rss', '3.0.01 1287532800', 1351857075, 'VINADES (contact@vinades.vn)', ''), 
('shops', 0, 1, 'shops', 'shops', '3.0.01 1273830435', 1352906423, 'VINADES (contact@vinades.vn)', ''), 
('popup', 0, 0, 'popup', 'popup', '3.0.1 1395373496', 1418222393, 'VINADES (contact@vinades.vn)', ''), 
('rental', 0, 1, 'rental', 'rental', '3.4.01 1352592000', 1353340129, 'VINADES (contact@vinades.vn)', ''), 
('silide', 1, 1, 'silide', 'silide', '3.2.0 1319330195', 1353343347, 'Nhoc.Maru@yahoo.com.vn', ''), 
('home', 0, 0, 'home', 'home', '3.4.01 1371254400', 1418097674, 'Phan Tan Dung (phantandung92@gmail.com)', '');


-- ---------------------------------------


--
-- Table structure for table `vt_shops_block`
--

DROP TABLE IF EXISTS `vt_shops_block`;
CREATE TABLE `vt_shops_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_shops_block`
--

INSERT INTO `vt_shops_block` VALUES
(1, 2, 0), 
(1, 10, 0), 
(1, 9, 0), 
(1, 1, 0), 
(1, 14, 0), 
(1, 7, 0), 
(1, 8, 0), 
(1, 6, 0);


-- ---------------------------------------


--
-- Table structure for table `vt_shops_block_cat`
--

DROP TABLE IF EXISTS `vt_shops_block_cat`;
CREATE TABLE `vt_shops_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_description` varchar(255) NOT NULL DEFAULT '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY (`bid`),
  UNIQUE KEY `vi_alias` (`vi_alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_shops_block_cat`
--

INSERT INTO `vt_shops_block_cat` VALUES
(1, 0, '', '', 1, 1353510217, 1353510217, 'Tour mới nhất', 'Tour-moi-nhat', '', ''), 
(2, 0, '', '', 2, 1353510229, 1353510229, 'Tour tiêu biểu', 'Tour-tieu-bieu', '', '');


-- ---------------------------------------


--
-- Table structure for table `vt_shops_catalogs`
--

DROP TABLE IF EXISTS `vt_shops_catalogs`;
CREATE TABLE `vt_shops_catalogs` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL DEFAULT '',
  `thumbnail` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_description` varchar(255) NOT NULL DEFAULT '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY (`catid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=37  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_shops_catalogs`
--

INSERT INTO `vt_shops_catalogs` VALUES
(1, 0, ' ', ' ', 1, 1, 0, 'view_home_cat', 3, '3,4,5', 1, 4, '', 1353508519, 1418201741, 0, '', 'Tour trong nước', 'Tour-trong-nuoc', '', ''), 
(2, 0, ' ', ' ', 2, 23, 0, 'view_home_cat', 3, '6,7,8', 1, 4, '', 1353508525, 1418201765, 0, '', 'Tour nước ngoài', 'Tour-nuoc-ngoai', '', ''), 
(3, 1, ' ', ' ', 1, 2, 1, 'view_home_cat', 6, '9,10,11,12,13,14', 1, 4, '', 1353508552, 1353508552, 0, '', 'TỪ TP HỒ CHÍ MINH', 'TU-TP-HO-CHI-MINH', '', ''), 
(4, 1, ' ', ' ', 2, 9, 1, 'view_home_cat', 6, '15,16,17,18,19,20', 1, 4, '', 1353508562, 1353508562, 0, '', 'TỪ HÀ NỘI', 'TU-HA-NOI', '', ''), 
(5, 1, ' ', ' ', 3, 16, 1, 'view_home_cat', 6, '21,22,23,24,25,26', 1, 4, '', 1353508578, 1353508578, 0, '', 'TỪ ĐÀ NẴNG', 'TU-DA-NANG', '', ''), 
(6, 2, ' ', ' ', 1, 24, 1, 'view_home_cat', 3, '27,28,29', 1, 4, '', 1353508612, 1353508612, 0, '', 'TỪ TP HỒ CHÍ MINH', 'NUOC-NGOAI-TU-TP-HO-CHI-MINH', '', ''), 
(7, 2, ' ', ' ', 2, 28, 1, 'view_home_cat', 3, '30,31,32', 1, 4, '', 1353508647, 1353508647, 0, '', 'TỪ HÀ NỘI', 'NUOC-NGOAI-TU-HA-NOI', '', ''), 
(8, 2, ' ', ' ', 3, 32, 1, 'view_home_cat', 3, '33,34,35', 1, 4, '', 1353508655, 1353508655, 0, '', 'TỪ ĐÀ NẴNG', 'NUOC-NGOAI-TU-DA-NANG', '', ''), 
(9, 3, ' ', ' ', 1, 3, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508677, 1353508677, 0, '', 'Tour miền Bắc', 'Tour-mien-Bac', '', ''), 
(10, 3, ' ', ' ', 2, 4, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508682, 1353508682, 0, '', 'Tour miền Trung', 'Tour-mien-Trung', '', ''), 
(11, 3, ' ', ' ', 3, 5, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508690, 1353508690, 0, '', 'Tour Tây Nguyên', 'Tour-Tay-Nguyen', '', ''), 
(12, 3, ' ', ' ', 4, 6, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508704, 1353508704, 0, '', 'Tour miền Tây Nam Bộ', 'Tour-mien-Tay-Nam-Bo', '', ''), 
(13, 3, ' ', ' ', 5, 7, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508721, 1353508721, 0, '', 'Tour Nha Trang', 'Tour-Nha-Trang', '', ''), 
(14, 3, ' ', ' ', 6, 8, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508750, 1353508750, 0, '', 'Tour Đà Lạt', 'Tour-Da-Lat', '', ''), 
(15, 4, ' ', ' ', 1, 10, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508778, 1353508778, 0, '', 'Tour miền Bắc', 'TU-HA-NOI-Tour-mien-Bac', '', ''), 
(16, 4, ' ', ' ', 2, 11, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508789, 1353508789, 0, '', 'Tour miền Trung', 'TU-HA-NOI-Tour-mien-Trung', '', ''), 
(17, 4, ' ', ' ', 3, 12, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508796, 1353508796, 0, '', 'Tour Tây Nguyên', 'TU-HA-NOI-Tour-Tay-Nguyen', '', ''), 
(18, 4, ' ', ' ', 4, 13, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508810, 1353508810, 0, '', 'Tour miền Tây Nam Bộ', 'TU-HA-NOI-Tour-mien-Tay-Nam-Bo', '', ''), 
(19, 4, ' ', ' ', 5, 14, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508813, 1353508813, 0, '', 'Tour Nha Trang', 'TU-HA-NOI-Tour-Nha-Trang', '', ''), 
(20, 4, ' ', ' ', 6, 15, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508822, 1353508822, 0, '', 'Tour Đà Lạt', 'TU-HA-NOI-Tour-Da-Lat', '', ''), 
(21, 5, ' ', ' ', 1, 17, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508839, 1353508839, 0, '', 'Tour miền Bắc', 'TU-DA-NANG-Tour-mien-Bac', '', ''), 
(22, 5, ' ', ' ', 2, 18, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508843, 1353508843, 0, '', 'Tour miền Trung', 'TU-DA-NANG-Tour-mien-Trung', '', ''), 
(23, 5, ' ', ' ', 3, 19, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508846, 1353508846, 0, '', 'Tour Tây Nguyên', 'TU-DA-NANG-Tour-Tay-Nguyen', '', ''), 
(24, 5, ' ', ' ', 4, 20, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508860, 1353508860, 0, '', 'Tour miền Tây Nam Bộ', 'TU-DA-NANG-Tour-mien-Tay-Nam-Bo', '', ''), 
(25, 5, ' ', ' ', 5, 21, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508866, 1353508866, 0, '', 'Tour Nha Trang', 'TU-DA-NANG-Tour-Nha-Trang', '', ''), 
(26, 5, ' ', ' ', 6, 22, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508873, 1353508873, 0, '', 'Tour Đà Lạt', 'TU-DA-NANG-Tour-Da-Lat', '', ''), 
(27, 6, ' ', ' ', 1, 25, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508893, 1418217215, 0, '', 'Tour Singapore', 'Tour-Sing', '', ''), 
(28, 6, ' ', ' ', 2, 26, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508900, 1353508900, 0, '', 'Tour Thái Lan', 'Tour-Thai-Lan', '', ''), 
(29, 6, ' ', ' ', 3, 27, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508907, 1353508907, 0, '', 'Tour Malaysia', 'Tour-Malaysia', '', ''), 
(30, 7, ' ', ' ', 1, 29, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508917, 1418217199, 0, '', 'Tour Hàn Quốc', 'NUOC-NGOAI-TU-HA-NOI-Tour-HQ', '', ''), 
(31, 7, ' ', ' ', 2, 30, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508924, 1353508924, 0, '', 'Tour Thái Lan', 'NUOC-NGOAI-TU-HA-NOI-Tour-Thai-Lan', '', ''), 
(32, 7, ' ', ' ', 3, 31, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508930, 1353508930, 0, '', 'Tour Malaysia', 'NUOC-NGOAI-TU-HA-NOI-Tour-Malaysia', '', ''), 
(33, 8, ' ', ' ', 1, 33, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508945, 1418217253, 0, '', 'Tour Nhật Bản', 'NUOC-NGOAI-TU-DA-NANG-Tour-Japan', '', ''), 
(34, 8, ' ', ' ', 2, 34, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508951, 1353508951, 0, '', 'Tour Thái Lan', 'NUOC-NGOAI-TU-DA-NANG-Tour-Thai-Lan', '', ''), 
(35, 8, ' ', ' ', 3, 35, 2, 'viewcat_page_list', 0, '', 1, 4, '', 1353508956, 1353508956, 0, '', 'Tour Malaysia', 'NUOC-NGOAI-TU-DA-NANG-Tour-Malaysia', '', '');


-- ---------------------------------------


--
-- Table structure for table `vt_shops_comments_vi`
--

DROP TABLE IF EXISTS `vt_shops_comments_vi`;
CREATE TABLE `vt_shops_comments_vi` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_id` int(11) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `photo` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_shops_group`
--

DROP TABLE IF EXISTS `vt_shops_group`;
CREATE TABLE `vt_shops_group` (
  `groupid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `cateid` int(11) NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL DEFAULT '',
  `thumbnail` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewgroup` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubgroup` int(11) NOT NULL DEFAULT '0',
  `subgroupid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  `numpro` int(11) unsigned NOT NULL DEFAULT '0',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_description` varchar(255) NOT NULL DEFAULT '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY (`groupid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=39  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_shops_group`
--

INSERT INTO `vt_shops_group` VALUES
(1, 0, 0, ' ', ' ', 1, 1, 0, 'viewcat_page_gird', 10, '3,4,5,6,7,8,9,10,11,12', 1, 4, '', 1353509458, 1353509458, 0, '', 1, 'TRONG NƯỚC', 'TRONG-NUOC', '', ''), 
(2, 0, 0, ' ', ' ', 2, 12, 0, 'viewcat_page_gird', 10, '13,14,15,16,17,18,19,20,21,22', 1, 4, '', 1353509493, 1353509493, 0, '', 0, 'NƯỚC NGOÀI', 'NUOC-NGOAI', '', ''), 
(3, 1, 0, ' ', ' ', 1, 2, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509773, 1353509773, 0, '', 3, 'Tour Phan Thiết', 'Tour-Phan-Thiet', '', ''), 
(4, 1, 0, ' ', ' ', 2, 3, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509780, 1353509780, 0, '', 2, 'Tour miền Trung', 'Tour-mien-Trung', '', ''), 
(5, 1, 0, ' ', ' ', 3, 4, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509785, 1353509785, 0, '', 1, 'Tour miền Bắc', 'Tour-mien-Bac', '', ''), 
(6, 1, 0, ' ', ' ', 4, 5, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509792, 1353509792, 0, '', 0, 'Tour miền Tây Nam Bộ', 'Tour-mien-Tay-Nam-Bo', '', ''), 
(7, 1, 0, ' ', ' ', 5, 6, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509799, 1353509799, 0, '', 0, 'Tour Đà Lạt', 'Tour-Da-Lat', '', ''), 
(8, 1, 0, ' ', ' ', 6, 7, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509811, 1353509811, 0, '', 0, 'Tour Phú Quốc', 'Tour-Phu-Quoc', '', ''), 
(9, 1, 0, ' ', ' ', 7, 8, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509817, 1353509817, 0, '', 0, 'Tour Hạ Long', 'Tour-Ha-Long', '', ''), 
(10, 1, 0, ' ', ' ', 8, 9, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509828, 1353509828, 0, '', 0, 'Tour Sa Pa', 'Tour-Sa-Pa', '', ''), 
(11, 1, 0, ' ', ' ', 9, 10, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509832, 1353509832, 0, '', 0, 'Tour Đà Nẵng', 'Tour-Da-Nang', '', ''), 
(12, 1, 0, ' ', ' ', 10, 11, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509838, 1353509838, 0, '', 0, 'Tour Hội An', 'Tour-Hoi-An', '', ''), 
(13, 2, 0, ' ', ' ', 1, 13, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509850, 1353509850, 0, '', 0, 'Tour Campuchia', 'Tour-Campuchia', '', ''), 
(14, 2, 0, ' ', ' ', 2, 14, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509857, 1353509857, 0, '', 0, 'Tour Thái Lan', 'Tour-Thai-Lan', '', ''), 
(15, 2, 0, ' ', ' ', 3, 15, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509863, 1353509863, 0, '', 0, 'Tour Malaysia', 'Tour-Malaysia', '', ''), 
(16, 2, 0, ' ', ' ', 4, 16, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509869, 1353509869, 0, '', 0, 'Tour Singapore', 'Tour-Singapore', '', ''), 
(17, 2, 0, ' ', ' ', 5, 17, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509873, 1353509873, 0, '', 0, 'Tour Hong Kong', 'Tour-Hong-Kong', '', ''), 
(18, 2, 0, ' ', ' ', 6, 18, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509885, 1353509885, 0, '', 0, 'Tour Trung Quốc', 'Tour-Trung-Quoc', '', ''), 
(19, 2, 0, ' ', ' ', 7, 19, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509893, 1353509893, 0, '', 0, 'Tour Hàn Quốc', 'Tour-Han-Quoc', '', ''), 
(20, 2, 0, ' ', ' ', 8, 20, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509900, 1353509900, 0, '', 0, 'Tour Nhật Bản', 'Tour-Nhat-Ban', '', ''), 
(21, 2, 0, ' ', ' ', 9, 21, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509907, 1353509907, 0, '', 0, 'Tour Mỹ', 'Tour-My', '', ''), 
(22, 2, 0, ' ', ' ', 10, 22, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509913, 1353509913, 0, '', 0, 'Tour Châu Âu', 'Tour-Chau-Au', '', ''), 
(23, 0, 0, ' ', ' ', 3, 23, 0, 'viewcat_page_gird', 7, '25,26,27,28,29,30,31', 1, 4, '', 1353509948, 1353509948, 0, '', 0, 'THEO NGÀY', 'THEO-NGAY', '', ''), 
(24, 0, 0, ' ', ' ', 4, 31, 0, 'viewcat_page_gird', 7, '32,33,34,35,36,37,38', 1, 4, '', 1353509954, 1353509954, 0, '', 0, 'LOẠI HÌNH TOUR', 'LOAI-HINH-TOUR', '', ''), 
(25, 23, 0, ' ', ' ', 1, 24, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353509965, 1353509965, 0, '', 1, '1 Ngày', '1-Ngay', '', ''), 
(26, 23, 0, ' ', ' ', 2, 25, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353510059, 1353510059, 0, '', 2, '2 Ngày 1 Đêm', '2-Ngay-1-Dem', '', ''), 
(27, 23, 0, ' ', ' ', 3, 26, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353510064, 1353510064, 0, '', 0, '3 Ngày 2 Đêm', '3-Ngay-2-Dem', '', ''), 
(28, 23, 0, ' ', ' ', 4, 27, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353510069, 1353510069, 0, '', 0, '4 Ngày 3 Đêm', '4-Ngay-3-Dem', '', ''), 
(29, 23, 0, ' ', ' ', 5, 28, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353510076, 1353510076, 0, '', 1, '5 Ngày 4 Đêm', '5-Ngay-4-Dem', '', ''), 
(30, 23, 0, ' ', ' ', 6, 29, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353510087, 1353510087, 0, '', 1, '6 Ngày 5 Đêm', '6-Ngay-5-Dem', '', ''), 
(31, 23, 0, ' ', ' ', 7, 30, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353510103, 1353510103, 0, '', 0, '7 Ngày 6 Đêm', '7-Ngay-6-Dem', '', ''), 
(32, 24, 0, ' ', ' ', 1, 32, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353510131, 1353510131, 0, '', 2, 'Du lịch biển', 'Du-lich-bien', '', ''), 
(33, 24, 0, ' ', ' ', 2, 33, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353510141, 1353510141, 0, '', 0, 'Du lịch trăng mật', 'Du-lich-trang-mat', '', ''), 
(34, 24, 0, ' ', ' ', 3, 34, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353510145, 1353510145, 0, '', 1, 'Du lịch dã ngoại', 'Du-lich-da-ngoai', '', ''), 
(35, 24, 0, ' ', ' ', 4, 35, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353510150, 1353510150, 0, '', 0, 'Du lịch xuyên Việt', 'Du-lich-xuyen-Viet', '', ''), 
(36, 24, 0, ' ', ' ', 5, 36, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353510158, 1353510158, 0, '', 0, 'Du lịch hè', 'Du-lich-he', '', ''), 
(37, 24, 0, ' ', ' ', 6, 37, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353510162, 1353510162, 0, '', 0, 'Du lịch cao cấp', 'Du-lich-cao-cap', '', ''), 
(38, 24, 0, ' ', ' ', 7, 38, 1, 'viewcat_page_gird', 0, '', 1, 4, '', 1353510172, 1353510172, 0, '', 0, 'Du lịch cuối tuần', 'Du-lich-cuoi-tuan', '', '');


-- ---------------------------------------


--
-- Table structure for table `vt_shops_money_vi`
--

DROP TABLE IF EXISTS `vt_shops_money_vi`;
CREATE TABLE `vt_shops_money_vi` (
  `id` mediumint(11) NOT NULL,
  `code` char(3) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `exchange` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_shops_money_vi`
--

INSERT INTO `vt_shops_money_vi` VALUES
(840, 'USD', 'US Dollar', '21000'), 
(704, 'VND', 'Vietnam Dong', '1');


-- ---------------------------------------


--
-- Table structure for table `vt_shops_orders`
--

DROP TABLE IF EXISTS `vt_shops_orders`;
CREATE TABLE `vt_shops_orders` (
  `order_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_code` varchar(30) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT 'en',
  `order_name` varchar(255) NOT NULL,
  `order_email` varchar(255) NOT NULL,
  `order_address` text NOT NULL,
  `order_phone` varchar(20) NOT NULL,
  `order_note` text NOT NULL,
  `listid` text NOT NULL,
  `listnum` text NOT NULL,
  `listprice` text NOT NULL,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `admin_id` int(11) unsigned NOT NULL DEFAULT '0',
  `shop_id` int(11) unsigned NOT NULL DEFAULT '0',
  `who_is` int(2) unsigned NOT NULL DEFAULT '0',
  `unit_total` char(3) NOT NULL,
  `order_total` double unsigned NOT NULL DEFAULT '0',
  `order_time` int(11) unsigned NOT NULL DEFAULT '0',
  `postip` varchar(100) NOT NULL,
  `view` tinyint(2) NOT NULL DEFAULT '0',
  `transaction_status` tinyint(4) NOT NULL,
  `transaction_id` int(11) NOT NULL DEFAULT '0',
  `transaction_count` int(11) NOT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order_code` (`order_code`),
  KEY `user_id` (`user_id`),
  KEY `order_time` (`order_time`),
  KEY `shop_id` (`shop_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_shops_payment`
--

DROP TABLE IF EXISTS `vt_shops_payment`;
CREATE TABLE `vt_shops_payment` (
  `payment` varchar(100) NOT NULL,
  `paymentname` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text NOT NULL,
  `images_button` varchar(255) NOT NULL,
  PRIMARY KEY (`payment`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_shops_rows`
--

DROP TABLE IF EXISTS `vt_shops_rows`;
CREATE TABLE `vt_shops_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `listcatid` int(11) NOT NULL DEFAULT '0',
  `group_id` varchar(255) NOT NULL DEFAULT '',
  `user_id` mediumint(8) NOT NULL DEFAULT '0',
  `source_id` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `product_code` varchar(255) NOT NULL DEFAULT '',
  `product_number` int(11) NOT NULL DEFAULT '0',
  `product_price` double NOT NULL DEFAULT '0',
  `product_discounts` int(11) NOT NULL DEFAULT '0',
  `money_unit` char(3) NOT NULL,
  `product_unit` int(11) NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL,
  `otherimage` text NOT NULL,
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(255) NOT NULL DEFAULT '',
  `allowed_send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `showprice` tinyint(2) NOT NULL DEFAULT '0',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_description` varchar(255) NOT NULL DEFAULT '',
  `vi_keywords` text NOT NULL,
  `vi_note` text NOT NULL,
  `vi_hometext` text NOT NULL,
  `vi_bodytext` mediumtext NOT NULL,
  `vi_address` text NOT NULL,
  `vi_warranty` text NOT NULL,
  `vi_promotional` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `listcatid` (`listcatid`),
  KEY `user_id` (`user_id`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`)
) ENGINE=MyISAM  AUTO_INCREMENT=15  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_shops_rows`
--

INSERT INTO `vt_shops_rows` VALUES
(1, 1, '1,3,4,25,32', 1, 2, 1353510482, 1418227141, 1, 1353510482, 0, 2, 'S000001', 1, '1', 0, 'VND', 1, '2014_12/sapa7.jpg', 'thumb/sapa7.jpg|block/sapa7.jpg', '', '', 0, 0, 1, 1, 1, '0', 1, 1, 1, 1, 0, 0, 1, 'Du lịch Sapa', 'Du-lich-Sapa', '', 'du lịch', 'Tàu. ô tô', 'Du lịch Sapa', '<strong style=\"margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: rgb(247, 247, 247); color: rgb(51, 51, 51); font-family: Arial, Helvetica, sans-serif; line-height: 12px;\">Nội dung dành cho khách đoàn&nbsp;<span class=\"require\" style=\"margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; color: red;\">(*)</span></strong><span style=\"color: rgb(51, 51, 51); font-family: Arial, Helvetica, sans-serif; line-height: 12px; background-color: rgb(247, 247, 247);\">&nbsp;(Chỉ hiển thị đối với những đối tượng được phép xem)</span><br  /><br  /><img alt=\"\" src=\"/dulich/uploads/shops/2014_12/sapa7.jpg\" style=\"width: 800px; height: 244px;\" />', 'Nơi đi', '3 sao', '1 ngày'), 
(2, 9, '3,4,5,29,30,32', 1, 3, 1353510701, 1418227053, 1, 1353510701, 0, 2, 'S000002', 1, '1', 0, 'VND', 1, '2014_12/banner-02-1080x349.jpg', 'thumb/banner-02-1080x349.jpg|block/banner-02-1080x349.jpg', '', '', 0, 0, 1, 1, 1, '0', 1, 1, 1, 1, 0, 0, 1, 'Tour du lịch miền Bắc 5N4Đ giá rẻ', 'Tour-du-lich-mien-Bac-5N4D-gia-re', '', 'du lịch', '', 'Tour du lịch miền Bắc 5N4Đ giá rẻ', '<strong style=\"margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: rgb(247, 247, 247); color: rgb(51, 51, 51); font-family: Arial, Helvetica, sans-serif; line-height: 12px;\">Nội dung dành cho khách đoàn&nbsp;<span class=\"require\" style=\"margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background-color: transparent; color: red;\">(*)</span></strong><span style=\"color: rgb(51, 51, 51); font-family: Arial, Helvetica, sans-serif; line-height: 12px; background-color: rgb(247, 247, 247);\">&nbsp;(Chỉ hiển thị đối với những đối tượng được phép xem)<br  /><img alt=\"\" src=\"/dulich/uploads/shops/2014_12/banner-02-1080x349.jpg\" style=\"width: 800px; height: 259px;\" /></span><br  />', 'Hà Nội', '2 sao', '1 ngày 1 đêm'), 
(6, 16, '3,26,34', 1, 2, 1353513410, 1418226695, 1, 1353513410, 0, 2, 'S000006', 1, '1', 0, 'VND', 1, '2014_12/hanoi-is-in-the-top-ten-most-favourite-places-for-cultural-tours.jpg', 'thumb/hanoi-is-in-the-top-ten-most-favourite-places-for-cultural-tours.jpg|block/hanoi-is-in-the-top-ten-most-favourite-places-for-cultural-tours.jpg', '', '', 0, 0, 1, 1, 1, '0', 1, 1, 1, 8, 0, 0, 1, 'Tour Hà Nội - Buôn Mê Thuột - Kon Tum 4N3Đ', 'Tour-Ha-Noi-Buon-Me-Thuot-Kon-Tum-4N3D', '', 'hà nội', 'Máy bay', 'Tour Hà Nội - Buôn Mê Thuột - Kon Tum 4N3Đ', '<h3 class=\"art-postheader\" style=\"margin: 0px; padding: 0px; font-family: Arial, Helvetica, sans-serif; color: rgb(51, 51, 51); line-height: 20px;\"> a<img alt=\"\" src=\"/dulich/uploads/shops/2014_12/hanoi-is-in-the-top-ten-most-favourite-places-for-cultural-tours.jpg\" /></h3>', 'Hà Nội', '2 sao', '2 ngày 2 đêm'), 
(7, 27, '', 1, 0, 1353513520, 1418226540, 1, 1353513520, 0, 2, 'S000007', 1, '1', 0, 'VND', 1, '2014_12/da-nang-giau-dep-van-minh-87e29.jpg', 'thumb/da-nang-giau-dep-van-minh-87e29_1.jpg|block/da-nang-giau-dep-van-minh-87e29_1.jpg', '', '', 0, 0, 1, 1, 1, '0', 1, 1, 1, 3, 0, 0, 1, 'CAMPUCHIA - Vương quốc của những kỳ quan&#33;', 'CAMPUCHIA-Vuong-quoc-cua-nhung-ky-quan', '', '', 'Máy bay', 'CAMPUCHIA - Vương quốc của những kỳ quan!', '<h3 class=\"art-postheader\" style=\"margin: 0px; padding: 0px; font-family: Arial, Helvetica, sans-serif; color: rgb(51, 51, 51); line-height: 20px;\"> <a class=\"PostHeader\" href=\"http://datviettour.com.vn/tour-du-lich/campuchia-vuong-quoc-cua-nhung-ky-quan!.html\" style=\"margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 15px; font-family: Arial; text-decoration: initial;\" title=\"CAMPUCHIA - Vương quốc của những kỳ quan!\">CAMPUCHIA - Vương quốc của những kỳ quan!</a><a class=\"PostHeader\" href=\"http://datviettour.com.vn/tour-du-lich/campuchia-vuong-quoc-cua-nhung-ky-quan!.html\" style=\"margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 15px; font-family: Arial; text-decoration: initial;\" title=\"CAMPUCHIA - Vương quốc của những kỳ quan!\">CAMPUCHIA - Vương quốc của những kỳ quan!</a><a class=\"PostHeader\" href=\"http://datviettour.com.vn/tour-du-lich/campuchia-vuong-quoc-cua-nhung-ky-quan!.html\" style=\"margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 15px; font-family: Arial; text-decoration: initial;\" title=\"CAMPUCHIA - Vương quốc của những kỳ quan!\">CAMPUCHIA - Vương quốc của những kỳ quan!</a><span class=\"PostHeader\" style=\"margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 15px; font-family: Arial; text-decoration: initial;\">CAMPUCHIA - Vương quốc của những kỳ quan!</span></h3>', 'Ninh thuận', '2 sao', '7 ngày đêm'), 
(8, 28, '26', 1, 0, 1353513629, 1418226597, 1, 1353513629, 0, 2, 'S000008', 1, '1', 0, 'VND', 1, '2014_12/images.jpg', 'thumb/images.jpg|block/images.jpg', '', '', 0, 0, 1, 1, 1, '0', 1, 1, 1, 2, 0, 0, 1, 'Tour Bangkok - Pattaya', 'Tour-Bangkok-Pattaya', '', '', 'Máy bay', 'Tour Bangkok - Pattaya', '<h3 style=\"margin: 0px; padding: 0px; font-family: Arial, Helvetica, sans-serif; color: rgb(51, 51, 51); line-height: 20px; height: 20px; width: 275.5px; overflow: hidden; font-size: 14px;\"> <span class=\"title_mini\" style=\"margin: 15px 0px 0px; padding: 0px; color: rgb(166, 12, 41); font-size: 15px; line-height: 18px; text-align: justify;\"><a href=\"http://datviettour.com.vn/tour-du-lich/tour-bangkok-pattaya.html\" style=\"margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 12px; font-family: Arial; text-decoration: initial;\" title=\"Tour Bangkok - Pattaya\">Tour Bangkok - Pattaya</a></span><span style=\"line-height: 18px; text-align: justify; margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 12px; font-family: Arial; text-decoration: initial;\">Tour Bangkok - Pattaya</span><a href=\"http://datviettour.com.vn/tour-du-lich/tour-bangkok-pattaya.html\" style=\"line-height: 18px; text-align: justify; margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 12px; font-family: Arial; text-decoration: initial;\" title=\"Tour Bangkok - Pattaya\">Tour Bangkok - Pattaya</a><a href=\"http://datviettour.com.vn/tour-du-lich/tour-bangkok-pattaya.html\" style=\"line-height: 18px; text-align: justify; margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 12px; font-family: Arial; text-decoration: initial;\" title=\"Tour Bangkok - Pattaya\">Tour Bangkok -&nbsp;</a><a href=\"http://datviettour.com.vn/tour-du-lich/tour-bangkok-pattaya.html\" style=\"line-height: 18px; text-align: justify; margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 12px; font-family: Arial; text-decoration: initial;\" title=\"Tour Bangkok - Pattaya\">Tour Bangkok - Pattaya</a><a href=\"http://datviettour.com.vn/tour-du-lich/tour-bangkok-pattaya.html\" style=\"line-height: 18px; text-align: justify; margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 12px; font-family: Arial; text-decoration: initial;\" title=\"Tour Bangkok - Pattaya\">Tour Bangkok - Pattaya</a><a href=\"http://datviettour.com.vn/tour-du-lich/tour-bangkok-pattaya.html\" style=\"line-height: 18px; text-align: justify; margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 12px; font-family: Arial; text-decoration: initial;\" title=\"Tour Bangkok - Pattaya\">Tour Bangkok - Pattaya</a><a href=\"http://datviettour.com.vn/tour-du-lich/tour-bangkok-pattaya.html\" style=\"line-height: 18px; text-align: justify; margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 12px; font-family: Arial; text-decoration: initial;\" title=\"Tour Bangkok - Pattaya\">Tour Bangkok - Pattaya</a><a href=\"http://datviettour.com.vn/tour-du-lich/tour-bangkok-pattaya.html\" style=\"line-height: 18px; text-align: justify; margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 12px; font-family: Arial; text-decoration: initial;\" title=\"Tour Bangkok - Pattaya\">Tour Bangkok - Pattaya</a></h3>', 'Hà Nội', '3 sao', '2 ngày 2 đêm'), 
(9, 32, '', 1, 0, 1353513715, 1418226586, 1, 1353513715, 0, 2, 'S000009', 1, '1', 0, 'VND', 1, '2014_12/du-lich-hong-kong-kham-pha-khu-giai-tri-dineyland-11.jpg', 'thumb/du-lich-hong-kong-kham-pha-khu-giai-tri-dineyland-11.jpg|block/du-lich-hong-kong-kham-pha-khu-giai-tri-dineyland-11.jpg', '', '', 0, 0, 1, 1, 1, '0', 1, 1, 1, 3, 0, 0, 1, 'Du lịch Hong Kong - Disneyland', 'Du-lich-Hong-Kong-Disneyland', '', 'du lịch', 'Máy bay', 'Du lịch Hong Kong - Disneyland', '<h3 style=\"margin: 0px; padding: 0px; font-family: Arial, Helvetica, sans-serif; color: rgb(51, 51, 51); line-height: 20px; height: 20px; width: 275.5px; overflow: hidden; font-size: 14px;\"> <span class=\"title_mini\" style=\"margin: 15px 0px 0px; padding: 0px; color: rgb(166, 12, 41); font-size: 15px; line-height: 18px; text-align: justify;\"><a href=\"http://datviettour.com.vn/tour-du-lich/du-lich-hong-kong-disneyland.html\" style=\"margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 12px; font-family: Arial; text-decoration: initial;\" title=\"Du lịch Hong Kong - Disneyland\">Du lịch Hong Kong - Disneyland</a></span><span style=\"line-height: 18px; text-align: justify; margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 12px; font-family: Arial; text-decoration: initial;\">Du lịch Hong Kong - Disneyland</span><a href=\"http://datviettour.com.vn/tour-du-lich/du-lich-hong-kong-disneyland.html\" style=\"line-height: 18px; text-align: justify; margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 12px; font-family: Arial; text-decoration: initial;\" title=\"Du lịch Hong Kong - Disneyland\">Du lịch Hong Kong - Disneyland</a></h3><br  /><img alt=\"\" src=\"/dulich/uploads/shops/2014_12/du-lich-hong-kong-kham-pha-khu-giai-tri-dineyland-11.jpg\" style=\"width: 800px; height: 600px;\" />', 'Ninh thuận', '5 Sao', '3 ngày 2 đêm'), 
(10, 33, '', 1, 0, 1353513783, 1418226319, 1, 1353513783, 0, 2, 'S000010', 1, '1', 0, 'VND', 1, '2014_12/hongkongboat.jpg', 'thumb/hongkongboat.jpg|block/hongkongboat.jpg', '', '', 0, 0, 1, 1, 1, '0', 1, 1, 1, 1, 0, 0, 1, 'Du lịch Hongkong - Disneyland - Thẩm Quyến', 'Du-lich-Hongkong-Disneyland-Tham-Quyen', '', 'du lịch', 'máy bay', 'Du lịch Hongkong - Disneyland - Thẩm Quyến', '<h3 style=\"margin: 0px; padding: 0px; font-family: Arial, Helvetica, sans-serif; color: rgb(51, 51, 51); line-height: 20px; height: 20px; width: 275.5px; overflow: hidden; font-size: 14px;\"> <span class=\"title_mini\" style=\"margin: 15px 0px 0px; padding: 0px; color: rgb(166, 12, 41); font-size: 15px; line-height: 18px; text-align: justify;\"><span style=\"margin: 0px; padding: 0px; color: rgb(0, 102, 153); font-size: 12px; font-family: Arial; text-decoration: initial;\">Du lịch Hongkong - Disneyland - Thẩm Quyến</span></span></h3><br  /><img alt=\"\" src=\"/dulich/uploads/shops/2014_12/hongkongboat.jpg\" style=\"width: 620px; height: 385px;\" />', '', '5 sao', '7 này 7 đêm'), 
(14, 25, '', 1, 0, 1353514188, 1418287862, 1, 1353514188, 0, 2, 'S000014', 1, '1', 0, 'VND', 1, '2014_12/da-nang-giau-dep-van-minh-87e29.jpg', 'thumb/da-nang-giau-dep-van-minh-87e29.jpg|block/da-nang-giau-dep-van-minh-87e29.jpg', '', '', 0, 0, 1, 1, 1, '0', 1, 1, 1, 42, 0, 0, 1, 'Du lịch Nha Trang trọn gói', 'Du-lich-Nha-Trang-tron-goi', '', 'du lịch', 'Ô tô, máy bay', 'Du lịch Phú QUốc 3 Ngày giá rẻ', '<div align=\"justify\"> <h3> NGÀY 01: HÀ NỘI – NHA TRANG ( Ăn: Tối)</h3> <hr  /> <ul> <li> <strong>05h30</strong> Xe và HDV đón Quý khách tại Nhà Hát Lớn, đưa đoàn ra sân bay Nội Bài. Quý khách đáp chuyến bay <strong>VN1553</strong> khởi hành đi Nha Trang vào lúc <strong>07h55.</strong></li> <li> <strong>09h40</strong> Quý khách có mặt tại sân bay Cam Ranh, xe và HDV đón Quý khách tại sân bay đưa đoàn đi ăn trưa tại nhà hàng, sau đó về khách sạn nhận phòng nghỉ ngơi.</li> <li> <strong>Chiều</strong> Đoàn tự do tắm biển.</li> <li> <strong>19h00 </strong>Ăn tối tại nhà hàng, tự do khám phá Nha Trang về đêm.</li> </ul> <h3> NGÀY 02: THAM QUAN NHA TRANG – KDL VINPEARLLAND (Ăn: Sáng, Trưa)</h3> <hr  /> <ul> <li> Quý khách ăn sáng tại khách sạn, xe đưa ra bến tàu. Đoàn lên tàu đi tham quan <strong>Vịnh Nha Trang.</strong></li> <li> <strong>Hòn Mun</strong> – được mệnh danh là điểm lặn biển ngắm san hô đẹp nhất Việt Nam hiện nay, tại đây quý khách sẽ được tắm lặn ngắm san hô, cùng nhiều loài cá khác nhau rất sinh động và hấp dẫn, hoặc ngắm đáy đại dương từ tàu đáy kính <strong>(chi phí tự túc). </strong></li> <li> <strong>Ngắm Làng Chài, Hòn Tre.</strong> <ul> <li> <strong>11h30</strong> Quý khách ăn trưa tại nhà hàng.</li> <li> <strong>Chiều</strong> Quý khách tự do tham quan KDL Vinpearlland, Quý khách thăm quan.</li> <li> <strong>KDL</strong><strong> Vinpearl Land</strong><strong> – </strong>Chương trình biểu diễn trên sân khấu nhạc nước hiện đại,nơi từng diễn ra các sự kiện văn hóa lớn.Tham gia tất cả các trò chơi động cảm giác mạnh như: Quay nhào lộn, đu quay ngựa gỗ, đu quay voi. Các trò chơi tĩnh như: tàu lượn, đua xe, khám phá vũ trụ, trượt tuyết, lượt sóng, xe điện đụng. Đặc biệt có phòng chiếu phim 4D mới lạ, tăng thêm hiệu quả nhờ các vòi phun gió, nước để thám hiểm đại dương, các đường hầm bí hiểm hay lâu đài ma quái…</li> </ul> </li> <li> <strong>18h00</strong> Đoàn tự do ăn tối tại khu du lịch.</li> <li> <strong>20h00</strong> Quý khách đi cáp treo về lại thành phố. Xe đón đoàn về khách sạn nghỉ ngơi.</li> </ul> <h3> NGÀY 03: NHA TRANG – KDL DỐC LẾT (Ăn: Sáng, Trưa, Tối)</h3> <hr  /> <ul> <li> <strong>07h30 </strong>Quý khách ăn sáng tại khách sạn.</li> <li> <strong>09h00</strong> Xe đưa quý khách đi tham quan.</li> <li> <strong>Dốc Lết</strong> – Quý khách có thể chiêm ngưỡng vẻ đẹp huyền ảo của Vịnh Nha Phu trong sương sớm, lắng nghe tiếng sóng vỗ êm ái vào ghềnh đá. Tiếp tục chuyến hành trình đến với Dốc Lết&nbsp; ,&nbsp; đến khu du lịch Quý khách tự do nghỉ ngơi&nbsp; và tắm biển,&nbsp; tham gia các trò chơi thể thao nước hoặc thưởng thức hải sản tươi sống tại Chợ Hải Sản địa phương (&nbsp; chi phí tự túc ).</li> <li> <strong>11h30</strong> Đoàn ăn trưa tại nhà hàng Dốc Lết, nghỉ ngơi thư giãn trong khu du lịch.</li> <li> <strong>14h30 </strong>HDV đưa Quý khách khởi hành về lại thành phố Nha Trang, trên đường về dừng chân tham quan ruộng <strong>muối Ninh Diêm</strong>, chụp ảnh lưu niệm . Đến Lò Nem ,Quý khách có thể mua đặc sản <strong>Nem Ninh Hòa</strong> về làm quà cho người thân và gia đình.</li> <li> <strong>18h30 </strong>Quý khách ăn tối tại nhà hàng, tự do khám phá thành phố biển về đêm.</li> </ul> <h3> NGÀY 04: NHA TRANG – HÀ NỘI (Ăn: Sáng, Trưa)</h3> <hr  /> <ul> <li> Quý khách tự do tắm biển, ăn sáng tại khách sạn, tự do đi chợ Đầm mua quà lưu niệm cho gia đình và người thân</li> <li> <strong>11h30</strong> Quý khách làm thủ tục trả phòng, ăn trưa tại nhà hàng. Sau đó đoàn tự do cho đến khi xe đưa đoàn ra sân bay Cam Ranh đáp chuyến bay <strong>VN1560</strong> về lại Hà Nội vào lúc <strong>21h00.</strong></li> <li> <strong>22h45</strong>Quý khách về đến sân bay Nội Bài, xe đón Quý khách về điểm hẹn ban đầu. Chia tay đoàn và hẹn gặp lại.</li> </ul></div><img alt=\"\" src=\"/dulich/uploads/shops/2014_12/da-nang-giau-dep-van-minh-87e29.jpg\" style=\"width: 800px; height: 373px;\" />', '', '3 sao', '2 ngày');


-- ---------------------------------------


--
-- Table structure for table `vt_shops_sources`
--

DROP TABLE IF EXISTS `vt_shops_sources`;
CREATE TABLE `vt_shops_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `link` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`sourceid`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_shops_sources`
--

INSERT INTO `vt_shops_sources` VALUES
(4, '', '', 3, 1353513976, 1353513976, 'Ninh Thuận'), 
(2, '', '', 1, 1353510483, 1353510483, 'Hà nội'), 
(3, '', '', 2, 1353510701, 1353510701, 'Hội an');


-- ---------------------------------------


--
-- Table structure for table `vt_shops_transaction`
--

DROP TABLE IF EXISTS `vt_shops_transaction`;
CREATE TABLE `vt_shops_transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_time` int(11) NOT NULL DEFAULT '0',
  `transaction_status` int(11) NOT NULL,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `payment` varchar(22) NOT NULL DEFAULT '0',
  `payment_id` varchar(22) NOT NULL DEFAULT '0',
  `payment_time` int(11) NOT NULL DEFAULT '0',
  `payment_amount` int(11) NOT NULL DEFAULT '0',
  `payment_data` text NOT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `order_id` (`order_id`),
  KEY `payment_id` (`payment_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_shops_units`
--

DROP TABLE IF EXISTS `vt_shops_units`;
CREATE TABLE `vt_shops_units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_note` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_shops_units`
--

INSERT INTO `vt_shops_units` VALUES
(1, '1 Người', '');


-- ---------------------------------------


--
-- Table structure for table `vt_tour_hotel`
--

DROP TABLE IF EXISTS `vt_tour_hotel`;
CREATE TABLE `vt_tour_hotel` (
  `hotelid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `link` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`hotelid`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_tour_hotel`
--

INSERT INTO `vt_tour_hotel` VALUES
(2, '', '', 2, 1352988144, 1352990405, '3 ngày 2 đêm'), 
(3, '', '', 3, 1352990299, 1352990952, 'rewr'), 
(4, '', 's.jpg', 4, 1352990559, 1352990909, '3 sao');


-- ---------------------------------------


--
-- Table structure for table `vt_users`
--

DROP TABLE IF EXISTS `vt_users`;
CREATE TABLE `vt_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `gender` char(1) NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `website` varchar(255) NOT NULL DEFAULT '',
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL DEFAULT '',
  `telephone` varchar(100) NOT NULL DEFAULT '',
  `fax` varchar(100) NOT NULL DEFAULT '',
  `mobile` varchar(100) NOT NULL DEFAULT '',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `passlostkey` varchar(40) NOT NULL DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255) NOT NULL DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40) NOT NULL DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) NOT NULL DEFAULT '',
  `last_agent` varchar(255) NOT NULL DEFAULT '',
  `last_openid` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_users`
--

INSERT INTO `vt_users` VALUES
(1, 'levietadmin', '325e7adec0200075c39365e55085ebdd', 'a7f29605d2da5380ef84b6206483014c11061da2', 'leviet.vnuahy@gmail.com', 'ADMIN LEVIET', 'M', '', 0, '', 1351857125, 'http://levietpro.com', '', '', '', '', '', 'levietpro', 'leviet', '', 0, 1, '', 1, '', 1351857125, '', '', '');


-- ---------------------------------------


--
-- Table structure for table `vt_users_config`
--

DROP TABLE IF EXISTS `vt_users_config`;
CREATE TABLE `vt_users_config` (
  `config` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_users_config`
--

INSERT INTO `vt_users_config` VALUES
('registertype', '1', 1351857075), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1351857075), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1351857075), 
('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br  /> <br  /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br  /> <br  /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br  /> <br  /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129);


-- ---------------------------------------


--
-- Table structure for table `vt_users_openid`
--

DROP TABLE IF EXISTS `vt_users_openid`;
CREATE TABLE `vt_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `opid` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_users_question`
--

DROP TABLE IF EXISTS `vt_users_question`;
CREATE TABLE `vt_users_question` (
  `qid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_users_question`
--

INSERT INTO `vt_users_question` VALUES
(1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238), 
(2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250), 
(3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257), 
(4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264), 
(5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270), 
(6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278), 
(7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);


-- ---------------------------------------


--
-- Table structure for table `vt_users_reg`
--

DROP TABLE IF EXISTS `vt_users_reg`;
CREATE TABLE `vt_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `checknum` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_vi_about`
--

DROP TABLE IF EXISTS `vt_vi_about`;
CREATE TABLE `vt_vi_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `bodytext` mediumtext NOT NULL,
  `keywords` mediumtext NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_about`
--

INSERT INTO `vt_vi_about` VALUES
(1, 'Giới thiệu về NukeViet 3.0', 'Gioi-thieu-ve-NukeViet-3-0', '<p> NukeViet 3.0 là thế hệ CMS hoàn toàn mới do người Việt phát triển. Lần đầu tiên ở Việt Nam, một bộ nhân mã nguồn mở được đầu tư bài bản và chuyên nghiệp cả về tài chính, nhân lực và thời gian. Kết quả là 100% dòng code của NukeViet được viết mới hoàn toàn, NukeViet 3 sử dụng xHTML, CSS với Xtemplate và jquery cho phép vận dụng Ajax uyển chuyển cả trong công nghệ nhân.</p><p> Tận dụng các thành tựu mã nguồn mở có sẵn nhưng NukeViet 3 vẫn đảm bảo rằng từng dòng code là được code tay (NukeViet 3 không sử dụng bất cứ một nền tảng (framework) nào). Điều này có nghĩa là NukeViet 3 hoàn toàn không phụ thuộc vào bất cứ framework nào trong quá trình phát triển của mình; Bạn hoàn toàn có thể đọc hiểu để tự lập trình trên NukeViet 3 nếu bạn biết PHP và MySQL (đồng nghĩa với việc NukeViet 3 hoàn toàn mở và dễ nghiên cứu cho bất cứ ai muốn tìm hiểu về code của NukeViet).</p><p style=\"text-align: justify;\"> Bộ nhân NukeViet 3 ngoài việc thừa hưởng sự đơn giản vốn có của NukeViet nhưng không vì thế mà quên nâng cấp mình. Hệ thống NukeViet 3 hỗ trợ công nghệ đa nhân module. Chúng tôi gọi đó là công nghệ ảo hóa module. Công nghệ này cho phép người sử dụng có thể khởi tạo hàng ngàn module một cách tự động mà không cần động đến một dòng code. Các module được sinh ra từ công nghệ này gọi là module ảo. Module ảo là module được nhân bản từ một module bất kỳ của hệ thống nukeviet nếu module đó cho phép tạo module ảo.</p><p style=\"text-align: justify;\"> NukeViet 3 cũng hỗ trợ việc cài đặt từ động 100% các module, block, theme từ Admin Control Panel, người sử dụng có thể cài module mà không cần làm bất cứ thao tác phức tạp nào. NukeViet 3 còn cho phép bạn đóng gói module để chia sẻ cho người khác.</p><p style=\"text-align: justify;\"> NukeViet 3 đa ngôn ngữ 100% với 2 loại: đa ngôn ngữ giao diện và đa ngôn ngữ database. NukeViet 3 có tính năng&nbsp; cho phép người quản trị tự xây dựng ngôn ngữ mới cho site. Cho&nbsp; phép đóng gói file ngôn ngữ để chia sẻ cho cộng đồng... câu chuyện về nukeviet 3 sẽ còn dài vì một loạt các tính năng cao cấp vẫn đang được phát triển. Hãy sử dụng và phổ biến NukeViet 3 để tự mình tận hưởng những thành quả mới nhất từ công nghệ web mã nguồn mở. Cuối cùng NukeViet 3 là món của của <a href=\"http://vinades.vn\" target=\"_blank\">VINADES.,JSC</a> gửi tới cộng đồng để cảm ơn cộng đồng đã ủng hộ thời gian qua, bây giờ NukeViet 3 được đưa trở lại cộng đồng để cộng đồng tiếp tục nuôi nấng và chăm sóc NukeViet lớn mạnh hơn.</p><p style=\"text-align: justify;\"> Mọi ý kiến và yêu cầu trợ giúp về NukeViet 3 các bạn có thể gửi lên diễn đàn NukeViet tại địa chỉ: <a href=\"http://nukeviet.vn/phpbb/\" target=\"_blank\">http://nukeviet.vn/phpbb/</a>. Việc giúp đỡ hoàn toàn miễn phí và mọi góp ý của bạn đều được hoan nghênh.</p> <div style=\"text-align: center;\"> <object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" height=\"400\" width=\"480\"><param name=\"quality\" value=\"high\" /><param name=\"allowScriptAccess\" value=\"always\" /><param name=\"movie\" value=\"/nuke342/images/jwplayer/player.swf\" /><param name=\"allowfullscreen\" value=\"true\" /><param name=\"allowscriptaccess\" value=\"always\" /><param name=\"flashvars\" value=\"file=http://www.youtube.com/watch?v=dG66RocXSeY&amp;autostart=true\" /><embed allowscriptaccess=\"always\" flashvars=\"file=http://www.youtube.com/watch?v=dG66RocXSeY&amp;autostart=true\" height=\"400\" quality=\"high\" src=\"/nuke342/images/jwplayer/player.swf\" width=\"480\"></embed></object><br  /> Video clip Giới thiệu mã nguồn mở NukeViet trong bản tin Tiêu điểm của chương trình Xã hội thông tin<br  /> (Đài truyền hình kỹ thuật số VTC) phát sóng lúc 20h chủ nhật, ngày 05-09-2010 trên VTC1</div>', 'thế hệ,hoàn toàn,phát triển,tài chính,nhân lực,thời gian,kết quả,sử dụng,cho phép,uyển chuyển,công nghệ,tận dụng,thành tựu,đảm bảo,nền tảng,có nghĩa,phụ thuộc,quá trình,có thể,tự lập,đồng nghĩa', 1, 1, 1275320174, 1275320174, 1), 
(2, 'Giới thiệu về công ty chuyên quản NukeViet', 'Gioi-thieu-ve-cong-ty-chuyen-quan-NukeViet', '<p style=\"text-align: justify;\"> <strong>Công ty cổ phần phát triển nguồn mở Việt Nam</strong> (VINADES.,JSC) là công ty mã nguồn mở đầu tiên của Việt Nam sở hữu riêng một mã nguồn mở nổi tiếng và đang được sử dụng ở hàng ngàn website lớn nhỏ trong mọi lĩnh vực.<br  /> <br  /> Ra đời từ hoạt động của tổ chức nguồn mở NukeViet (từ năm 2004) và chính thức được thành lập đầu 2010 tại Hà Nội, khi đó báo chí đã gọi VINADES.,JSC là &quot;Công ty mã nguồn mở đầu tiên tại Việt Nam&quot;.<br  /> <br  /> Ngay sau khi thành lập, VINADES.,JSC đã thành công trong việc xây dựng <strong><a href=\"http://nukeviet.vn/\" target=\"_blank\">NukeViet</a></strong> thành một <a href=\"http://nukeviet.vn/\" target=\"_blank\">mã nguồn mở</a> thuần Việt. Với khả năng mạnh mẽ, cùng các ưu điểm vượt trội về công nghệ, độ an toàn và bảo mật, NukeViet đã được hàng ngàn website lựa chọn sử dụng trong năm qua. Ngay khi ra mắt phiên bản mới năm 2010, NukeViet đã tạo nên hiệu ứng truyền thông chưa từng có trong lịch sử mã nguồn mở Việt Nam. Tiếp đó, năm 2011 Mã nguồn mở NukeViet đã giành giải thưởng Nhân tài đất Việt cho sản phẩm Công nghệ thông tin đã được ứng dụng rộng rãi.<br  /> <div style=\"text-align: center;\"> <object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" height=\"400\" width=\"480\"><param name=\"movie\" value=\"/nuke342/images/jwplayer/player.swf\" /><param name=\"allowfullscreen\" value=\"true\" /><param name=\"allowscriptaccess\" value=\"always\" /><param name=\"flashvars\" value=\"file=http://www.youtube.com/watch?v=ZOhu2bLE-eA&amp;autostart=true\" /><embed allowfullscreen=\"true\" allowscriptaccess=\"always\" flashvars=\"file=http://www.youtube.com/watch?v=ZOhu2bLE-eA&amp;autostart=true\" height=\"400\" src=\"/nuke342/images/jwplayer/player.swf\" width=\"480\"></embed></object><br  /> <strong>Video clip trao giải Nhân tài đất Việt 2011.</strong><br  /> Sản phẩm &quot;Mã nguồn mở NukeViet&quot; đã nhận giải cao nhất (Giải ba, không có giải nhất, giải nhì) của Giải thưởng Nhân Tài Đất Việt 2011 ở lĩnh vực Công nghệ thông tin - Sản phẩm đã có ứng dụng rộng rãi.</div><br  /> Tự chuyên nghiệp hóa mình, thoát khỏi mô hình phát triển tự phát, công ty đã nỗ lực vươn mình ra thế giới và đang phấn đấu trở thành một trong những hiện tượng của thời &quot;dotcom&quot; ở Việt Nam.<br  /> <br  /> Để phục vụ hoạt động của công ty, công ty liên tục mở rộng và tuyển thêm nhân sự ở các vị trí: Lập trình viên, chuyên viên đồ họa, nhân viên kinh doanh... Hãy liên hệ ngay để gia nhập VINADES.,JSC và cùng chúng tôi trở thành một công ty phát triển nguồn mở thành công nhất Việt Nam.</p> <p>Nếu bạn có nhu cầu triển khai các hệ thống <a href=\"http://toasoandientu.vn\" target=\"_blank\">Tòa Soạn Điện Tử</a>, <a href=\"http://webnhanh.vn\" target=\"_blank\">phần mềm trực tuyến</a>, <a href=\"http://vinades.vn\" target=\"_blank\">thiết kế web</a> theo yêu cầu hoặc dịch vụ có liên quan, hãy liên hệ công ty chuyên quản NukeViet theo thông tin dưới đây:</p><strong><span style=\"font-family: Tahoma; color: rgb(255, 69, 0); font-size: 14px;\">CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM</span></strong><br  /><div> <strong>VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY</strong> (<strong>VINADES.,JSC</strong>)<br  /> <div>Website: <a href=\"http://vinades.vn/\">http://vinades.vn</a> | <a href=\"http://nukeviet.vn/\">http://nukeviet.vn</a> | <a href=\"http://webnhanh.vn/\">http://webnhanh.vn</a></div><br  />Trụ sở: Phòng 1805 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.<br  /> - Tel: +84-4-85872007<br  /> - Fax: +84-4-35500914<br  /> - Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></div></div>', '', 2, 1, 1275320224, 1275320224, 1);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_blocks_groups`
--

DROP TABLE IF EXISTS `vt_vi_blocks_groups`;
CREATE TABLE `vt_vi_blocks_groups` (
  `bid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55) NOT NULL,
  `module` varchar(55) NOT NULL,
  `file_name` varchar(55) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `template` varchar(55) DEFAULT NULL,
  `position` varchar(55) DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` tinyint(4) DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=64  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_blocks_groups`
--

INSERT INTO `vt_vi_blocks_groups` VALUES
(1, 'default', 'news', 'global.block_category.php', 'Menu', '', '', '[LEFT]', 0, 1, '0', 0, 1, 'a:1:{s:12:\"title_length\";i:25;}'), 
(9, 'modern', 'news', 'module.block_newscenter.php', 'Tin mới', '', 'no_title', '[HEADER]', 0, 1, '0', 0, 1, ''), 
(10, 'modern', 'about', 'global.about.php', 'Giới thiệu', '', 'no_title_html', '[RIGHT]', 0, 1, '0', 1, 1, ''), 
(11, 'modern', 'users', 'global.login.php', 'Đăng nhập', '', '', '[RIGHT]', 0, 1, '0', 1, 2, ''), 
(12, 'modern', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '0', 1, 3, ''), 
(13, 'modern', 'statistics', 'global.counter.php', 'Bộ đếm', '', '', '[RIGHT]', 0, 1, '0', 1, 4, ''), 
(14, 'modern', 'news', 'module.block_newsright.php', 'News Right', '', 'no_title', '[RIGHT]', 0, 1, '0', 0, 5, ''), 
(15, 'modern', 'banners', 'global.banners.php', 'Quảng cáo top banner', '', 'no_title', '[TOPADV]', 0, 1, '0', 1, 1, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(16, 'modern', 'menu', 'global.menu_theme_modern.php', 'global menu theme modern', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''), 
(17, 'default', 'menu', 'global.menu_style.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, 'a:4:{s:4:\"type\";i:5;s:6:\"menuid\";i:1;s:10:\"is_viewdes\";i:0;s:12:\"title_length\";i:20;}'), 
(18, 'modern', 'global', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '0', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:274:\"© Copyright NukeViet 3. All right reserved.<br  />Xây dựng trên nền tảng <a href=\"http://nukeviet.vn/\" title=\"Mã nguồn mở NukeViet\">Mã nguồn mở NukeViet</a>. <a href=\"http://vinades.vn/\" title=\"Thiết kế web\">Thiết kế website</a> bởi VINADES.,JSC\";}'), 
(20, 'mobile_nukeviet', 'menu', 'global.menu_theme_default.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''), 
(46, 'default', 'global', 'global.html.php', 'global html', '', 'no_title', '[SOCIAL]', 0, 1, '0', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:1693:\"<div style=\"text-align: center;\"> <strong><span style=\"color:rgb(255, 140, 0);\">&nbsp;<a href=\"http://facebook.com/#\" target=\"_blank\" title=\"Follow us on Facebook\"><img alt=\"Facebook icon,social icon\" src=\"/demo/dulich/uploads/social/facebook.gif\" style=\"width: 23px; height: 23px;\" /></a> <a href=\"http://google.com/+1\" target=\"_blank\" title=\"Follow us on Google+\"><img alt=\"google+ plus icon,social icon\" src=\"/demo/dulich/uploads/social/google-plus.jpg\" style=\"width: 24px; height: 23px;\" /></a> <a href=\"http://tweeter.com/#\" title=\"Follow us on Tweeter\"><img alt=\"tweeter icon,social icon\" src=\"/demo/dulich/uploads/social/tweeter.gif\" style=\"width: 24px; height: 23px;\" /></a> <a href=\"http://youtube.com/v\" target=\"_blank\" title=\"Follow us on Youtube\"><img alt=\"youtube icon,social icon\" src=\"/demo/dulich/uploads/social/youtube.gif\" style=\"width: 23px; height: 23px;\" /></a> </span></strong><a href=\"#\" title=\"RSS\"><img alt=\"rss icon,feed icon\" src=\"/demo/dulich/uploads/social/rss-feed-icon.png\" style=\"width: 23px; height: 23px;\" /></a><br  /> <span style=\"font-size:12px;\"><span style=\"color: rgb(255, 0, 0);\"><strong>HOTLINE: 0901234567</strong></span></span><br  /> <strong><a href=\"ymsgr:sendim?leviet_vnit&amp;m=Chao%20webmaster%21\" rel=\"nofollow\"><img alt=\"\" src=\"http://opi.yahoo.com/online?u=leviet_vnit&amp;m=g&amp;t=2\" style=\"width:auto; height: 16px;\" title=\"Chat yahoo voi Quan tri website!\" /></a> <a href=\"skype:leviet.donex?chat\" rel=\"nofollow\" title=\"Chat Skype với Quản trị website\"><img alt=\"skype button,skype.png,skype icon,skype me\" src=\"http://donexpro.com/uploads/social-skype-button-blue-icon.png\" style=\"width:auto; height: 16px;\" /></a></strong></div>\";}'), 
(27, 'default', 'news', 'module.block_news.php', 'global block cart', '', '', '[RIGHT]', 0, 1, '0', 0, 1, 'a:1:{s:6:\"numrow\";i:20;}'), 
(29, 'default', 'shops', 'global.block_search.php', 'global block search', '', '', '[LEFT]', 0, 1, '0', 0, 2, ''), 
(35, 'default', 'news', 'global.block_catid.php', 'Việt Nam - Đất nước - Con người', '', 'title_on', '[BOTTOM]', 0, 1, '0', 0, 1, 'a:3:{s:5:\"catid\";i:1;s:6:\"numrow\";i:5;s:4:\"type\";i:4;}'), 
(41, 'default', 'shops', 'global.block_group.php', 'global block group', '', '', '[LEFT]', 0, 1, '0', 0, 3, ''), 
(43, 'default', 'news', 'global.block_catid.php', 'TIN DU LỊCH', '', 'title_on', '[LEFT]', 0, 1, '0', 0, 4, 'a:3:{s:5:\"catid\";i:8;s:6:\"numrow\";i:5;s:4:\"type\";i:6;}'), 
(45, 'default', 'banners', 'global.banners_slide.php', 'global banners slide', '', '', '[TOP]', 0, 1, '0', 0, 2, 'a:1:{s:12:\"idplanbanner\";i:2;}'), 
(49, 'default', 'banners', 'global.banners_home.php', 'banner-home', '', 'no_title', '[HEADER]', 0, 1, '0', 0, 1, 'a:1:{s:12:\"idplanbanner\";i:3;}'), 
(51, 'default', 'shops', 'global.block_relates_product.php', 'block tour home', '', 'no_title', '[HEADER]', 0, 1, '0', 0, 2, 'a:3:{s:7:\"blockid\";i:1;s:6:\"numrow\";i:6;s:7:\"cut_num\";i:25;}'), 
(54, 'default', 'global', 'global.html.php', 'left-footer', '', 'no_title', '[FOOTER1]', 0, 1, '0', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:227:\"<span style=\"color:rgb(105, 105, 105);\"><strong>Công ty CP Du lịch &amp; Thương mại VietnamTourist</strong><br  />Địa chỉ: 123 Abc, Hanoi, Vietnam<br  />Điện thoại: 234567666<br  />Email: info@vietnam.vn</span>\";}'), 
(55, 'default', 'global', 'global.html.php', 'right-footer', '', 'no_title', '[FOOTER2]', 0, 1, '0', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:993:\"<div style=\"text-align: right;\"> <strong><a href=\"/demo/dulich/\"><span style=\"color:rgb(105, 105, 105);\">TRANG CHỦ</span></a><span style=\"color:rgb(105, 105, 105);\">&nbsp; |&nbsp;</span><a href=\"/demo/dulich/news/\"><span style=\"color:rgb(105, 105, 105);\"> TIN TỨC VHTTDL</span></a><span style=\"color:rgb(105, 105, 105);\">&nbsp; | </span><a href=\"/demo/dulich/shops/\"><span style=\"color:rgb(105, 105, 105);\">TOURS</span></a><span style=\"color:rgb(105, 105, 105);\">&nbsp; |&nbsp; </span><a href=\"/demo/dulich/rental/\"><span style=\"color:rgb(105, 105, 105);\">XE DU LỊCH</span></a><span style=\"color:rgb(105, 105, 105);\">&nbsp; |&nbsp; </span><a href=\"/demo/dulich/contact/\"><span style=\"color:rgb(105, 105, 105);\">LIÊN HỆ</span></a><span style=\"color:rgb(105, 105, 105);\">&nbsp;</span>&nbsp;&nbsp;&nbsp; <a href=\"#top\"><span style=\"color:rgb(255, 140, 0);\">[^]</span></a></strong><br  /> <span style=\"color:rgb(128, 128, 128);\">2014 © VietnamTourist . Develope by LeVietpro</span></div>\";}'), 
(56, 'default', 'news', 'module.block_newscenter.php', 'News center', '', '', '[TOP]', 0, 1, '0', 0, 3, ''), 
(58, 'default', 'news', 'global.block_slide_showbiz.php', 'tin home', '', 'no_title', '[HEADER]', 0, 1, '0', 0, 3, 'a:2:{s:7:\"blockid\";i:1;s:6:\"numrow\";i:10;}'), 
(62, 'default', 'shops', 'global.block_cart.php', 'Giỏ hàng - tour', '', 'no_title', '[SOCIAL]', 0, 1, '0', 0, 2, '');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_blocks_weight`
--

DROP TABLE IF EXISTS `vt_vi_blocks_weight`;
CREATE TABLE `vt_vi_blocks_weight` (
  `bid` int(11) NOT NULL DEFAULT '0',
  `func_id` int(11) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_blocks_weight`
--

INSERT INTO `vt_vi_blocks_weight` VALUES
(1, 5, 1), 
(1, 6, 1), 
(1, 7, 1), 
(1, 13, 1), 
(1, 15, 1), 
(1, 16, 1), 
(9, 7, 1), 
(10, 2, 1), 
(10, 36, 1), 
(10, 39, 1), 
(10, 42, 1), 
(10, 43, 1), 
(10, 27, 1), 
(10, 5, 1), 
(10, 6, 1), 
(10, 7, 1), 
(10, 13, 1), 
(10, 15, 1), 
(10, 16, 1), 
(10, 47, 1), 
(10, 46, 1), 
(10, 28, 1), 
(10, 29, 1), 
(10, 30, 1), 
(10, 31, 1), 
(10, 32, 1), 
(10, 33, 1), 
(10, 34, 1), 
(10, 17, 1), 
(10, 25, 1), 
(10, 24, 1), 
(10, 23, 1), 
(10, 22, 1), 
(10, 21, 1), 
(10, 20, 1), 
(10, 19, 1), 
(10, 18, 1), 
(10, 26, 1), 
(11, 2, 2), 
(11, 36, 2), 
(11, 39, 2), 
(11, 42, 2), 
(11, 43, 2), 
(11, 27, 2), 
(11, 5, 2), 
(11, 6, 2), 
(11, 7, 2), 
(11, 13, 2), 
(11, 15, 2), 
(11, 16, 2), 
(11, 47, 2), 
(11, 46, 2), 
(11, 28, 2), 
(11, 29, 2), 
(11, 30, 2), 
(11, 31, 2), 
(11, 32, 2), 
(11, 33, 2), 
(11, 34, 2), 
(11, 17, 2), 
(11, 25, 2), 
(11, 24, 2), 
(11, 23, 2), 
(11, 22, 2), 
(11, 21, 2), 
(11, 20, 2), 
(11, 19, 2), 
(11, 18, 2), 
(11, 26, 2), 
(12, 2, 3), 
(12, 36, 3), 
(12, 39, 3), 
(12, 42, 3), 
(12, 43, 3), 
(12, 27, 3), 
(12, 5, 3), 
(12, 6, 3), 
(12, 7, 3), 
(12, 13, 3), 
(12, 15, 3), 
(12, 16, 3), 
(12, 47, 3), 
(12, 46, 3), 
(12, 28, 3), 
(12, 29, 3), 
(12, 30, 3), 
(12, 31, 3), 
(12, 32, 3), 
(12, 33, 3), 
(12, 34, 3), 
(12, 17, 3), 
(12, 25, 3), 
(12, 24, 3), 
(12, 23, 3), 
(12, 22, 3), 
(12, 21, 3), 
(12, 20, 3), 
(12, 19, 3), 
(12, 18, 3), 
(12, 26, 3), 
(13, 2, 4), 
(13, 36, 4), 
(13, 39, 4), 
(13, 42, 4), 
(13, 43, 4), 
(13, 27, 4), 
(13, 5, 4), 
(13, 6, 4), 
(13, 7, 4), 
(13, 13, 4), 
(13, 15, 4), 
(13, 16, 4), 
(13, 47, 4), 
(13, 46, 4), 
(13, 28, 4), 
(13, 29, 4), 
(13, 30, 4), 
(13, 31, 4), 
(13, 32, 4), 
(13, 33, 4), 
(13, 34, 4), 
(13, 17, 4), 
(13, 25, 4), 
(13, 24, 4), 
(13, 23, 4), 
(13, 22, 4), 
(13, 21, 4), 
(13, 20, 4), 
(13, 19, 4), 
(13, 18, 4), 
(13, 26, 4), 
(14, 5, 5), 
(14, 6, 5), 
(14, 7, 5), 
(14, 13, 5), 
(14, 15, 5), 
(14, 16, 5), 
(15, 2, 1), 
(15, 36, 1), 
(15, 39, 1), 
(15, 42, 1), 
(15, 43, 1), 
(15, 27, 1), 
(15, 5, 1), 
(15, 6, 1), 
(15, 7, 1), 
(15, 13, 1), 
(15, 15, 1), 
(15, 16, 1), 
(15, 47, 1), 
(15, 46, 1), 
(15, 28, 1), 
(15, 29, 1), 
(15, 30, 1), 
(15, 31, 1), 
(15, 32, 1), 
(15, 33, 1), 
(15, 34, 1), 
(15, 17, 1), 
(15, 25, 1), 
(15, 24, 1), 
(15, 23, 1), 
(15, 22, 1), 
(15, 21, 1), 
(15, 20, 1), 
(15, 19, 1), 
(15, 18, 1), 
(15, 26, 1), 
(16, 2, 1), 
(16, 36, 1), 
(16, 39, 1), 
(16, 42, 1), 
(16, 43, 1), 
(16, 27, 1), 
(16, 5, 1), 
(16, 6, 1), 
(16, 7, 1), 
(16, 13, 1), 
(16, 15, 1), 
(16, 16, 1), 
(16, 47, 1), 
(16, 46, 1), 
(16, 33, 1), 
(16, 32, 1), 
(16, 30, 1), 
(16, 29, 1), 
(16, 31, 1), 
(16, 28, 1), 
(16, 34, 1), 
(16, 24, 1), 
(16, 20, 1), 
(16, 21, 1), 
(16, 26, 1), 
(16, 23, 1), 
(16, 18, 1), 
(16, 25, 1), 
(16, 17, 1), 
(16, 22, 1), 
(16, 19, 1), 
(17, 2, 1), 
(17, 36, 1), 
(17, 39, 1), 
(17, 42, 1), 
(17, 43, 1), 
(17, 27, 1), 
(17, 5, 1), 
(17, 6, 1), 
(17, 7, 1), 
(17, 13, 1), 
(17, 15, 1), 
(17, 16, 1), 
(17, 47, 1), 
(17, 46, 1), 
(17, 33, 1), 
(17, 32, 1), 
(17, 30, 1), 
(17, 29, 1), 
(17, 31, 1), 
(17, 28, 1), 
(17, 34, 1), 
(17, 24, 1), 
(17, 20, 1), 
(17, 21, 1), 
(17, 26, 1), 
(17, 23, 1), 
(17, 18, 1), 
(17, 25, 1), 
(17, 17, 1), 
(17, 22, 1), 
(17, 19, 1), 
(18, 2, 1), 
(18, 36, 1), 
(18, 39, 1), 
(18, 42, 1), 
(18, 43, 1), 
(18, 27, 1), 
(18, 5, 1), 
(18, 6, 1), 
(18, 7, 1), 
(18, 13, 1), 
(18, 15, 1), 
(18, 16, 1), 
(18, 47, 1), 
(18, 46, 1), 
(18, 33, 1), 
(18, 32, 1), 
(18, 30, 1), 
(18, 29, 1), 
(18, 31, 1), 
(18, 28, 1), 
(18, 34, 1), 
(18, 24, 1), 
(18, 20, 1), 
(18, 21, 1), 
(18, 26, 1), 
(18, 23, 1), 
(18, 18, 1), 
(18, 25, 1), 
(18, 17, 1), 
(18, 22, 1), 
(18, 19, 1), 
(17, 48, 1), 
(18, 48, 1), 
(16, 48, 1), 
(10, 48, 1), 
(11, 48, 2), 
(12, 48, 3), 
(13, 48, 4), 
(15, 48, 1), 
(20, 2, 1), 
(20, 36, 1), 
(20, 39, 1), 
(20, 42, 1), 
(20, 43, 1), 
(20, 27, 1), 
(20, 5, 1), 
(20, 6, 1), 
(20, 7, 1), 
(20, 13, 1), 
(20, 15, 1), 
(20, 16, 1), 
(20, 47, 1), 
(20, 46, 1), 
(20, 33, 1), 
(20, 32, 1), 
(20, 30, 1), 
(20, 29, 1), 
(20, 31, 1), 
(20, 28, 1), 
(20, 34, 1), 
(20, 48, 1), 
(20, 24, 1), 
(20, 20, 1), 
(20, 21, 1), 
(20, 26, 1), 
(20, 23, 1), 
(20, 18, 1), 
(20, 25, 1), 
(20, 17, 1), 
(20, 22, 1), 
(20, 19, 1), 
(16, 35, 1), 
(10, 35, 1), 
(11, 35, 2), 
(12, 35, 3), 
(13, 35, 4), 
(15, 35, 1), 
(18, 35, 1), 
(17, 35, 1), 
(20, 35, 1), 
(16, 50, 1), 
(10, 50, 1), 
(11, 50, 2), 
(12, 50, 3), 
(13, 50, 4), 
(15, 50, 1), 
(18, 50, 1), 
(17, 50, 1), 
(20, 50, 1), 
(17, 51, 1), 
(46, 172, 1), 
(46, 15, 1), 
(46, 144, 1), 
(46, 16, 1), 
(46, 158, 1), 
(46, 154, 1), 
(46, 51, 1), 
(46, 157, 1), 
(46, 150, 1), 
(46, 167, 1), 
(27, 5, 1), 
(27, 6, 1), 
(27, 7, 1), 
(20, 63, 1), 
(20, 79, 1), 
(20, 59, 1), 
(20, 75, 1), 
(20, 54, 1), 
(20, 66, 1), 
(20, 67, 1), 
(20, 56, 1), 
(20, 61, 1), 
(20, 60, 1), 
(18, 63, 1), 
(18, 79, 1), 
(18, 59, 1), 
(18, 75, 1), 
(18, 54, 1), 
(18, 66, 1), 
(18, 67, 1), 
(18, 56, 1), 
(18, 61, 1), 
(18, 60, 1), 
(16, 63, 1), 
(16, 79, 1), 
(16, 59, 1), 
(16, 75, 1), 
(16, 54, 1), 
(16, 66, 1), 
(16, 67, 1), 
(16, 56, 1), 
(16, 61, 1), 
(16, 60, 1), 
(10, 63, 1), 
(10, 79, 1), 
(10, 59, 1), 
(10, 75, 1), 
(10, 54, 1), 
(10, 66, 1), 
(10, 67, 1), 
(10, 56, 1), 
(10, 61, 1), 
(10, 60, 1), 
(11, 63, 2), 
(11, 79, 2), 
(11, 59, 2), 
(11, 75, 2), 
(11, 54, 2), 
(11, 66, 2), 
(11, 67, 2), 
(11, 56, 2), 
(11, 61, 2), 
(11, 60, 2), 
(12, 63, 3), 
(12, 79, 3), 
(12, 59, 3), 
(12, 75, 3), 
(12, 54, 3), 
(12, 66, 3), 
(12, 67, 3), 
(12, 56, 3), 
(12, 61, 3), 
(12, 60, 3), 
(13, 63, 4), 
(13, 79, 4), 
(13, 59, 4), 
(13, 75, 4), 
(13, 54, 4), 
(13, 66, 4), 
(13, 67, 4), 
(13, 56, 4), 
(13, 61, 4), 
(13, 60, 4), 
(15, 63, 1), 
(15, 79, 1), 
(15, 59, 1), 
(15, 75, 1), 
(15, 54, 1), 
(15, 66, 1), 
(15, 67, 1), 
(15, 56, 1), 
(15, 61, 1), 
(15, 60, 1), 
(17, 91, 1), 
(17, 103, 1), 
(17, 87, 1), 
(17, 99, 1), 
(17, 82, 1), 
(17, 92, 1), 
(17, 93, 1), 
(17, 84, 1), 
(17, 89, 1), 
(17, 88, 1), 
(20, 91, 1), 
(20, 103, 1), 
(20, 87, 1), 
(20, 99, 1), 
(20, 82, 1), 
(20, 92, 1), 
(20, 93, 1), 
(20, 84, 1), 
(20, 89, 1), 
(20, 88, 1), 
(18, 91, 1), 
(18, 103, 1), 
(18, 87, 1), 
(18, 99, 1), 
(18, 82, 1), 
(18, 92, 1), 
(18, 93, 1), 
(18, 84, 1), 
(18, 89, 1), 
(18, 88, 1), 
(16, 91, 1), 
(16, 103, 1), 
(16, 87, 1), 
(16, 99, 1), 
(16, 82, 1), 
(16, 92, 1), 
(16, 93, 1), 
(16, 84, 1), 
(16, 89, 1), 
(16, 88, 1), 
(10, 91, 1), 
(10, 103, 1), 
(10, 87, 1), 
(10, 99, 1), 
(10, 82, 1), 
(10, 92, 1), 
(10, 93, 1), 
(10, 84, 1), 
(10, 89, 1), 
(10, 88, 1), 
(11, 91, 2), 
(11, 103, 2), 
(11, 87, 2), 
(11, 99, 2), 
(11, 82, 2), 
(11, 92, 2), 
(11, 93, 2), 
(11, 84, 2), 
(11, 89, 2), 
(11, 88, 2), 
(12, 91, 3), 
(12, 103, 3), 
(12, 87, 3), 
(12, 99, 3), 
(12, 82, 3), 
(12, 92, 3), 
(12, 93, 3), 
(12, 84, 3), 
(12, 89, 3), 
(12, 88, 3), 
(13, 91, 4), 
(13, 103, 4), 
(13, 87, 4), 
(13, 99, 4), 
(13, 82, 4), 
(13, 92, 4), 
(13, 93, 4), 
(13, 84, 4), 
(13, 89, 4), 
(13, 88, 4), 
(15, 91, 1), 
(15, 103, 1), 
(15, 87, 1), 
(15, 99, 1), 
(15, 82, 1), 
(15, 92, 1), 
(15, 93, 1), 
(15, 84, 1), 
(15, 89, 1), 
(15, 88, 1), 
(27, 16, 1), 
(27, 51, 1), 
(27, 15, 1), 
(27, 13, 1), 
(46, 43, 1), 
(46, 6, 1), 
(46, 13, 1), 
(46, 39, 1), 
(46, 36, 1), 
(46, 7, 1), 
(46, 27, 1), 
(46, 5, 1), 
(46, 42, 1), 
(46, 2, 1), 
(17, 141, 1), 
(17, 140, 1), 
(17, 137, 1), 
(17, 138, 1), 
(20, 116, 1), 
(20, 134, 1), 
(20, 112, 1), 
(20, 129, 1), 
(20, 106, 1), 
(20, 119, 1), 
(20, 120, 1), 
(20, 109, 1), 
(20, 114, 1), 
(20, 113, 1), 
(20, 130, 1), 
(20, 118, 1), 
(20, 125, 1), 
(20, 121, 1), 
(18, 116, 1), 
(18, 134, 1), 
(18, 112, 1), 
(18, 129, 1), 
(18, 106, 1), 
(18, 119, 1), 
(18, 120, 1), 
(18, 109, 1), 
(18, 114, 1), 
(18, 113, 1), 
(18, 130, 1), 
(18, 118, 1), 
(18, 125, 1), 
(18, 121, 1), 
(16, 116, 1), 
(16, 134, 1), 
(16, 112, 1), 
(16, 129, 1), 
(16, 106, 1), 
(16, 119, 1), 
(16, 120, 1), 
(16, 109, 1), 
(16, 114, 1), 
(16, 113, 1), 
(16, 130, 1), 
(16, 118, 1), 
(16, 125, 1), 
(16, 121, 1), 
(10, 116, 1), 
(10, 134, 1), 
(10, 112, 1), 
(10, 129, 1), 
(10, 106, 1), 
(10, 119, 1), 
(10, 120, 1), 
(10, 109, 1), 
(10, 114, 1), 
(10, 113, 1), 
(10, 130, 1), 
(10, 118, 1), 
(10, 125, 1), 
(10, 121, 1), 
(11, 116, 2), 
(11, 134, 2), 
(11, 112, 2), 
(11, 129, 2), 
(11, 106, 2), 
(11, 119, 2), 
(11, 120, 2), 
(11, 109, 2), 
(11, 114, 2), 
(11, 113, 2), 
(11, 130, 2), 
(11, 118, 2), 
(11, 125, 2), 
(11, 121, 2), 
(12, 116, 3), 
(12, 134, 3), 
(12, 112, 3), 
(12, 129, 3), 
(12, 106, 3), 
(12, 119, 3), 
(12, 120, 3), 
(12, 109, 3), 
(12, 114, 3), 
(12, 113, 3), 
(12, 130, 3), 
(12, 118, 3), 
(12, 125, 3), 
(12, 121, 3), 
(13, 116, 4), 
(13, 134, 4), 
(13, 112, 4), 
(13, 129, 4), 
(13, 106, 4), 
(13, 119, 4), 
(13, 120, 4), 
(13, 109, 4), 
(13, 114, 4), 
(13, 113, 4), 
(13, 130, 4), 
(13, 118, 4), 
(13, 125, 4), 
(13, 121, 4), 
(15, 116, 1), 
(15, 134, 1), 
(15, 112, 1), 
(15, 129, 1), 
(15, 106, 1), 
(15, 119, 1), 
(15, 120, 1), 
(15, 109, 1), 
(15, 114, 1), 
(15, 113, 1), 
(15, 130, 1), 
(15, 118, 1), 
(15, 125, 1), 
(15, 121, 1), 
(29, 2, 1), 
(29, 36, 1), 
(29, 39, 1), 
(29, 42, 1), 
(29, 43, 1), 
(29, 27, 1), 
(29, 5, 2), 
(29, 6, 2), 
(29, 7, 2), 
(29, 13, 2), 
(29, 15, 2), 
(29, 16, 2), 
(29, 51, 1), 
(29, 47, 1), 
(29, 46, 1), 
(41, 43, 2), 
(62, 181, 2), 
(41, 6, 3), 
(41, 13, 3), 
(41, 39, 2), 
(41, 36, 2), 
(41, 7, 3), 
(41, 27, 2), 
(41, 5, 3), 
(41, 42, 2), 
(41, 2, 2), 
(29, 33, 1), 
(29, 32, 1), 
(29, 30, 1), 
(29, 29, 1), 
(29, 31, 1), 
(29, 28, 1), 
(29, 34, 1), 
(62, 189, 2), 
(62, 203, 2), 
(62, 188, 2), 
(62, 175, 2), 
(62, 182, 2), 
(29, 24, 1), 
(29, 48, 1), 
(29, 50, 1), 
(29, 20, 1), 
(29, 21, 1), 
(29, 26, 1), 
(29, 23, 1), 
(29, 18, 1), 
(29, 25, 1), 
(29, 17, 1), 
(29, 22, 1), 
(29, 19, 1), 
(29, 35, 1), 
(35, 185, 1), 
(17, 154, 1), 
(17, 172, 1), 
(17, 150, 1), 
(17, 167, 1), 
(17, 144, 1), 
(17, 157, 1), 
(17, 158, 1), 
(17, 147, 1), 
(17, 152, 1), 
(17, 151, 1), 
(17, 168, 1), 
(17, 156, 1), 
(17, 163, 1), 
(17, 159, 1), 
(20, 154, 1), 
(20, 172, 1), 
(20, 150, 1), 
(20, 167, 1), 
(20, 144, 1), 
(20, 157, 1), 
(20, 158, 1), 
(20, 147, 1), 
(20, 152, 1), 
(20, 151, 1), 
(20, 168, 1), 
(20, 156, 1), 
(20, 163, 1), 
(20, 159, 1), 
(18, 154, 1), 
(18, 172, 1), 
(18, 150, 1), 
(18, 167, 1), 
(18, 144, 1), 
(18, 157, 1), 
(18, 158, 1), 
(18, 147, 1), 
(18, 152, 1), 
(18, 151, 1), 
(18, 168, 1), 
(18, 156, 1), 
(18, 163, 1), 
(18, 159, 1), 
(16, 154, 1), 
(16, 172, 1), 
(16, 150, 1), 
(16, 167, 1), 
(16, 144, 1), 
(16, 157, 1), 
(16, 158, 1), 
(16, 147, 1), 
(16, 152, 1), 
(16, 151, 1), 
(16, 168, 1), 
(16, 156, 1), 
(16, 163, 1), 
(16, 159, 1), 
(10, 154, 1), 
(10, 172, 1), 
(10, 150, 1), 
(10, 167, 1), 
(10, 144, 1), 
(10, 157, 1), 
(10, 158, 1), 
(10, 147, 1), 
(10, 152, 1), 
(10, 151, 1), 
(10, 168, 1), 
(10, 156, 1), 
(10, 163, 1), 
(10, 159, 1), 
(11, 154, 2), 
(11, 172, 2), 
(11, 150, 2), 
(11, 167, 2), 
(11, 144, 2), 
(11, 157, 2), 
(11, 158, 2), 
(11, 147, 2), 
(11, 152, 2), 
(11, 151, 2), 
(11, 168, 2), 
(11, 156, 2), 
(11, 163, 2), 
(11, 159, 2), 
(12, 154, 3), 
(12, 172, 3), 
(12, 150, 3), 
(12, 167, 3), 
(12, 144, 3), 
(12, 157, 3), 
(12, 158, 3), 
(12, 147, 3), 
(12, 152, 3), 
(12, 151, 3), 
(12, 168, 3), 
(12, 156, 3), 
(12, 163, 3), 
(12, 159, 3), 
(13, 154, 4), 
(13, 172, 4), 
(13, 150, 4), 
(13, 167, 4), 
(13, 144, 4), 
(13, 157, 4), 
(13, 158, 4), 
(13, 147, 4), 
(13, 152, 4), 
(13, 151, 4), 
(13, 168, 4), 
(13, 156, 4), 
(13, 163, 4), 
(13, 159, 4), 
(15, 154, 1), 
(15, 172, 1), 
(15, 150, 1), 
(15, 167, 1), 
(15, 144, 1), 
(15, 157, 1), 
(15, 158, 1), 
(15, 147, 1), 
(15, 152, 1), 
(15, 151, 1), 
(15, 168, 1), 
(15, 156, 1), 
(15, 163, 1), 
(15, 159, 1), 
(17, 185, 1), 
(17, 203, 1), 
(17, 181, 1), 
(17, 198, 1), 
(17, 175, 1), 
(17, 188, 1), 
(17, 189, 1), 
(17, 178, 1), 
(17, 183, 1), 
(17, 182, 1), 
(17, 199, 1), 
(17, 187, 1), 
(17, 194, 1), 
(17, 190, 1), 
(29, 185, 1), 
(29, 203, 1), 
(29, 181, 1), 
(29, 198, 1), 
(29, 175, 1), 
(29, 188, 1), 
(29, 189, 1), 
(29, 178, 1), 
(29, 183, 1), 
(29, 182, 1), 
(29, 199, 1), 
(29, 187, 1), 
(29, 194, 1), 
(29, 190, 1), 
(20, 185, 1), 
(20, 203, 1), 
(20, 181, 1), 
(20, 198, 1), 
(20, 175, 1), 
(20, 188, 1), 
(20, 189, 1), 
(20, 178, 1), 
(20, 183, 1), 
(20, 182, 1), 
(20, 199, 1), 
(20, 187, 1), 
(20, 194, 1), 
(20, 190, 1), 
(18, 185, 1), 
(18, 203, 1), 
(18, 181, 1), 
(18, 198, 1), 
(18, 175, 1), 
(18, 188, 1), 
(18, 189, 1), 
(18, 178, 1), 
(18, 183, 1), 
(18, 182, 1), 
(18, 199, 1), 
(18, 187, 1), 
(18, 194, 1), 
(18, 190, 1), 
(16, 185, 1), 
(16, 203, 1), 
(16, 181, 1), 
(16, 198, 1), 
(16, 175, 1), 
(16, 188, 1), 
(16, 189, 1), 
(16, 178, 1), 
(16, 183, 1), 
(16, 182, 1), 
(16, 199, 1), 
(16, 187, 1), 
(16, 194, 1), 
(16, 190, 1), 
(10, 185, 1), 
(10, 203, 1), 
(10, 181, 1), 
(10, 198, 1), 
(10, 175, 1), 
(10, 188, 1), 
(10, 189, 1), 
(10, 178, 1), 
(10, 183, 1), 
(10, 182, 1), 
(10, 199, 1), 
(10, 187, 1), 
(10, 194, 1), 
(10, 190, 1), 
(11, 185, 2), 
(11, 203, 2), 
(11, 181, 2), 
(11, 198, 2), 
(11, 175, 2), 
(11, 188, 2), 
(11, 189, 2), 
(11, 178, 2), 
(11, 183, 2), 
(11, 182, 2), 
(11, 199, 2), 
(11, 187, 2), 
(11, 194, 2), 
(11, 190, 2), 
(12, 185, 3), 
(12, 203, 3), 
(12, 181, 3), 
(12, 198, 3), 
(12, 175, 3), 
(12, 188, 3), 
(12, 189, 3), 
(12, 178, 3), 
(12, 183, 3), 
(12, 182, 3), 
(12, 199, 3), 
(12, 187, 3), 
(12, 194, 3), 
(12, 190, 3), 
(13, 185, 4), 
(13, 203, 4), 
(13, 181, 4), 
(13, 198, 4), 
(13, 175, 4), 
(13, 188, 4), 
(13, 189, 4), 
(13, 178, 4), 
(13, 183, 4), 
(13, 182, 4), 
(13, 199, 4), 
(13, 187, 4), 
(13, 194, 4), 
(13, 190, 4), 
(15, 185, 1), 
(15, 203, 1), 
(15, 181, 1), 
(15, 198, 1), 
(15, 175, 1), 
(15, 188, 1), 
(15, 189, 1), 
(15, 178, 1), 
(15, 183, 1), 
(15, 182, 1), 
(15, 199, 1), 
(15, 187, 1), 
(15, 194, 1), 
(15, 190, 1), 
(41, 15, 3), 
(41, 16, 3), 
(41, 51, 2), 
(41, 47, 2), 
(41, 46, 2), 
(41, 185, 2), 
(41, 203, 2), 
(41, 181, 2), 
(41, 198, 2), 
(41, 175, 2), 
(41, 188, 2), 
(41, 189, 2), 
(41, 178, 2), 
(41, 183, 2), 
(41, 182, 2), 
(41, 199, 2), 
(41, 187, 2), 
(41, 194, 2), 
(41, 190, 2), 
(41, 33, 2), 
(41, 32, 2), 
(41, 30, 2), 
(41, 29, 2), 
(41, 31, 2), 
(41, 28, 2), 
(41, 34, 2), 
(41, 91, 2), 
(41, 103, 2), 
(41, 87, 2), 
(41, 99, 2), 
(41, 82, 2), 
(41, 92, 2), 
(41, 93, 2), 
(41, 84, 2), 
(41, 89, 2), 
(41, 88, 2), 
(41, 141, 2), 
(41, 137, 2), 
(41, 140, 2), 
(41, 138, 2), 
(41, 48, 2), 
(41, 50, 2), 
(41, 24, 2), 
(41, 20, 2), 
(41, 21, 2), 
(41, 26, 2), 
(41, 23, 2), 
(41, 18, 2), 
(41, 25, 2), 
(41, 17, 2), 
(41, 22, 2), 
(41, 19, 2), 
(41, 35, 2), 
(43, 2, 3), 
(43, 36, 3), 
(43, 39, 3), 
(43, 42, 3), 
(43, 43, 3), 
(43, 27, 3), 
(43, 5, 4), 
(43, 6, 4), 
(43, 7, 4), 
(43, 13, 4), 
(43, 15, 4), 
(43, 16, 4), 
(43, 51, 3), 
(43, 154, 2), 
(43, 172, 2), 
(43, 150, 2), 
(43, 167, 2), 
(43, 144, 2), 
(43, 157, 2), 
(43, 158, 2), 
(43, 147, 2), 
(43, 152, 2), 
(43, 151, 2), 
(43, 168, 2), 
(43, 156, 2), 
(43, 163, 2), 
(43, 159, 2), 
(43, 47, 3), 
(43, 46, 3), 
(43, 185, 3), 
(43, 203, 3), 
(43, 181, 3), 
(43, 198, 3), 
(43, 175, 3), 
(43, 188, 3), 
(43, 189, 3), 
(43, 178, 3), 
(43, 183, 3), 
(43, 182, 3), 
(43, 199, 3), 
(43, 187, 3), 
(43, 194, 3), 
(43, 190, 3), 
(43, 33, 3), 
(43, 32, 3), 
(43, 30, 3), 
(43, 29, 3), 
(43, 31, 3), 
(43, 28, 3), 
(43, 34, 3), 
(43, 91, 3), 
(43, 103, 3), 
(43, 87, 3), 
(43, 99, 3), 
(43, 82, 3), 
(43, 92, 3), 
(43, 93, 3), 
(43, 84, 3), 
(43, 89, 3), 
(43, 88, 3), 
(43, 141, 3), 
(43, 137, 3), 
(43, 140, 3), 
(43, 138, 3), 
(43, 48, 3), 
(43, 50, 3), 
(43, 24, 3), 
(43, 20, 3), 
(43, 21, 3), 
(43, 26, 3), 
(43, 23, 3), 
(43, 18, 3), 
(43, 25, 3), 
(43, 17, 3), 
(43, 22, 3), 
(43, 19, 3), 
(43, 35, 3), 
(41, 154, 3), 
(41, 172, 3), 
(41, 150, 3), 
(41, 167, 3), 
(41, 144, 3), 
(41, 157, 3), 
(41, 158, 3), 
(41, 147, 3), 
(41, 152, 3), 
(41, 151, 3), 
(41, 168, 3), 
(41, 156, 3), 
(41, 163, 3), 
(41, 159, 3), 
(45, 185, 1), 
(46, 147, 1), 
(46, 152, 1), 
(46, 151, 1), 
(46, 168, 1), 
(46, 156, 1), 
(46, 163, 1), 
(46, 159, 1), 
(46, 47, 1), 
(46, 46, 1), 
(46, 185, 1), 
(46, 203, 1), 
(46, 181, 1), 
(46, 198, 1), 
(46, 175, 1), 
(46, 188, 1), 
(46, 189, 1), 
(46, 178, 1), 
(46, 183, 1), 
(46, 182, 1), 
(46, 199, 1), 
(46, 187, 1), 
(46, 194, 1), 
(46, 190, 1), 
(46, 33, 1), 
(46, 32, 1), 
(46, 30, 1), 
(46, 29, 1), 
(46, 31, 1), 
(46, 28, 1), 
(46, 34, 1), 
(46, 48, 1), 
(46, 50, 1), 
(46, 24, 1), 
(46, 20, 1), 
(46, 21, 1), 
(46, 26, 1), 
(46, 23, 1), 
(46, 18, 1), 
(46, 25, 1), 
(46, 17, 1), 
(46, 22, 1), 
(46, 19, 1), 
(46, 35, 1), 
(17, 204, 1), 
(46, 204, 1), 
(20, 204, 1), 
(18, 204, 1), 
(16, 204, 1), 
(10, 204, 1), 
(11, 204, 2), 
(12, 204, 3), 
(13, 204, 4), 
(15, 204, 1), 
(49, 204, 1), 
(51, 204, 2), 
(54, 2, 1), 
(54, 36, 1), 
(54, 39, 1), 
(54, 42, 1), 
(54, 43, 1), 
(54, 27, 1), 
(54, 204, 1), 
(54, 5, 1), 
(54, 6, 1), 
(54, 7, 1), 
(54, 13, 1), 
(54, 15, 1), 
(54, 16, 1), 
(54, 51, 1), 
(54, 154, 1), 
(54, 172, 1), 
(54, 150, 1), 
(54, 167, 1), 
(54, 144, 1), 
(54, 157, 1), 
(54, 158, 1), 
(54, 147, 1), 
(54, 152, 1), 
(54, 151, 1), 
(54, 168, 1), 
(54, 156, 1), 
(54, 163, 1), 
(54, 159, 1), 
(54, 47, 1), 
(54, 46, 1), 
(54, 185, 1), 
(54, 203, 1), 
(54, 181, 1), 
(54, 198, 1), 
(54, 175, 1), 
(54, 188, 1), 
(54, 189, 1), 
(54, 178, 1), 
(54, 183, 1), 
(54, 182, 1), 
(54, 199, 1), 
(54, 187, 1), 
(54, 194, 1), 
(54, 190, 1), 
(54, 33, 1), 
(54, 32, 1), 
(54, 30, 1), 
(54, 29, 1), 
(54, 31, 1), 
(54, 28, 1), 
(54, 34, 1), 
(54, 91, 1), 
(54, 103, 1), 
(54, 87, 1), 
(54, 99, 1), 
(54, 82, 1), 
(54, 92, 1), 
(54, 93, 1), 
(54, 84, 1), 
(54, 89, 1), 
(54, 88, 1), 
(54, 141, 1), 
(54, 137, 1), 
(54, 140, 1), 
(54, 138, 1), 
(54, 24, 1), 
(54, 50, 1), 
(54, 48, 1), 
(54, 20, 1), 
(54, 21, 1), 
(54, 26, 1), 
(54, 23, 1), 
(54, 18, 1), 
(54, 25, 1), 
(54, 17, 1), 
(54, 22, 1), 
(54, 19, 1), 
(54, 35, 1), 
(55, 2, 1), 
(55, 36, 1), 
(55, 39, 1), 
(55, 42, 1), 
(55, 43, 1), 
(55, 27, 1), 
(55, 204, 1), 
(55, 5, 1), 
(55, 6, 1), 
(55, 7, 1), 
(55, 13, 1), 
(55, 15, 1), 
(55, 16, 1), 
(55, 51, 1), 
(55, 154, 1), 
(55, 172, 1), 
(55, 150, 1), 
(55, 167, 1), 
(55, 144, 1), 
(55, 157, 1), 
(55, 158, 1), 
(55, 147, 1), 
(55, 152, 1), 
(55, 151, 1), 
(55, 168, 1), 
(55, 156, 1), 
(55, 163, 1), 
(55, 159, 1), 
(55, 47, 1), 
(55, 46, 1), 
(55, 185, 1), 
(55, 203, 1), 
(55, 181, 1), 
(55, 198, 1), 
(55, 175, 1), 
(55, 188, 1), 
(55, 189, 1), 
(55, 178, 1), 
(55, 183, 1), 
(55, 182, 1), 
(55, 199, 1), 
(55, 187, 1), 
(55, 194, 1), 
(55, 190, 1), 
(55, 33, 1), 
(55, 32, 1), 
(55, 30, 1), 
(55, 29, 1), 
(55, 31, 1), 
(55, 28, 1), 
(55, 34, 1), 
(55, 24, 1), 
(55, 50, 1), 
(55, 48, 1), 
(55, 20, 1), 
(55, 21, 1), 
(55, 26, 1), 
(55, 23, 1), 
(55, 18, 1), 
(55, 25, 1), 
(55, 17, 1), 
(55, 22, 1), 
(55, 19, 1), 
(55, 35, 1), 
(56, 7, 1), 
(56, 13, 1), 
(56, 15, 1), 
(56, 16, 1), 
(56, 51, 1), 
(58, 204, 3);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_contact_rows`
--

DROP TABLE IF EXISTS `vt_vi_contact_rows`;
CREATE TABLE `vt_vi_contact_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `note` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_contact_rows`
--

INSERT INTO `vt_vi_contact_rows` VALUES
(1, 'Webmaster', '', '', '', '', '1/1/1/0;', 1);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_contact_send`
--

DROP TABLE IF EXISTS `vt_vi_contact_send`;
CREATE TABLE `vt_vi_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `sender_phone` varchar(255) NOT NULL,
  `sender_ip` varchar(15) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `reply_content` mediumtext NOT NULL,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_vi_counter`
--

DROP TABLE IF EXISTS `vt_vi_counter`;
CREATE TABLE `vt_vi_counter` (
  `c_type` varchar(100) NOT NULL,
  `c_val` varchar(100) NOT NULL,
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_counter`
--

INSERT INTO `vt_vi_counter` VALUES
('c_time', 'start', 0, 0), 
('c_time', 'last', 1419064498, 0), 
('total', 'hits', 96, 1419064498), 
('year', '2009', 0, 0), 
('year', '2010', 0, 0), 
('year', '2011', 0, 0), 
('year', '2012', 41, 1354584455), 
('year', '2013', 11, 1375538771), 
('year', '2014', 44, 1419064498), 
('year', '2015', 0, 0), 
('year', '2016', 0, 0), 
('year', '2017', 0, 0), 
('year', '2018', 0, 0), 
('year', '2019', 0, 0), 
('year', '2020', 0, 0), 
('month', 'Jan', 0, 1357117605), 
('month', 'Feb', 0, 0), 
('month', 'Mar', 0, 1363521112), 
('month', 'Apr', 0, 1366823004), 
('month', 'May', 0, 1368763370), 
('month', 'Jun', 0, 0), 
('month', 'Jul', 0, 0), 
('month', 'Aug', 0, 1375538771), 
('month', 'Sep', 0, 0), 
('month', 'Oct', 0, 0), 
('month', 'Nov', 1, 1417054899), 
('month', 'Dec', 43, 1419064498), 
('day', '01', 0, 1354348841), 
('day', '02', 0, 1357117605), 
('day', '03', 0, 1375538771), 
('day', '04', 0, 0), 
('day', '05', 0, 0), 
('day', '06', 2, 1417856002), 
('day', '07', 2, 1418003511), 
('day', '08', 4, 1418096560), 
('day', '09', 2, 1418174272), 
('day', '10', 1, 1418258908), 
('day', '11', 7, 1418344377), 
('day', '12', 8, 1418440450), 
('day', '13', 6, 1418520992), 
('day', '14', 4, 1418606436), 
('day', '15', 2, 1418702789), 
('day', '16', 1, 1418708079), 
('day', '17', 0, 1368763370), 
('day', '18', 2, 1418954949), 
('day', '19', 1, 1418968641), 
('day', '20', 1, 1419064498), 
('day', '21', 0, 1353558412), 
('day', '22', 0, 1353605502), 
('day', '23', 0, 0), 
('day', '24', 0, 1366823004), 
('day', '25', 0, 0), 
('day', '26', 0, 1417054899), 
('day', '27', 0, 1354064667), 
('day', '28', 0, 1354108349), 
('day', '29', 0, 1354201459), 
('day', '30', 0, 1354322811), 
('day', '31', 0, 0), 
('dayofweek', 'Sunday', 11, 1418606436), 
('dayofweek', 'Monday', 11, 1418702789), 
('dayofweek', 'Tuesday', 10, 1418708079), 
('dayofweek', 'Wednesday', 20, 1418258908), 
('dayofweek', 'Thursday', 12, 1418954949), 
('dayofweek', 'Friday', 17, 1418968641), 
('dayofweek', 'Saturday', 15, 1419064498), 
('hour', '00', 0, 1418968641), 
('hour', '01', 0, 0), 
('hour', '02', 0, 1418540861), 
('hour', '03', 1, 1419064498), 
('hour', '04', 0, 1418290815), 
('hour', '05', 0, 1418553597), 
('hour', '06', 0, 1418554956), 
('hour', '07', 0, 1418474253), 
('hour', '08', 0, 1418389596), 
('hour', '09', 0, 1418481342), 
('hour', '10', 0, 1375538771), 
('hour', '11', 0, 1353515589), 
('hour', '12', 0, 1353605502), 
('hour', '13', 0, 1366823004), 
('hour', '14', 0, 0), 
('hour', '15', 0, 0), 
('hour', '16', 0, 1353533538), 
('hour', '17', 0, 1363383350), 
('hour', '18', 0, 0), 
('hour', '19', 0, 1418949403), 
('hour', '20', 0, 1418606436), 
('hour', '21', 0, 1418954949), 
('hour', '22', 0, 1418440450), 
('hour', '23', 0, 1418702789), 
('bot', 'Alexa', 10, 1368763370), 
('bot', 'AltaVista Scooter', 0, 0), 
('bot', 'Altavista Mercator', 0, 0), 
('bot', 'Altavista Search', 0, 0), 
('bot', 'Aport.ru Bot', 0, 0), 
('bot', 'Ask Jeeves', 0, 0), 
('bot', 'Baidu', 0, 0), 
('bot', 'Exabot', 0, 0), 
('bot', 'FAST Enterprise', 0, 0), 
('bot', 'FAST WebCrawler', 0, 0), 
('bot', 'Francis', 0, 0), 
('bot', 'Gigablast', 0, 0), 
('bot', 'Google AdsBot', 0, 0), 
('bot', 'Google Adsense', 0, 0), 
('bot', 'Google Bot', 0, 0), 
('bot', 'Google Desktop', 0, 0), 
('bot', 'Google Feedfetcher', 0, 0), 
('bot', 'Heise IT-Markt', 0, 0), 
('bot', 'Heritrix', 0, 0), 
('bot', 'IBM Research', 0, 0), 
('bot', 'ICCrawler - ICjobs', 0, 0), 
('bot', 'Ichiro', 0, 0), 
('bot', 'InfoSeek Spider', 0, 0), 
('bot', 'Lycos.com Bot', 0, 0), 
('bot', 'MSN Bot', 0, 0), 
('bot', 'MSN Bot Media', 0, 0), 
('bot', 'MSN Bot News', 0, 0), 
('bot', 'MSN NewsBlogs', 0, 0), 
('bot', 'Majestic-12', 0, 0), 
('bot', 'Metager', 0, 0), 
('bot', 'NG-Search', 0, 0), 
('bot', 'Nutch Bot', 0, 0), 
('bot', 'NutchCVS', 0, 0), 
('bot', 'OmniExplorer', 0, 0), 
('bot', 'Online Link Validator', 0, 0), 
('bot', 'Open-source Web Search', 0, 0), 
('bot', 'Psbot', 0, 0), 
('bot', 'Rambler', 0, 0), 
('bot', 'SEO Crawler', 0, 0), 
('bot', 'SEOSearch', 0, 0), 
('bot', 'Seekport', 0, 0), 
('bot', 'Sensis', 0, 0), 
('bot', 'Seoma', 0, 0), 
('bot', 'Snappy', 0, 0), 
('bot', 'Steeler', 0, 0), 
('bot', 'Synoo', 0, 0), 
('bot', 'Telekom', 0, 0), 
('bot', 'TurnitinBot', 0, 0), 
('bot', 'Vietnamese Search', 0, 0), 
('bot', 'Voyager', 0, 0), 
('bot', 'W3 Sitesearch', 0, 0), 
('bot', 'W3C Linkcheck', 0, 0), 
('bot', 'W3C Validator', 1, 1418372360), 
('bot', 'WiseNut', 0, 0), 
('bot', 'YaCy', 0, 0), 
('bot', 'Yahoo Bot', 0, 0), 
('bot', 'Yahoo MMCrawler', 0, 0), 
('bot', 'Yahoo Slurp', 0, 0), 
('bot', 'YahooSeeker', 0, 0), 
('bot', 'Yandex', 0, 0), 
('bot', 'Yandex Blog', 0, 0), 
('bot', 'Yandex Direct Bot', 0, 0), 
('bot', 'Yandex Something', 0, 0), 
('browser', 'netcaptor', 0, 0), 
('browser', 'opera', 0, 0), 
('browser', 'aol', 0, 0), 
('browser', 'aol2', 0, 0), 
('browser', 'mosaic', 0, 0), 
('browser', 'k-meleon', 0, 0), 
('browser', 'konqueror', 0, 0), 
('browser', 'avantbrowser', 0, 0), 
('browser', 'avantgo', 0, 0), 
('browser', 'proxomitron', 0, 0), 
('browser', 'chrome', 41, 1419064498), 
('browser', 'safari', 0, 0), 
('browser', 'lynx', 0, 0), 
('browser', 'links', 0, 0), 
('browser', 'galeon', 0, 0), 
('browser', 'abrowse', 0, 0), 
('browser', 'amaya', 0, 0), 
('browser', 'ant', 0, 0), 
('browser', 'aweb', 0, 0), 
('browser', 'beonex', 0, 0), 
('browser', 'blazer', 0, 0), 
('browser', 'camino', 0, 0), 
('browser', 'chimera', 0, 0), 
('browser', 'columbus', 0, 0), 
('browser', 'crazybrowser', 0, 0), 
('browser', 'curl', 0, 0), 
('browser', 'deepnet', 0, 0), 
('browser', 'dillo', 0, 0), 
('browser', 'doris', 0, 0), 
('browser', 'elinks', 0, 0), 
('browser', 'epiphany', 0, 0), 
('browser', 'ibrowse', 0, 0), 
('browser', 'icab', 0, 0), 
('browser', 'ice', 0, 0), 
('browser', 'isilox', 0, 0), 
('browser', 'lotus', 0, 0), 
('browser', 'lunascape', 0, 0), 
('browser', 'maxthon', 0, 0), 
('browser', 'mbrowser', 0, 0), 
('browser', 'multibrowser', 0, 0), 
('browser', 'nautilus', 0, 0), 
('browser', 'netfront', 0, 0), 
('browser', 'netpositive', 0, 0), 
('browser', 'omniweb', 0, 0), 
('browser', 'oregano', 0, 0), 
('browser', 'phaseout', 0, 0), 
('browser', 'plink', 0, 0), 
('browser', 'phoenix', 0, 0), 
('browser', 'shiira', 0, 0), 
('browser', 'sleipnir', 0, 0), 
('browser', 'slimbrowser', 0, 0), 
('browser', 'staroffice', 0, 0), 
('browser', 'sunrise', 0, 0), 
('browser', 'voyager', 0, 0), 
('browser', 'w3m', 0, 0), 
('browser', 'webtv', 0, 0), 
('browser', 'xiino', 0, 0), 
('browser', 'explorer', 5, 1353558412), 
('browser', 'firefox', 23, 1418968641), 
('browser', 'netscape', 0, 0), 
('browser', 'netscape2', 0, 0), 
('browser', 'mozilla', 0, 0), 
('browser', 'mozilla2', 0, 0), 
('browser', 'firebird', 0, 0), 
('browser', 'Mobile', 8, 1418708079), 
('browser', 'Unknown', 19, 1418481342), 
('os', 'windows7', 37, 1419064498), 
('os', 'windowsvista', 0, 0), 
('os', 'windows2003', 0, 0), 
('os', 'windowsxp', 0, 0), 
('os', 'windowsxp2', 29, 1375538771), 
('os', 'windows2k', 0, 0), 
('os', 'windows95', 0, 0), 
('os', 'windowsce', 0, 0), 
('os', 'windowsme', 0, 0), 
('os', 'windowsme2', 0, 0), 
('os', 'windowsnt', 0, 0), 
('os', 'windowsnt2', 3, 1418954949), 
('os', 'windows98', 0, 0), 
('os', 'windows', 0, 0), 
('os', 'linux', 0, 0), 
('os', 'linux2', 0, 0), 
('os', 'linux3', 2, 1418309312), 
('os', 'macosx', 0, 0), 
('os', 'macppc', 0, 0), 
('os', 'mac', 0, 0), 
('os', 'amiga', 0, 0), 
('os', 'beos', 0, 0), 
('os', 'freebsd', 0, 0), 
('os', 'freebsd2', 0, 0), 
('os', 'irix', 0, 0), 
('os', 'netbsd', 0, 0), 
('os', 'netbsd2', 0, 0), 
('os', 'os2', 0, 0), 
('os', 'os22', 0, 0), 
('os', 'openbsd', 0, 0), 
('os', 'openbsd2', 0, 0), 
('os', 'palm', 0, 0), 
('os', 'palm2', 0, 0), 
('os', 'Unspecified', 14, 1418708079), 
('country', 'AD', 0, 0), 
('country', 'AE', 0, 0), 
('country', 'AF', 0, 0), 
('country', 'AG', 0, 0), 
('country', 'AI', 0, 0), 
('country', 'AL', 0, 0), 
('country', 'AM', 0, 0), 
('country', 'AN', 0, 0), 
('country', 'AO', 0, 0), 
('country', 'AQ', 0, 0), 
('country', 'AR', 0, 0), 
('country', 'AS', 0, 0), 
('country', 'AT', 0, 0), 
('country', 'AU', 0, 0), 
('country', 'AW', 0, 0), 
('country', 'AZ', 0, 0), 
('country', 'BA', 0, 0), 
('country', 'BB', 0, 0), 
('country', 'BD', 0, 0), 
('country', 'BE', 0, 0), 
('country', 'BF', 0, 0), 
('country', 'BG', 0, 0), 
('country', 'BH', 0, 0), 
('country', 'BI', 0, 0), 
('country', 'BJ', 0, 0), 
('country', 'BM', 0, 0), 
('country', 'BN', 0, 0), 
('country', 'BO', 0, 0), 
('country', 'BR', 0, 0), 
('country', 'BS', 0, 0), 
('country', 'BT', 0, 0), 
('country', 'BW', 0, 0), 
('country', 'BY', 0, 0), 
('country', 'BZ', 0, 0), 
('country', 'CA', 0, 0), 
('country', 'CD', 0, 0), 
('country', 'CF', 0, 0), 
('country', 'CG', 0, 0), 
('country', 'CH', 0, 0), 
('country', 'CI', 0, 0), 
('country', 'CK', 0, 0), 
('country', 'CL', 0, 0), 
('country', 'CM', 0, 0), 
('country', 'CN', 0, 0), 
('country', 'CO', 0, 0), 
('country', 'CR', 0, 0), 
('country', 'CS', 0, 0), 
('country', 'CU', 0, 0), 
('country', 'CV', 0, 0), 
('country', 'CY', 0, 0), 
('country', 'CZ', 0, 0), 
('country', 'DE', 0, 0), 
('country', 'DJ', 0, 0), 
('country', 'DK', 0, 0), 
('country', 'DM', 0, 0), 
('country', 'DO', 0, 0), 
('country', 'DZ', 0, 0), 
('country', 'EC', 0, 0), 
('country', 'EE', 0, 0), 
('country', 'EG', 0, 0), 
('country', 'ER', 0, 0), 
('country', 'ES', 0, 0), 
('country', 'ET', 0, 0), 
('country', 'EU', 0, 0), 
('country', 'FI', 0, 0), 
('country', 'FJ', 0, 0), 
('country', 'FK', 0, 0), 
('country', 'FM', 0, 0), 
('country', 'FO', 0, 0), 
('country', 'FR', 0, 0), 
('country', 'GA', 0, 0), 
('country', 'GB', 0, 0), 
('country', 'GD', 0, 0), 
('country', 'GE', 0, 0), 
('country', 'GF', 0, 0), 
('country', 'GH', 0, 0), 
('country', 'GI', 0, 0), 
('country', 'GL', 0, 0), 
('country', 'GM', 0, 0), 
('country', 'GN', 0, 0), 
('country', 'GP', 0, 0), 
('country', 'GQ', 0, 0), 
('country', 'GR', 0, 0), 
('country', 'GS', 0, 0), 
('country', 'GT', 0, 0), 
('country', 'GU', 0, 0), 
('country', 'GW', 0, 0), 
('country', 'GY', 0, 0), 
('country', 'HK', 0, 0), 
('country', 'HN', 0, 0), 
('country', 'HR', 0, 0), 
('country', 'HT', 0, 0), 
('country', 'HU', 0, 0), 
('country', 'ID', 0, 0), 
('country', 'IE', 0, 0), 
('country', 'IL', 0, 0), 
('country', 'IN', 0, 0), 
('country', 'IO', 0, 0), 
('country', 'IQ', 0, 0), 
('country', 'IR', 0, 0), 
('country', 'IS', 0, 0), 
('country', 'IT', 0, 0), 
('country', 'JM', 0, 0), 
('country', 'JO', 0, 0), 
('country', 'JP', 0, 0), 
('country', 'KE', 0, 0), 
('country', 'KG', 0, 0), 
('country', 'KH', 0, 0), 
('country', 'KI', 0, 0), 
('country', 'KM', 0, 0), 
('country', 'KN', 0, 0), 
('country', 'KR', 0, 0), 
('country', 'KW', 0, 0), 
('country', 'KY', 0, 0), 
('country', 'KZ', 0, 0), 
('country', 'LA', 0, 0), 
('country', 'LB', 0, 0), 
('country', 'LC', 0, 0), 
('country', 'LI', 0, 0), 
('country', 'LK', 0, 0), 
('country', 'LR', 0, 0), 
('country', 'LS', 0, 0), 
('country', 'LT', 0, 0), 
('country', 'LU', 0, 0), 
('country', 'LV', 0, 0), 
('country', 'LY', 0, 0), 
('country', 'MA', 0, 0), 
('country', 'MC', 0, 0), 
('country', 'MD', 0, 0), 
('country', 'MG', 0, 0), 
('country', 'MH', 0, 0), 
('country', 'MK', 0, 0), 
('country', 'ML', 0, 0), 
('country', 'MM', 0, 0), 
('country', 'MN', 0, 0), 
('country', 'MO', 0, 0), 
('country', 'MP', 0, 0), 
('country', 'MQ', 0, 0), 
('country', 'MR', 0, 0), 
('country', 'MT', 0, 0), 
('country', 'MU', 0, 0), 
('country', 'MV', 0, 0), 
('country', 'MW', 0, 0), 
('country', 'MX', 0, 0), 
('country', 'MY', 0, 0), 
('country', 'MZ', 0, 0), 
('country', 'NA', 0, 0), 
('country', 'NC', 0, 0), 
('country', 'NE', 0, 0), 
('country', 'NF', 0, 0), 
('country', 'NG', 0, 0), 
('country', 'NI', 0, 0), 
('country', 'NL', 0, 0), 
('country', 'NO', 0, 0), 
('country', 'NP', 0, 0), 
('country', 'NR', 0, 0), 
('country', 'NU', 0, 0), 
('country', 'NZ', 0, 0), 
('country', 'OM', 0, 0), 
('country', 'PA', 0, 0), 
('country', 'PE', 0, 0), 
('country', 'PF', 0, 0), 
('country', 'PG', 0, 0), 
('country', 'PH', 0, 0), 
('country', 'PK', 0, 0), 
('country', 'PL', 0, 0), 
('country', 'PR', 0, 0), 
('country', 'PS', 0, 0), 
('country', 'PT', 0, 0), 
('country', 'PW', 0, 0), 
('country', 'PY', 0, 0), 
('country', 'QA', 0, 0), 
('country', 'RE', 0, 0), 
('country', 'RO', 0, 0), 
('country', 'RU', 0, 0), 
('country', 'RW', 0, 0), 
('country', 'SA', 0, 0), 
('country', 'SB', 0, 0), 
('country', 'SC', 0, 0), 
('country', 'SD', 0, 0), 
('country', 'SE', 0, 0), 
('country', 'SG', 0, 0), 
('country', 'SI', 0, 0), 
('country', 'SK', 0, 0), 
('country', 'SL', 0, 0), 
('country', 'SM', 0, 0), 
('country', 'SN', 0, 0), 
('country', 'SO', 0, 0), 
('country', 'SR', 0, 0), 
('country', 'ST', 0, 0), 
('country', 'SV', 0, 0), 
('country', 'SY', 0, 0), 
('country', 'SZ', 0, 0), 
('country', 'TD', 0, 0), 
('country', 'TF', 0, 0), 
('country', 'TG', 0, 0), 
('country', 'TH', 0, 0), 
('country', 'TJ', 0, 0), 
('country', 'TK', 0, 0), 
('country', 'TL', 0, 0), 
('country', 'TM', 0, 0), 
('country', 'TN', 0, 0), 
('country', 'TO', 0, 0), 
('country', 'TR', 0, 0), 
('country', 'TT', 0, 0), 
('country', 'TV', 0, 0), 
('country', 'TW', 0, 0), 
('country', 'TZ', 0, 0), 
('country', 'UA', 0, 0), 
('country', 'UG', 0, 0), 
('country', 'US', 29, 1418481342), 
('country', 'UY', 0, 0), 
('country', 'UZ', 0, 0), 
('country', 'VA', 0, 0), 
('country', 'VC', 0, 0), 
('country', 'VE', 0, 0), 
('country', 'VG', 0, 0), 
('country', 'VI', 0, 0), 
('country', 'VN', 53, 1418968641), 
('country', 'VU', 0, 0), 
('country', 'WS', 0, 0), 
('country', 'YE', 0, 0), 
('country', 'YT', 0, 0), 
('country', 'YU', 0, 0), 
('country', 'ZA', 0, 0), 
('country', 'ZM', 0, 0), 
('country', 'ZW', 0, 0), 
('country', 'ZZ', 14, 1419064498), 
('country', 'unkown', 0, 0);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_menu_menu`
--

DROP TABLE IF EXISTS `vt_vi_menu_menu`;
CREATE TABLE `vt_vi_menu_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `menu_item` mediumtext NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_menu_menu`
--

INSERT INTO `vt_vi_menu_menu` VALUES
(1, 'Menu ngang', '1,2,3,4,5,6,7,8,10,11,12,15,16,19,20,23,46,45,29,30,32,33,34,35,36,37,38,39,40,41,42,43,44', ''), 
(2, 'Menu footer', '48', '');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_menu_rows`
--

DROP TABLE IF EXISTS `vt_vi_menu_rows`;
CREATE TABLE `vt_vi_menu_rows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` int(11) unsigned NOT NULL,
  `mid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  `weight` int(11) NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` mediumtext NOT NULL,
  `who_view` tinyint(2) NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL,
  `module_name` varchar(255) NOT NULL DEFAULT '',
  `op` varchar(255) NOT NULL DEFAULT '',
  `target` tinyint(4) NOT NULL DEFAULT '0',
  `css` varchar(255) NOT NULL DEFAULT '',
  `active_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=49  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_menu_rows`
--

INSERT INTO `vt_vi_menu_rows` VALUES
(1, 0, 1, 'Trang chủ', '&#x002F;demo&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;home', '', 1, 1, 0, '', 0, '', 'home', '', 1, '', 0, 1), 
(2, 0, 1, 'Tour trong nước', '&#x002F;demo&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;TRONG-NUOC', '', 2, 2, 0, '4,5,6', 0, '', 'shops', '', 1, '', 0, 1), 
(3, 0, 1, 'Tour nước ngoài', '&#x002F;demo&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;NUOC-NGOAI', '', 3, 19, 0, '33,34,35', 0, '', 'shops', '', 1, '', 0, 1), 
(4, 2, 1, 'TỪ TP HỒ CHÍ MINH', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;TU-TP-HO-CHI-MINH', '', 1, 3, 1, '7,8,10,11,12', 0, '', 'shops', '', 1, '', 0, 1), 
(5, 2, 1, 'TỪ HÀ NỘI', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;TU-HA-NOI', '', 2, 9, 1, '15,16,19,20', 0, '', 'shops', '', 1, '', 0, 1), 
(6, 2, 1, 'TỪ ĐÀ NẴNG', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;TU-DA-NANG', '', 3, 14, 1, '23,29,30,32', 0, '', 'shops', '', 1, '', 0, 1), 
(7, 4, 1, 'Tour miền Bắc', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;Tour-mien-Bac', '', 1, 4, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(8, 4, 1, 'Tour miền Trung', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;Tour-mien-Trung', '', 2, 5, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(10, 4, 1, 'Tour miền Tây Nam Bộ', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;Tour-mien-Tay-Nam-Bo', '', 3, 6, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(11, 4, 1, 'Tour Nha Trang', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;Tour-Nha-Trang', '', 4, 7, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(12, 4, 1, 'Tour Đà Lạt', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;Tour-Da-Lat', '', 5, 8, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(15, 5, 1, 'Tour miền Bắc', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;TU-HA-NOI-Tour-mien-Bac', '', 1, 10, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(16, 5, 1, 'Tour miền Trung', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;TU-HA-NOI-Tour-mien-Trung', '', 2, 11, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(19, 5, 1, 'Tour Nha Trang', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;TU-HA-NOI-Tour-Nha-Trang', '', 3, 12, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(20, 5, 1, 'Tour Đà Lạt', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;TU-HA-NOI-Tour-Da-Lat', '', 4, 13, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(23, 6, 1, 'Tour miền Bắc', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;TU-DA-NANG-Tour-mien-Bac', '', 1, 15, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(46, 0, 1, 'Xe du lịch', '&#x002F;demo&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;rental', '', 4, 32, 0, '', 0, '', 'rental', '', 1, '', 0, 1), 
(48, 0, 2, 'Trang chủ', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;home', '', 1, 1, 0, '', 0, '', 'home', '', 1, '', 0, 1), 
(45, 0, 1, 'Liên hệ', '&#x002F;demo&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;contact', '', 5, 33, 0, '', 0, '', 'contact', '', 1, '', 0, 1), 
(29, 6, 1, 'Tour Tây Nguyên', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;TU-DA-NANG-Tour-Tay-Nguyen', '', 2, 16, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(30, 6, 1, 'Tour miền Tây Nam Bộ', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;TU-DA-NANG-Tour-mien-Tay-Nam-Bo', '', 3, 17, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(32, 6, 1, 'Tour Đà Lạt', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;TU-DA-NANG-Tour-Da-Lat', '', 4, 18, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(33, 3, 1, 'TỪ TP HỒ CHÍ MINH', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;NUOC-NGOAI-TU-TP-HO-CHI-MINH', '', 1, 20, 1, '36,37,38', 0, '', 'shops', '', 1, '', 0, 1), 
(34, 3, 1, 'TỪ HÀ NỘI', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;NUOC-NGOAI-TU-HA-NOI', '', 2, 24, 1, '39,40,41', 0, '', 'shops', '', 1, '', 0, 1), 
(35, 3, 1, 'TỪ ĐÀ NẴNG', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;NUOC-NGOAI-TU-DA-NANG', '', 3, 28, 1, '42,43,44', 0, '', 'shops', '', 1, '', 0, 1), 
(36, 33, 1, 'Tour Singapore', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;Tour-Sing', '', 1, 21, 2, '', 0, '', 'shops', 'Tour-Sing', 1, '', 0, 1), 
(37, 33, 1, 'Tour Thái Lan', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;Tour-Thai-Lan', '', 2, 22, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(38, 33, 1, 'Tour Malaysia', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;Tour-Malaysia', '', 3, 23, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(39, 34, 1, 'Tour Hàn Quốc', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;NUOC-NGOAI-TU-HA-NOI-Tour-HQ', '', 1, 25, 2, '', 0, '', 'shops', 'NUOC-NGOAI-TU-HA-NOI-Tour-HQ', 1, '', 0, 1), 
(40, 34, 1, 'Tour Thái Lan', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;NUOC-NGOAI-TU-HA-NOI-Tour-Thai-Lan', '', 2, 26, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(41, 34, 1, 'Tour Malaysia', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;NUOC-NGOAI-TU-HA-NOI-Tour-Malaysia', '', 3, 27, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(42, 35, 1, 'Tour Nhật Bản', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;NUOC-NGOAI-TU-DA-NANG-Tour-Japan', '', 1, 29, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(43, 35, 1, 'Tour Thái Lan', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;NUOC-NGOAI-TU-DA-NANG-Tour-Thai-Lan', '', 2, 30, 2, '', 0, '', 'shops', '', 1, '', 0, 1), 
(44, 35, 1, 'Tour Malaysia', '&#x002F;dulich&#x002F;index.php?language&#x3D;vi&amp;nv&#x3D;shops&amp;op&#x3D;NUOC-NGOAI-TU-DA-NANG-Tour-Malaysia', '', 3, 31, 2, '', 0, '', 'shops', '', 1, '', 0, 1);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_modfuncs`
--

DROP TABLE IF EXISTS `vt_vi_modfuncs`;
CREATE TABLE `vt_vi_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55) NOT NULL,
  `func_custom_name` varchar(255) NOT NULL,
  `in_module` varchar(55) NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=205  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_modfuncs`
--

INSERT INTO `vt_vi_modfuncs` VALUES
(1, 'Sitemap', 'Sitemap', 'about', 0, 0, 0, ''), 
(2, 'main', 'Main', 'about', 1, 0, 1, ''), 
(3, 'Sitemap', 'Sitemap', 'news', 0, 0, 0, ''), 
(4, 'comment', 'Comment', 'news', 0, 0, 0, ''), 
(5, 'content', 'Content', 'news', 1, 0, 1, ''), 
(6, 'detail', 'Detail', 'news', 1, 0, 2, ''), 
(7, 'main', 'Main', 'news', 1, 0, 3, ''), 
(8, 'postcomment', 'Postcomment', 'news', 0, 0, 0, ''), 
(9, 'print', 'Print', 'news', 0, 0, 0, ''), 
(10, 'rating', 'Rating', 'news', 0, 0, 0, ''), 
(11, 'rss', 'Rss', 'news', 0, 0, 0, ''), 
(12, 'savefile', 'Savefile', 'news', 0, 0, 0, ''), 
(13, 'search', 'Search', 'news', 1, 0, 4, ''), 
(14, 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''), 
(15, 'topic', 'Topic', 'news', 1, 0, 5, ''), 
(16, 'viewcat', 'Viewcat', 'news', 1, 0, 6, ''), 
(17, 'active', 'Active', 'users', 1, 0, 8, ''), 
(18, 'changepass', 'Đổi mật khẩu', 'users', 1, 1, 6, ''), 
(19, 'editinfo', 'Editinfo', 'users', 1, 0, 10, ''), 
(20, 'login', 'Đăng nhập', 'users', 1, 1, 2, ''), 
(21, 'logout', 'Logout', 'users', 1, 1, 3, ''), 
(22, 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 9, ''), 
(23, 'lostpass', 'Quên mật khẩu', 'users', 1, 1, 5, ''), 
(24, 'main', 'Main', 'users', 1, 1, 1, ''), 
(25, 'openid', 'Openid', 'users', 1, 1, 7, ''), 
(26, 'register', 'Đăng ký', 'users', 1, 1, 4, ''), 
(27, 'main', 'Main', 'contact', 1, 0, 1, ''), 
(28, 'allbots', 'Máy chủ tìm kiếm', 'statistics', 1, 1, 6, ''), 
(29, 'allbrowsers', 'Theo trình duyệt', 'statistics', 1, 1, 4, ''), 
(30, 'allcountries', 'Theo quốc gia', 'statistics', 1, 1, 3, ''), 
(31, 'allos', 'Theo hệ điều hành', 'statistics', 1, 1, 5, ''), 
(32, 'allreferers', 'Theo đường dẫn đến site', 'statistics', 1, 1, 2, ''), 
(33, 'main', 'Main', 'statistics', 1, 0, 1, ''), 
(34, 'referer', 'Đường dẫn đến site theo tháng', 'statistics', 1, 0, 7, ''), 
(35, 'main', 'Main', 'voting', 1, 0, 0, ''), 
(36, 'addads', 'Addads', 'banners', 1, 0, 1, ''), 
(37, 'cledit', 'Cledit', 'banners', 0, 0, 0, ''), 
(38, 'click', 'Click', 'banners', 0, 0, 0, ''), 
(39, 'clientinfo', 'Clientinfo', 'banners', 1, 0, 2, ''), 
(40, 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''), 
(41, 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''), 
(42, 'main', 'Main', 'banners', 1, 0, 3, ''), 
(43, 'stats', 'Stats', 'banners', 1, 0, 4, ''), 
(44, 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''), 
(45, 'adv', 'Adv', 'search', 0, 0, 0, ''), 
(46, 'main', 'Main', 'search', 1, 0, 1, ''), 
(47, 'main', 'Main', 'rss', 1, 0, 1, ''), 
(48, 'regroups', 'Nhóm thành viên', 'users', 1, 0, 1, ''), 
(50, 'memberlist', 'Danh sách thành viên', 'users', 1, 1, 1, ''), 
(51, 'groups', 'Groups', 'news', 1, 0, 7, ''), 
(197, 'rss', 'Rss', 'shops', 0, 0, 0, ''), 
(196, 'remove', 'Remove', 'shops', 0, 0, 0, ''), 
(195, 'rate', 'Rate', 'shops', 0, 0, 0, ''), 
(194, 'profile', 'Profile', 'shops', 1, 0, 13, ''), 
(193, 'print_pro', 'Print_pro', 'shops', 0, 0, 0, ''), 
(192, 'print', 'Print', 'shops', 0, 0, 0, ''), 
(191, 'postcomment', 'Postcomment', 'shops', 0, 0, 0, ''), 
(190, 'post', 'Post', 'shops', 1, 0, 14, ''), 
(189, 'payment', 'Payment', 'shops', 1, 0, 7, ''), 
(188, 'order', 'Order', 'shops', 1, 0, 6, ''), 
(187, 'myproduct', 'Myproduct', 'shops', 1, 0, 12, ''), 
(186, 'myinfo', 'Myinfo', 'shops', 0, 0, 0, ''), 
(185, 'main', 'Main', 'shops', 1, 0, 1, ''), 
(184, 'loadcart', 'Loadcart', 'shops', 0, 0, 0, ''), 
(183, 'history', 'History', 'shops', 1, 0, 9, ''), 
(182, 'group', 'Group', 'shops', 1, 0, 10, ''), 
(181, 'detail', 'Detail', 'shops', 1, 0, 3, ''), 
(180, 'delpro', 'Delpro', 'shops', 0, 0, 0, ''), 
(179, 'delhis', 'Delhis', 'shops', 0, 0, 0, ''), 
(178, 'complete', 'Complete', 'shops', 1, 0, 8, ''), 
(177, 'comment', 'Comment', 'shops', 0, 0, 0, ''), 
(176, 'checkorder', 'Checkorder', 'shops', 0, 0, 0, ''), 
(175, 'cart', 'Cart', 'shops', 1, 0, 5, ''), 
(174, 'addcomment', 'Addcomment', 'shops', 0, 0, 0, ''), 
(173, 'Sitemap', 'Sitemap', 'shops', 0, 0, 0, ''), 
(198, 'search', 'Search', 'shops', 1, 0, 4, ''), 
(199, 'search_result', 'Search_result', 'shops', 1, 0, 11, ''), 
(200, 'sendmail', 'Sendmail', 'shops', 0, 0, 0, ''), 
(201, 'service', 'Service', 'shops', 0, 0, 0, ''), 
(202, 'setcart', 'Setcart', 'shops', 0, 0, 0, ''), 
(203, 'viewcat', 'Viewcat', 'shops', 1, 0, 2, ''), 
(204, 'main', 'Main', 'home', 1, 0, 1, '');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_modthemes`
--

DROP TABLE IF EXISTS `vt_vi_modthemes`;
CREATE TABLE `vt_vi_modthemes` (
  `func_id` int(11) DEFAULT NULL,
  `layout` varchar(100) DEFAULT NULL,
  `theme` varchar(100) DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_modthemes`
--

INSERT INTO `vt_vi_modthemes` VALUES
(0, 'body', 'mobile_nukeviet'), 
(0, 'body-right', 'modern'), 
(0, 'left-body', 'default'), 
(2, 'body', 'mobile_nukeviet'), 
(2, 'body', 'modern'), 
(2, 'left-body', 'default'), 
(5, 'body', 'mobile_nukeviet'), 
(5, 'body-right', 'modern'), 
(5, 'left-body', 'default'), 
(6, 'body', 'mobile_nukeviet'), 
(6, 'body-right', 'modern'), 
(6, 'left-body', 'default'), 
(7, 'body', 'mobile_nukeviet'), 
(7, 'body-right', 'modern'), 
(7, 'left-body', 'default'), 
(13, 'body', 'mobile_nukeviet'), 
(13, 'body-right', 'modern'), 
(13, 'left-body', 'default'), 
(15, 'body', 'mobile_nukeviet'), 
(15, 'body-right', 'modern'), 
(15, 'left-body', 'default'), 
(16, 'body', 'mobile_nukeviet'), 
(16, 'body-right', 'modern'), 
(16, 'left-body', 'default'), 
(17, 'body', 'mobile_nukeviet'), 
(17, 'body-right', 'modern'), 
(17, 'left-body', 'default'), 
(18, 'body', 'mobile_nukeviet'), 
(18, 'body-right', 'modern'), 
(18, 'left-body', 'default'), 
(19, 'body', 'mobile_nukeviet'), 
(19, 'body-right', 'modern'), 
(19, 'left-body', 'default'), 
(20, 'body', 'mobile_nukeviet'), 
(20, 'body-right', 'modern'), 
(20, 'left-body', 'default'), 
(21, 'body', 'mobile_nukeviet'), 
(21, 'body-right', 'modern'), 
(21, 'left-body', 'default'), 
(22, 'body', 'mobile_nukeviet'), 
(22, 'body-right', 'modern'), 
(22, 'left-body', 'default'), 
(23, 'body', 'mobile_nukeviet'), 
(23, 'body-right', 'modern'), 
(23, 'left-body', 'default'), 
(24, 'body', 'mobile_nukeviet'), 
(24, 'body-right', 'modern'), 
(24, 'left-body', 'default'), 
(25, 'body', 'mobile_nukeviet'), 
(25, 'body-right', 'modern'), 
(25, 'left-body', 'default'), 
(26, 'body', 'mobile_nukeviet'), 
(26, 'body-right', 'modern'), 
(26, 'left-body', 'default'), 
(27, 'body', 'mobile_nukeviet'), 
(27, 'body-right', 'modern'), 
(27, 'left-body', 'default'), 
(28, 'body', 'mobile_nukeviet'), 
(28, 'body', 'modern'), 
(28, 'left-body', 'default'), 
(29, 'body', 'mobile_nukeviet'), 
(29, 'body', 'modern'), 
(29, 'left-body', 'default'), 
(30, 'body', 'mobile_nukeviet'), 
(30, 'body', 'modern'), 
(30, 'left-body', 'default'), 
(31, 'body', 'mobile_nukeviet'), 
(31, 'body', 'modern'), 
(31, 'left-body', 'default'), 
(32, 'body', 'mobile_nukeviet'), 
(32, 'body', 'modern'), 
(32, 'left-body', 'default'), 
(33, 'body', 'mobile_nukeviet'), 
(33, 'body', 'modern'), 
(33, 'left-body', 'default'), 
(34, 'body', 'mobile_nukeviet'), 
(34, 'body', 'modern'), 
(34, 'left-body', 'default'), 
(35, 'body', 'mobile_nukeviet'), 
(35, 'body-right', 'modern'), 
(35, 'left-body', 'default'), 
(36, 'body', 'mobile_nukeviet'), 
(36, 'body-right', 'modern'), 
(36, 'left-body', 'default'), 
(39, 'body', 'mobile_nukeviet'), 
(39, 'body-right', 'modern'), 
(39, 'left-body', 'default'), 
(42, 'body', 'mobile_nukeviet'), 
(42, 'body-right', 'modern'), 
(42, 'left-body', 'default'), 
(43, 'body', 'mobile_nukeviet'), 
(43, 'body-right', 'modern'), 
(43, 'left-body', 'default'), 
(46, 'body', 'mobile_nukeviet'), 
(46, 'body-right', 'modern'), 
(46, 'left-body', 'default'), 
(47, 'body', 'mobile_nukeviet'), 
(47, 'body', 'modern'), 
(47, 'left-body', 'default'), 
(48, 'body', 'mobile_nukeviet'), 
(48, 'body-right', 'modern'), 
(48, 'left-body', 'default'), 
(50, 'body', 'mobile_nukeviet'), 
(50, 'body-right', 'modern'), 
(50, 'left-body', 'default'), 
(51, 'body', 'mobile_nukeviet'), 
(51, 'body-right', 'modern'), 
(51, 'left-body', 'default'), 
(175, 'left-body', 'default'), 
(178, 'left-body', 'default'), 
(181, 'left-body', 'default'), 
(182, 'left-body', 'default'), 
(183, 'left-body', 'default'), 
(185, 'left-body', 'default'), 
(187, 'left-body', 'default'), 
(188, 'left-body', 'default'), 
(189, 'left-body', 'default'), 
(190, 'left-body', 'default'), 
(194, 'left-body', 'default'), 
(198, 'left-body', 'default'), 
(199, 'left-body', 'default'), 
(203, 'left-body', 'default'), 
(204, 'left-body', 'default');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_modules`
--

DROP TABLE IF EXISTS `vt_vi_modules`;
CREATE TABLE `vt_vi_modules` (
  `title` varchar(55) NOT NULL,
  `module_file` varchar(55) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `custom_title` varchar(255) NOT NULL,
  `admin_title` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` mediumtext NOT NULL,
  `groups_view` varchar(255) NOT NULL,
  `in_menu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255) NOT NULL,
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_modules`
--

INSERT INTO `vt_vi_modules` VALUES
('about', 'about', 'about', 'Giới thiệu', '', 1276333182, 1, 1, '', 'mobile_nukeviet', '', '', '0', 1, 1, 1, 1, '', 0), 
('news', 'news', 'news', 'Tin tức-Sự kiện', '', 1270400000, 1, 1, '', '', '', '', '0', 1, 4, 1, 1, '', 1), 
('users', 'users', 'users', 'Thành viên', 'QL Thành viên', 1274080277, 1, 1, '', '', '', '', '0', 1, 6, 1, 1, '', 0), 
('contact', 'contact', 'contact', 'Liên hệ', '', 1275351337, 1, 1, '', 'mobile_nukeviet', '', '', '0', 1, 8, 1, 1, '', 0), 
('statistics', 'statistics', 'statistics', 'Thống kê', '', 1276520928, 1, 0, '', 'mobile_nukeviet', '', 'truy cập, online, statistics', '0', 1, 9, 1, 1, '', 0), 
('voting', 'voting', 'voting', 'Thăm dò ý kiến', '', 1275315261, 1, 1, '', 'mobile_nukeviet', '', '', '0', 0, 10, 1, 1, '', 1), 
('banners', 'banners', 'banners', 'Quảng cáo', '', 1270400000, 1, 1, '', 'mobile_nukeviet', '', '', '0', 0, 5, 1, 1, '', 0), 
('search', 'search', 'search', 'Tìm kiếm', '', 1273474173, 1, 0, '', 'mobile_nukeviet', '', '', '0', 0, 11, 1, 1, '', 0), 
('menu', 'menu', 'menu', 'Menu Site', '', 1295287334, 0, 1, '', 'mobile_nukeviet', '', '', '0', 0, 12, 1, 1, '', 0), 
('rss', 'rss', 'rss', 'Rss', '', 1279366705, 1, 1, '', 'mobile_nukeviet', '', '', '0', 0, 13, 10, 1, '', 0), 
('silide', 'silide', 'silide', 'Slider', 'Slider', 1353343349, 0, 1, '', '', '', '', '0', 0, 7, 0, 0, '', 0), 
('shops', 'shops', 'shops', 'Tours', 'Quản lý Tours', 1353508387, 1, 1, '', '', '', '', '0', 1, 3, 1, 1, '', 1), 
('home', 'home', 'home', 'Trang chủ', 'Trang chủ', 1418097685, 1, 0, '', '', '', '', '0', 1, 2, 1, 1, '', 0);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_1`
--

DROP TABLE IF EXISTS `vt_vi_news_1`;
CREATE TABLE `vt_vi_news_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_1`
--

INSERT INTO `vt_vi_news_1` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 'thumb/nangly.jpg|block/nangly.jpg', 1, 2, 1, 5, 0, 0, 0, 'nguồn mở, quen thuộc, cộng đồng, việt nam, hoạt động, gần đây, phổ biến, áp dụng, hầu hết, hết các, lĩnh vực, tin tức, thương mại điện, điện tử, cá nhân, hệ thống'), 
(2, 1, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', 'nukeviet3.jpg', 'NukeViet 3.0', 'thumb/nukeviet3.jpg|block/nukeviet3.jpg', 1, 2, 1, 5, 0, 0, 0, 'nền tảng, xây dựng, hoàn toàn, với những, công nghệ, tiên tiến, hiện nay, hứa hẹn, cách mạng, nguồn mở, việt nam, món quà, cảm ơn, chân thành, thành nhất, cộng đồng'), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 'thumb/hoptac.jpg|block/hoptac.jpg', 1, 2, 1, 6, 0, 0, 0, 'hiện tại, tiến hành, phát triển, phiên bản, thế hệ, hoàn toàn, tính năng, ưu việt, kinh phí, thiện chí, hợp tác, trân trọng, mời hợp tác, đối tác, các công ty, công ty, cung cấp, tên miền, các doanh, doanh nghiệp, quan tâm'), 
(10, 8, '1,8', 0, 1, '', 4, 1322685920, 1418222681, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'thumb/nukeviet-nhantaidatviet2011.jpg|block/nukeviet-nhantaidatviet2011.jpg', 1, 2, 1, 7, 0, 0, 0, 'Nhân tài đất Việt 2011, mã nguồn mở'), 
(9, 8, '1,8', 0, 1, 'Phạm Thế Quang Huy', 4, 1322685396, 1418137360, 1, 1322685396, 0, 2, 'NukeViet - Công cụ mã nguồn mở cho cộng đồng thiết kế website Việt Nam', 'NukeViet-Cong-cu-ma-nguon-mo-cho-cong-dong-thiet-ke-website-Viet-Nam', '(Dân trí) - Là một trong những hệ quản trị nội dung nổi tiếng hàng đầu tại Việt Nam, NukeViet đã được áp dụng rộng rãi trong việc xây dựng nhiều trang báo điện tử và các cổng thông tin điện tử nổi tiếng tại Việt Nam. Mới đây nhất, NukeViet đã vượt qua vòng sơ khảo để tranh tài tại vòng chung khảo của Giải Thưởng Nhân Tài Đất Việt 2011', 'product_box.jpg', 'Sản phẩm dự thi Nhân tài Đất Việt 2011&#x3A; Mã nguồn mở NukeViet', 'thumb/product_box.jpg|block/product_box.jpg', 1, 2, 1, 3, 0, 0, 0, 'Nhân tài Đất Việt 2011, mã nguồn mở');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_10`
--

DROP TABLE IF EXISTS `vt_vi_news_10`;
CREATE TABLE `vt_vi_news_10` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_10`
--

INSERT INTO `vt_vi_news_10` VALUES
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 'thumb/hoptac.jpg|block/hoptac.jpg', 1, 2, 1, 6, 0, 0, 0, 'hiện tại, tiến hành, phát triển, phiên bản, thế hệ, hoàn toàn, tính năng, ưu việt, kinh phí, thiện chí, hợp tác, trân trọng, mời hợp tác, đối tác, các công ty, công ty, cung cấp, tên miền, các doanh, doanh nghiệp, quan tâm'), 
(8, 10, '9,10,13,14,15', 0, 1, 'laser', 3, 1310067949, 1353230671, 1, 1310067949, 0, 2, 'Webnhanh.vn - website dịch vụ chuyên nghiệp cho NukeViet chính thức ra mắt', 'Webnhanhvn-website-dich-vu-chuyen-nghiep-cho-NukeViet-chinh-thuc-ra-mat', 'Sau một thời gian đi vào hoạt động, Webnhanh.vn đã nhận được nhiều ủng hộ cùng sự quan tâm, góp ý của cộng đồng và khách hàng. Để đáp ứng mong mỏi của cộng đồng về một dịch vụ web chuyên nghiệp với mức giá tối thiểu, Webnhanh.vn đã thực hiện chiến dịch siêu khuyến mại Giảm giá tất cả các gói web dựng sẵn, module, block và giao diện (theme). Mức giảm giá cao nhất tới 90% giá so với trước tháng 7 năm 2011.', 'webnhanh-vn.jpg', '', 'thumb/webnhanh-vn.jpg|block/webnhanh-vn.jpg', 1, 2, 1, 2, 0, 0, 0, 'khai trương, khuyến mại, giảm giá, siêu khuyến mại, webnhanh, thiết kế website, giao diện web, thiết kế web');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_12`
--

DROP TABLE IF EXISTS `vt_vi_news_12`;
CREATE TABLE `vt_vi_news_12` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_12`
--

INSERT INTO `vt_vi_news_12` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 'thumb/nangly.jpg|block/nangly.jpg', 1, 2, 1, 5, 0, 0, 0, 'nguồn mở, quen thuộc, cộng đồng, việt nam, hoạt động, gần đây, phổ biến, áp dụng, hầu hết, hết các, lĩnh vực, tin tức, thương mại điện, điện tử, cá nhân, hệ thống'), 
(2, 1, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', 'nukeviet3.jpg', 'NukeViet 3.0', 'thumb/nukeviet3.jpg|block/nukeviet3.jpg', 1, 2, 1, 5, 0, 0, 0, 'nền tảng, xây dựng, hoàn toàn, với những, công nghệ, tiên tiến, hiện nay, hứa hẹn, cách mạng, nguồn mở, việt nam, món quà, cảm ơn, chân thành, thành nhất, cộng đồng');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_13`
--

DROP TABLE IF EXISTS `vt_vi_news_13`;
CREATE TABLE `vt_vi_news_13` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=9  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_13`
--

INSERT INTO `vt_vi_news_13` VALUES
(8, 10, '9,10,13,14,15', 0, 1, 'laser', 3, 1310067949, 1353230671, 1, 1310067949, 0, 2, 'Webnhanh.vn - website dịch vụ chuyên nghiệp cho NukeViet chính thức ra mắt', 'Webnhanhvn-website-dich-vu-chuyen-nghiep-cho-NukeViet-chinh-thuc-ra-mat', 'Sau một thời gian đi vào hoạt động, Webnhanh.vn đã nhận được nhiều ủng hộ cùng sự quan tâm, góp ý của cộng đồng và khách hàng. Để đáp ứng mong mỏi của cộng đồng về một dịch vụ web chuyên nghiệp với mức giá tối thiểu, Webnhanh.vn đã thực hiện chiến dịch siêu khuyến mại Giảm giá tất cả các gói web dựng sẵn, module, block và giao diện (theme). Mức giảm giá cao nhất tới 90% giá so với trước tháng 7 năm 2011.', 'webnhanh-vn.jpg', '', 'thumb/webnhanh-vn.jpg|block/webnhanh-vn.jpg', 1, 2, 1, 2, 0, 0, 0, 'khai trương, khuyến mại, giảm giá, siêu khuyến mại, webnhanh, thiết kế website, giao diện web, thiết kế web');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_14`
--

DROP TABLE IF EXISTS `vt_vi_news_14`;
CREATE TABLE `vt_vi_news_14` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=9  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_14`
--

INSERT INTO `vt_vi_news_14` VALUES
(8, 10, '9,10,13,14,15', 0, 1, 'laser', 3, 1310067949, 1353230671, 1, 1310067949, 0, 2, 'Webnhanh.vn - website dịch vụ chuyên nghiệp cho NukeViet chính thức ra mắt', 'Webnhanhvn-website-dich-vu-chuyen-nghiep-cho-NukeViet-chinh-thuc-ra-mat', 'Sau một thời gian đi vào hoạt động, Webnhanh.vn đã nhận được nhiều ủng hộ cùng sự quan tâm, góp ý của cộng đồng và khách hàng. Để đáp ứng mong mỏi của cộng đồng về một dịch vụ web chuyên nghiệp với mức giá tối thiểu, Webnhanh.vn đã thực hiện chiến dịch siêu khuyến mại Giảm giá tất cả các gói web dựng sẵn, module, block và giao diện (theme). Mức giảm giá cao nhất tới 90% giá so với trước tháng 7 năm 2011.', 'webnhanh-vn.jpg', '', 'thumb/webnhanh-vn.jpg|block/webnhanh-vn.jpg', 1, 2, 1, 2, 0, 0, 0, 'khai trương, khuyến mại, giảm giá, siêu khuyến mại, webnhanh, thiết kế website, giao diện web, thiết kế web');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_15`
--

DROP TABLE IF EXISTS `vt_vi_news_15`;
CREATE TABLE `vt_vi_news_15` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=9  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_15`
--

INSERT INTO `vt_vi_news_15` VALUES
(8, 10, '9,10,13,14,15', 0, 1, 'laser', 3, 1310067949, 1353230671, 1, 1310067949, 0, 2, 'Webnhanh.vn - website dịch vụ chuyên nghiệp cho NukeViet chính thức ra mắt', 'Webnhanhvn-website-dich-vu-chuyen-nghiep-cho-NukeViet-chinh-thuc-ra-mat', 'Sau một thời gian đi vào hoạt động, Webnhanh.vn đã nhận được nhiều ủng hộ cùng sự quan tâm, góp ý của cộng đồng và khách hàng. Để đáp ứng mong mỏi của cộng đồng về một dịch vụ web chuyên nghiệp với mức giá tối thiểu, Webnhanh.vn đã thực hiện chiến dịch siêu khuyến mại Giảm giá tất cả các gói web dựng sẵn, module, block và giao diện (theme). Mức giảm giá cao nhất tới 90% giá so với trước tháng 7 năm 2011.', 'webnhanh-vn.jpg', '', 'thumb/webnhanh-vn.jpg|block/webnhanh-vn.jpg', 1, 2, 1, 2, 0, 0, 0, 'khai trương, khuyến mại, giảm giá, siêu khuyến mại, webnhanh, thiết kế website, giao diện web, thiết kế web');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_8`
--

DROP TABLE IF EXISTS `vt_vi_news_8`;
CREATE TABLE `vt_vi_news_8` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_8`
--

INSERT INTO `vt_vi_news_8` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 'thumb/nangly.jpg|block/nangly.jpg', 1, 2, 1, 5, 0, 0, 0, 'nguồn mở, quen thuộc, cộng đồng, việt nam, hoạt động, gần đây, phổ biến, áp dụng, hầu hết, hết các, lĩnh vực, tin tức, thương mại điện, điện tử, cá nhân, hệ thống'), 
(2, 1, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', 'nukeviet3.jpg', 'NukeViet 3.0', 'thumb/nukeviet3.jpg|block/nukeviet3.jpg', 1, 2, 1, 5, 0, 0, 0, 'nền tảng, xây dựng, hoàn toàn, với những, công nghệ, tiên tiến, hiện nay, hứa hẹn, cách mạng, nguồn mở, việt nam, món quà, cảm ơn, chân thành, thành nhất, cộng đồng'), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 'thumb/hoptac.jpg|block/hoptac.jpg', 1, 2, 1, 6, 0, 0, 0, 'hiện tại, tiến hành, phát triển, phiên bản, thế hệ, hoàn toàn, tính năng, ưu việt, kinh phí, thiện chí, hợp tác, trân trọng, mời hợp tác, đối tác, các công ty, công ty, cung cấp, tên miền, các doanh, doanh nghiệp, quan tâm'), 
(10, 8, '1,8', 0, 1, '', 4, 1322685920, 1418222681, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'thumb/nukeviet-nhantaidatviet2011.jpg|block/nukeviet-nhantaidatviet2011.jpg', 1, 2, 1, 7, 0, 0, 0, 'Nhân tài đất Việt 2011, mã nguồn mở'), 
(9, 8, '1,8', 0, 1, 'Phạm Thế Quang Huy', 4, 1322685396, 1418137360, 1, 1322685396, 0, 2, 'NukeViet - Công cụ mã nguồn mở cho cộng đồng thiết kế website Việt Nam', 'NukeViet-Cong-cu-ma-nguon-mo-cho-cong-dong-thiet-ke-website-Viet-Nam', '(Dân trí) - Là một trong những hệ quản trị nội dung nổi tiếng hàng đầu tại Việt Nam, NukeViet đã được áp dụng rộng rãi trong việc xây dựng nhiều trang báo điện tử và các cổng thông tin điện tử nổi tiếng tại Việt Nam. Mới đây nhất, NukeViet đã vượt qua vòng sơ khảo để tranh tài tại vòng chung khảo của Giải Thưởng Nhân Tài Đất Việt 2011', 'product_box.jpg', 'Sản phẩm dự thi Nhân tài Đất Việt 2011&#x3A; Mã nguồn mở NukeViet', 'thumb/product_box.jpg|block/product_box.jpg', 1, 2, 1, 3, 0, 0, 0, 'Nhân tài Đất Việt 2011, mã nguồn mở');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_9`
--

DROP TABLE IF EXISTS `vt_vi_news_9`;
CREATE TABLE `vt_vi_news_9` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_9`
--

INSERT INTO `vt_vi_news_9` VALUES
(8, 10, '9,10,13,14,15', 0, 1, 'laser', 3, 1310067949, 1353230671, 1, 1310067949, 0, 2, 'Webnhanh.vn - website dịch vụ chuyên nghiệp cho NukeViet chính thức ra mắt', 'Webnhanhvn-website-dich-vu-chuyen-nghiep-cho-NukeViet-chinh-thuc-ra-mat', 'Sau một thời gian đi vào hoạt động, Webnhanh.vn đã nhận được nhiều ủng hộ cùng sự quan tâm, góp ý của cộng đồng và khách hàng. Để đáp ứng mong mỏi của cộng đồng về một dịch vụ web chuyên nghiệp với mức giá tối thiểu, Webnhanh.vn đã thực hiện chiến dịch siêu khuyến mại Giảm giá tất cả các gói web dựng sẵn, module, block và giao diện (theme). Mức giảm giá cao nhất tới 90% giá so với trước tháng 7 năm 2011.', 'webnhanh-vn.jpg', '', 'thumb/webnhanh-vn.jpg|block/webnhanh-vn.jpg', 1, 2, 1, 2, 0, 0, 0, 'khai trương, khuyến mại, giảm giá, siêu khuyến mại, webnhanh, thiết kế website, giao diện web, thiết kế web');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_admins`
--

DROP TABLE IF EXISTS `vt_vi_news_admins`;
CREATE TABLE `vt_vi_news_admins` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `comment` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_block`
--

DROP TABLE IF EXISTS `vt_vi_news_block`;
CREATE TABLE `vt_vi_news_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_block`
--

INSERT INTO `vt_vi_news_block` VALUES
(1, 9, 3), 
(1, 2, 6), 
(1, 1, 5), 
(2, 6, 3), 
(1, 10, 4), 
(2, 2, 2), 
(2, 1, 1), 
(1, 8, 2), 
(1, 6, 1);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_block_cat`
--

DROP TABLE IF EXISTS `vt_vi_news_block_cat`;
CREATE TABLE `vt_vi_news_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `number` mediumint(4) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_block_cat`
--

INSERT INTO `vt_vi_news_block_cat` VALUES
(1, 0, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', '', 'Tin tiêu điểm', 1, '', 1279945710, 1279956943), 
(2, 1, 4, 'Tin mới nhất', 'Tin-moi-nhat', '', '', 'Tin tiêu điểm', 2, '', 1279945725, 1279956445);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_bodyhtml_1`
--

DROP TABLE IF EXISTS `vt_vi_news_bodyhtml_1`;
CREATE TABLE `vt_vi_news_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_bodyhtml_1`
--

INSERT INTO `vt_vi_news_bodyhtml_1` VALUES
(1, '<p style=\"text-align: justify;\"> Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam.<br  /> <br  /> Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế.<br  /> <br  /> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet.<br  /> <br  /> NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn</p><blockquote> <p style=\"text-align: justify;\"> <em>Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (<a href=\"http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm\" target=\"_blank\">xem chi tiết</a>), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (<a href=\"http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov\" target=\"_blank\">xem chi tiết</a>); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.</em></p></blockquote>', 'http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm', 1, 0, 1, 1, 1), 
(2, '<p style=\"font-weight: bold;\"> <span style=\"font-size: 14pt;\">Câu chuyện của NukeViet và VINADES.,JSC</span></p><p style=\"font-weight: bold;\"> Từ một trăn trở</p><p style=\"text-align: justify;\"> Giữa năm 2009, trước yêu cầu cấp thiết phải đổi mới và làm một cuộc cách mạng cho mã nguồn mở NukeViet, một cuộc thảo luận sôi nổi đã diễn ra với tiêu đề &quot;Lối đi nào để chuyên nghiệp hóa mã nguồn mở NukeViet&quot;.</p><p> Kết quả của cuộc thảo luận này là 55 bài viết với hàng chục ý kiến đóng góp đã được đưa ra. Các giải pháp về tài chính, nhân lực, phương hướng hoạt động được đem ra thảo luận. rockbuilc, Nkd833 đề xuất phương án thành lập doanh nghiệp chuyên quản NukeViet như một giải pháp toàn diện để giải quyết vấn đề chuyên nghiệp hóa NukeViet. Các vấn đề được các thành viên tham gia thảo luận và mổ xẻ thẳng thắn, nhiều ý kiến phản biện trái chiều cũng được đưa ra trên tinh thần xây dựng. Sau 2 tháng thảo luận, Ban Quản Trị đã có dự định...</p><p> <span style=\"font-weight: bold;\">Gặp mặt</span></p><p> Tháng 11, Sau khi tham khảo các ý kiến của mọi người trên diễn đàn, Anh Tú đã trực tiếp về Việt Nam. Một cuộc offline được tổ chức chớp nhoáng với sự tham gia của các thành viên chủ chốt tại Hà Nội. Các cuộc tìm hiểu và tiếp xúc được triển khai gấp rút trong giai đoạn này.</p><p> <span style=\"font-weight: bold;\">Một mô hình - một lối đi</span></p><p style=\"text-align: justify;\"> Hướng đi chuyên nghiệp hóa việc phát triển NukeViet đã được anh Tú chọn lựa: &quot;Thành lập doanh nghiệp chuyên quản NukeViet&quot;. Doanh nghiệp chuyên quản NukeViet được thành lập từ chính nhu cầu của cộng đồng nhằm chuyên nghiệp hóa NukeViet, vì vậy mô hình công ty cổ phần được chọn lựa để đáp ứng yêu cầu đó. Chịu trách nhiệm triển khai, laser đã lên phương án đầu tư, mục tiêu, kế hoạch phát triển ngắn và dài hạn.</p><p> <br  /> <span style=\"font-weight: bold;\">Triển khai thực hiện</span></p><p style=\"text-align: justify;\"> Tháng 1 năm 2010, việc thành lập đã được xúc tiến. Ngày 25/02/2010, trên các bản tin tiếng Anh và tiếng Việt xuất hiện bản tin &quot;Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam&quot;. Đó là Công ty cổ phần Phát triển nguồn mở Việt Nam (VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY - VINADES.,JSC). Đây là một vài hình ảnh trong ngày khai trương:</p><div style=\"text-align: center;\"> <img alt=\"Anh Tú phát biểu khai trương VINADES.,JSC \" height=\"332\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhtu-phatbieu.jpg\" style=\"border: 0px solid;\" width=\"500\" /></div><div style=\"text-align: center;\"> Anh Tú phát biểu khai trương VINADES.,JSC <p> <br  /> <img alt=\"\" border=\"0\" src=\"http://nukeviet.vn/uploads/spaw2/images/hung-phatbieu.jpg\" style=\"width: 500px;\" width=\"500\" /></p> <p> Nguyễn Hùng giới thiệu đôi nét về công ty, mục tiêu và phương hướng hoạt động.</p> <p> <br  /> <img alt=\"\" border=\"0\" height=\"332\" src=\"http://nukeviet.vn/uploads/spaw2/images/nangly.jpg\" style=\"width: 500px; height: 332px;\" width=\"500\" /></p> <p> Cùng nâng ly chúc mừng khai trương.</p></div><p style=\"font-weight: bold;\"> ... và lời cảm ơn gửi tới cộng đồng</p><p style=\"text-align: justify;\"> VINADES.,JSC từ khi được thai nghén tới lúc chập chững những bước đi ban đầu đều có sự động viên, ủng hộ và đóng góp lớn nhỏ của cộng đồng NukeViet - Một cộng đồng gắn liền với những ký ức, những kỷ niệm buồn vui và mang trong mỗi thành viên một đam mê, một hoài bão lớn lao. &quot;Lửa thử vàng, gian nan thử sức&quot;, mỗi khó khăn trả qua khiến cộng đồng NukeViet lớn dần lên, gắn kết với nhau bằng một sợi dây vô hình không thể chia cắt: đó là niềm đam mê với mã nguồn mở, với công nghệ web. VINADES.,JSC được tạo ra từ cộng đồng và sẽ cố gắng hết sức để hoạt động vì lợi ích của cộng đồng.</p><p>  </p><div style=\"text-align: center;\"> <img alt=\"\" border=\"0\" height=\"375\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhvp2.jpg\" style=\"width: 500px; height: 375px;\" width=\"500\" /></div><p>  </p><p style=\"text-align: center;\"> Văn phòng làm việc của VINADES.,JSC ở Hà Nội.</p><div style=\"text-align: center;\"> <img alt=\"\" border=\"0\" height=\"375\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhvp3.jpg\" style=\"width: 500px; height: 375px;\" width=\"500\" /></div><p>  </p><p style=\"text-align: center;\"> Một góc văn phòng nhìn từ trong ra ngoài.</p><p style=\"font-weight: bold;\"> NukeViet 3.0 - Cuộc cách mạng của NukeViet</p><p style=\"text-align: justify;\"> Sau nhiều tháng triển khai, NukeViet 3.0 đã được định hình và dự định công bố bản beta trong thời gian gần. NukeViet 3.0 là phiên bản mang tính cách mạng của hệ thống NukeViet vì 100% các dòng code của NukeViet 3.0 đã được viết mới hoàn toàn chứ không sử dụng nền tảng cũ. Việc này đã ngốn rất nhiều thời gian và công sức của đội ngũ lập trình. Đó cũng là lý do vì sao bản 2.0 không được cải tiến nhiều trong thời gian qua.</p><div style=\"text-align: justify;\"> NukeViet 3.0 được xây dựng với mong muốn có một nền tảng ổn định để sau đó có thể đầu tư lâu dài, xây dựng một thư viện ứng dụng phong phú. VINADES.,JSC sẽ song hành cùng cộng đồng NukeViet trong việc hỗ trợ và phát triển NukeViet thành một mã nguồn mở hoạt động ở quy mô chuyên nghiệp. Đây là bước đi đầu tiên trong trong tiến trình chuyên nghiệp hóa này. Các ứng dụng bổ sung sẽ được xây dựng bài bản, chất lượng. Cộng đồng NukeViet sẽ không chỉ là cộng đồng người sử dụng mà sẽ được đầu tư về đào tạo để trở thành một cộng đồng lập trình mạnh. Thông tin chi tiết về dự án phát triển NukeViet 3.0 được cập nhật tại đây: <a href=\"http://nukeviet.vn/phpbb/viewforum.php?f=99\" target=\"_blank\">http://nukeviet.vn/phpbb/viewforum.php?f=99</a></div>', 'http://vinades.vn/vi/news/thong-cao-bao-chi/Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC-2/', 1, 0, 1, 1, 1), 
(6, '<div style=\"text-align: center;\"> <h2 style=\"color: rgb(255, 69, 0);\"> THƯ MỜI HỢP TÁC</h2> <h4> TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN</h4> <h2> MÃ NGUỒN MỞ NUKEVIET</h2> </div> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\">  </p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm; font-weight: bold;\"> Phương thức hợp tác nhưsau:</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 1.Quảng cáo, trao đổi banner, liên kết website:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên website &amp; hệ thống kênh truyền thông của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng bá rộng rãi cho đối tượng của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm chi phí quảng bá cho 2 bên.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 2.Hợp tác cung cấp hosting thử nghiệm NukeViet:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên ký hợp đồng nguyên tắc &amp; thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b. Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở rộng thị trường theo cả hướng đối tượng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%;\"> c. Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 3,Hợp tác nhân lực hỗ trợ người sử dụng:</p> <p style=\"text-align: justify; line-height: 130%;\"> a, Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tăng hiệu quả hỗ trợ khách hàng.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệu quả của sự hợp tác song phưong này.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 4. Các hình thức khác:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị.</p> <span style=\"font-weight: bold;\">Thông tin liên hệ:</span> <p style=\"text-align: justify;\"> CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC)</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Trụ sở chính: Phòng 1805 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Điện thoại: (84-4) 85 872007</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Fax: (84-4) 35 500 914</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Website: <a href=\"http://www.vinades.vn/\">www.vinades.vn</a> – <a href=\"http://www.nukeviet.vn/\">www.nukeviet.vn</a></p> <p style=\"text-align: justify; text-indent: 1cm;\"> Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></p>', 'http://vinades.vn/vi/news/thong-cao-bao-chi/Thu-moi-hop-tac-6/', 1, 0, 1, 1, 1), 
(8, '<p style=\"text-align: justify;\"> <span style=\"font-size:16px;\"><strong>Giảm giá tới 90% giá module, ngày nào cũng là ngày &quot;mua chung&quot; trên webnhanh.vn!</strong></span></p><p style=\"text-align: justify;\"> Như thông báo trên webnhanh.vn, chương trình &quot;<a href=\"http://webnhanh.vn/vi/thiet-ke-web/detail/Mua-chung-tren-Webnhanhvn-se-giam-gia-90-gia-module-da-cong-bo-245/\" target=\"_blank\"><strong>mua chung module</strong></a>&quot; nằm trong chính sách chung của webnhanh.vn trong việc hỗ trợ phát triển mã nguồn mở, giúp cho mọi người được hưởng những dịch vụ thiết kế website tốt nhất với chi phí thấp nhất. Tham gia chương trình này, bạn chỉ phải trả số tiền bằng 1/10 giá trị module mà vẫn được sở hữu module với tính năng hấp dẫn mà bạn&nbsp; mong muốn.<br  /> <br  /> Cụ thể, các module trong <a href=\"http://webnhanh.vn/vi/nvresources/cat/Modules-1/\" target=\"_blank\"><strong>kho module của webnhanh.vn</strong></a> đang chờ hoàn thiện sẽ được giảm giá tới 90% nếu khách hàng đăng ký mua chung module. Tuy nhiên sau 2 tháng thực hiện, Ban Quản Trị webnhanh.vn thấy rằng khả năng xuất hiện nhu cầu cùng mua chung 1 sản phẩm và dịch vụ có tính đặc thù như code dành cho web là rất thấp. Chính vì thế webnhanh.vn đã giảm giá đồng loạt các module trên webnhanh.vn để khách hàng có nhu cầu sẽ có nhiều cơ hội được sử dụng các module mà mình mong muốn cung cấp lên website.<br  /> <br  /> Đại đa số các module sẽ được giảm giá xuống mức giá siêu rẻ để đảm bảo mọi người đều có khả năng sử dụng. Đặc biệt với các module có mức giá từ 10-20 triệu đồng sẽ giảm giá xuống còn ở mức 1-5 triệu đồng.<br  /> <br  /> <span style=\"font-size:16px;\"><strong>Giá rẻ hơn, nhiều giao diện hơn cho web</strong></span></p><p style=\"text-align: justify;\"> Ngoài việc giảm giá <a href=\"http://webnhanh.vn/vi/nvresources/cat/Giao-dien-3/\" target=\"_blank\"><strong>các giao diện website</strong></a> do VINADES.,JSC thiết kế (từ mức giá 2 triệu đồng xuống còn 300 đến 700 ngàn đồng). Webnhanh.vn cũng sẽ cải thiện kho giao diện của mình bằng cách đưa vào sử dụng các mẫu giao diện của các nhà thiết kế giao diện khác với giá trung bình khoảng 300 ngàn đồng (chi phí chuyển template thành giao diện có thể cài đặt cho website). Khách hàng cũng có thể gửi mẫu giao diện (đã cắt HTML) để chúng tôi thực hiện việc ghép giao diện với mức giá 300-500 ngàn đồng (áp dụng mô hình giá chia sẻ của VINADES.,JSC&nbsp; trong <strong><a href=\"http://vinades.vn/vi/news/San-pham/Thiet-ke-giao-dien-14/\" target=\"_blank\">thiết kế giao diện web</a></strong> <sup>(*)</sup>).<br  /> <br  /> <span style=\"font-size:16px;\"><strong>Giảm giá các gói web dựng sẵn, nâng cao chất lượng và cấu hình dịch vụ</strong></span></p><p style=\"text-align: justify;\"> Cơ cấu chất lượng sản phẩm và dịch vụ cũng thay đổi theo hướng nâng cao rõ rệt. Ngoài việc giảm giá các <strong><a href=\"http://webnhanh.vn/vi/nvresources/package/\" target=\"_blank\">gói web dựng sẵn</a></strong>, webnhanh.vn đồng thời nâng cao chất lượng các dịch vụ đi kèm của các gói web này. Theo đó ngoài việc kéo dài thời gian bảo hành miễn phí lên 12 tháng, đồng thời webnhanh.vn cũng kéo dài thời gian sử dụng hosting miễn phí lên 12 tháng. Với mức hỗ trợ này, website thiết kế trên webnhanh.vn đảm bảo chất lượng cao và mức giá còn rẻ hơn cả các nhà cung cấp dịch vụ web giá rẻ. Đây là cơ hội rất lớn cho <strong><a href=\"http://webnhanh.vn/vi/dealers/\" target=\"_blank\">các đại lý của webnhanh.vn</a></strong> để tạo nên lợi thế cạnh tranh về chất lượng và giá cả dịch vụ.<br  /> <br  /> <strong><sup>(*)</sup> &quot;Giá chia sẻ&quot;</strong> là mức giá tiết kiệm cho khách hàng, nếu mua với mức giá này khách hàng sẽ tiết kiệm chi phí thiết kế giao diện một cách tối đa mà vẫn được toàn quyền sử dụng mẫu giao diện đã đặt hàng. Webnhanh.vn sẽ giữ lại mẫu giao diện này và đưa vào thư viện giao diện để cung cấp cho các khách hàng khác. Mô hình &quot;Giá chia sẻ&quot; sử dụng cho các khách hàng không quá khắt khe về việc đảm bảo tính duy nhất của mẫu giao diện đồng thời giúp webnhanh.vn làm phong phú thêm kho giao diện của mình.</p><strong>Chú ý:</strong> Ngoài việc cung cấp các gói web dựng sẵn với chi phí thấp phục vụ người dùng phổ thông, <strong><a href=\"http://vinades.vn\">VINADES.,JSC</a></strong> vẫn duy trì dịch vụ thiết kế giao diện riêng và thiết kế website theo yêu cầu để phục vụ những khách hàng có nhu cầu riêng biệt và cao cấp hơn, khách hàng có nhu cầu vui lòng truy cập <a href=\"http://vinades.vn\" target=\"_blank\">http://vinades.vn</a> hoặc liên hệ nhân viên kinh doanh của VINADES.,JSC để được tư vấn và báo giá dịch vụ.<br  /><br  /><div style=\"text-align: justify;\"> Như vậy, cùng với việc tham gia cung cấp hosting chuyên nghiệp dành cho NukeViet của các nhà cung cấp hosting trong và ngoài nước như <strong><a href=\"http://vinades.vn/vi/news/Doi-tac/VINADES-JSC-va-DIGISTAR-hop-tac-trong-viec-phat-trien-ma-nguon-mo-NukeViet-17/\">DIGISTAR</a></strong>, <strong><a href=\"http://nukeviet.vn/vi/news/the-gioi-cong-nghe/TMDHosting-cung-cap-dich-vu-hosting-chuyen-NukeViet-64/\" title=\"TMDHosting cung cấp dịch vụ hosting chuyên NukeViet\">TMDHosting</a></strong> hay <strong><a href=\"http://nukeviet.vn/vi/news/the-gioi-cong-nghe/SiteGround-cung-cap-dich-vu-hosting-chuyen-NukeViet-59/\" title=\"SiteGround cung cấp dịch vụ hosting chuyên NukeViet\">SiteGround</a></strong>, <a href=\"http://nukeviet.vn/vi/news/the-gioi-cong-nghe/website-dau-tien-thiet-ke-website-va-ban-code-chuyen-nghiep-danh-cho-NukeViet-67/\" title=\"Webnhanh.vn - website đầu tiên thiết kế website và bán code chuyên nghiệp dành cho NukeViet\"><strong>Webnhanh.vn</strong> là website đầu tiên có dịch vụ thiết kế website và bán code chuyên nghiệp</a> dành riêng cho NukeViet. Sự chuyên nghiệp hóa trong các khâu từ phát triển đến cung cấp dịch vụ cho mã nguồn mở NukeViet sẽ mở ra một cơ hội phát triển mới cho người sử dụng web ở Việt Nam.</div>', 'http://nukeviet.vn/vi/news/website/website-dau-tien-thiet-ke-website-va-ban-code-chuyen-nghiep-danh-cho-NukeViet-67/', 2, 0, 1, 1, 1), 
(9, '<div> Nhắc đến các hệ thống quản trị nội dung (Content Management System – CMS) để quản lý các cổng thông tin điện tử trên Internet, không ít người sẽ nhắc đến các bộ công cụ như Joomla hay Wordpress. Tuy nhiên, có một sản phẩm hoàn toàn thuần Việt, do người Việt xây dựng không hề thua kém những sản phẩm trên cả về tính năng lẫn khả năng ứng dụng, đó là NukeViet của nhóm tác giả thuộc Công ty Cổ phần phát triển nguồn mở Việt Nam (VINADES).</div><div> &nbsp;</div><div> Với NukeViet, người dùng tại Việt Nam sẽ vượt qua các trở ngại về rào cản ngôn ngữ, có thể xây dựng và vận hành các trang web một cách dễ dàng nhất, đồng thời nhận được sự hỗ trợ của cộng đồng người dùng và các nhà phát triển cũng chính là người Việt Nam.</div><div> &nbsp;</div><div> Mới đây nhất, Ban giám khảo <span style=\"FONT-STYLE: italic\">Giải thưởng Nhân Tài Đất Việt 2011</span> đã quyết định đưa NukeViet vào danh sách các sản phẩm đã vượt qua vòng sơ khảo để tranh tài tại vòng chung khảo của <span style=\"FONT-STYLE: italic\">Giải Thưởng Nhân Tài Đất Việt 2011</span> diễn ra vào ngày 17-18/11 tới đây.</div><div> &nbsp;</div><div> <span style=\"FONT-WEIGHT: bold\">Những ý tưởng giúp hình thành nên sản phẩm “thuần Việt”</span></div><div> &nbsp;</div><div> Theo chia sẻ của đại diện nhóm tác giả, năm 2004, anh Nguyễn Anh Tú, một lưu học sinh người Việt tại Nga với ý tưởng xây dựng một website để kết nối cộng đồng sinh viên du học đã sử dụng bộ CMS mã nguồn mở PHP-Nuke để thực hiện.</div><div> &nbsp;</div><div> Sau đó, anh Nguyễn Anh Tú đã phát triển và cải tiến bộ mã nguồn mở PHP-Nuke để chia sẻ cho các thành viên có nhu cầu xây dựng website một cách đơn giản và thuận tiện hơn. Được sự đón nhận của đông đảo người sử dụng, bộ mã nguồn đã liên tục được phát triển và trở thành một ứng dụng thuần Việt với tên gọi NukeViet. NukeViet đã nhanh chóng trở nên phổ biến trong giới các nhà xây dựng và phát triển website tại Việt Nam.</div><div> &nbsp;</div><div style=\"TEXT-ALIGN: center\"> <div> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\"><img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-1_4b905.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></span></div></div><div style=\"TEXT-ALIGN: center\"> <span style=\"FONT-SIZE: 10pt\"><span style=\"FONT-FAMILY: Tahoma\">Giao diện một website tin tức được xây dựng bằng NukeViet</span></span></div><div> &nbsp;</div><div> Trong quá trình phát triển NukeViet, có một điều đội ngũ kỹ thuật luôn trăn trở là làm sao để có thể nâng cao tỉ lệ đóng góp của người Việt vào trong mã nguồn sản phẩm. Chính vì ý thức được điều này nên mức độ thuần Việt của sản phẩm ngày càng được nâng cao trong từng phiên bản phát hành. Cho đến phiên bản 3.0 (phát hành tháng 10 năm 2010) thì NukeViet đã thực sự trở thành một sản phẩm mã nguồn mở riêng của Việt Nam với 100% dòng code được viết mới.</div><div> &nbsp;</div><div> Kể từ đây, cộng đồng mã nguồn mở Việt Nam đã có riêng một bộ mã nguồn thuần Việt, tự hào sánh bước ngang vai cùng các cộng đồng mã nguồn mở khác trên thế giới. NukeViet ra đời đã giúp cộng đồng mạng Việt Nam giải quyết nhu cầu và mong muốn có một bộ mã nguồn mở của riêng Việt Nam, giúp phát triển hệ thống website của người Việt một cách an toàn nhất, đảm bảo nhất.</div><div> &nbsp;</div><div style=\"TEXT-ALIGN: center\"> <div> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\"><img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-2_600d0.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></span></div></div><div style=\"TEXT-ALIGN: center\"> <span style=\"FONT-SIZE: 10pt\"><span style=\"FONT-FAMILY: Tahoma\">Một website bán hành trực tuyến xây dựng bằng NukeViet</span></span></div><div> &nbsp;</div><div> NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp.</div><div> &nbsp;</div><div> <span style=\"FONT-WEIGHT: bold\">Khả năng ứng dụng và những ưu điểm của NukeViet</span></div><div> &nbsp;</div><div> Kể từ khi ra đời và trải qua một quá trình dài phát triển, NukeViet hiện được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp. NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block...&nbsp;</div><div> &nbsp;</div><div> NukeViet chủ yếu được sử dụng làm trang tin tức &nbsp;nhờ module News tích hợp sẵn trong NukeViet được viết rất công phu, nó lại đặc biệt phù hợp với yêu cầu và đặc điểm sử dụng cho hệ thống tin tức. NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng do đó thường được những đối tượng người dùng không chuyên ưa thích.</div><div> &nbsp;</div><div style=\"TEXT-ALIGN: center\"> <div> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\"><img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-4_416a1.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></span></div></div><div style=\"TEXT-ALIGN: center\"> <span style=\"FONT-SIZE: 10pt\"><span style=\"FONT-FAMILY: Tahoma\">Website phòng Giáo dục và Đào tạo Lạng Giang được xây dựng trên mã nguồn NukeViet</span></span></div><div> &nbsp;</div><div> NukeViet có mã nguồn mở do đó việc sử dụng NukeViet là hoàn toàn miễn phí cho tất cả mọi người trên thế giới. Từ phiên bản 2.0 trở về trước, đối tượng người dùng chủ yếu của NukeViet là người Việt vì những đặc điểm của bản thân mã nguồn (có nguồn gốc từ PHP-Nuke) và vì chính sách của nhóm phát triển là: &quot;hệ thống Portal dành cho người Việt&quot;. Tuy nhiên, kể từ phiên bản 3.0, đội ngũ phát triển NukeViet định hướng đưa NukeViet ra cộng đồng quốc tế với hỗ trợ thêm nhiều ngôn ngữ.&nbsp;</div><div> &nbsp;</div><div> Trên thực tế, với những ưu điểm vượt trội của mình, NukeViet 3 đã được ứng dụng ở hàng ngàn website khác nhau. Đặc biệt, không ít các cơ quan, tổ chức của Nhà nước đã tin tưởng sử dụng mã nguồn NukeViet để xây dựng cổng thông tin điện tử của mình, như &nbsp;Cổng thông tin tích hợp 1 cửa cho Phòng giáo dục Lạng Giang, cổng thông tin 2 chiều - Công ty cổ phần đầu tư tài chính công đoàn dầu khí Việt Nam, Hệ thống tra cứu điểm, tra cứu văn bằng - Cổng thông tin Sở GD&amp;ĐT Quảng Ninh, Website viện y học cổ truyền Quân Đội…</div><div> &nbsp;</div><div> Tất cả các dự án trên đều được khách hàng đánh giá rất cao về tính ứng dụng, hiệu quả do tiết kiệm chi phí và đáp ứng rất tốt nhu cầu sử dụng của các đơn vị.&nbsp;</div><div> &nbsp;</div><div> <span style=\"FONT-WEIGHT: bold\">Hướng phát triển trong tương lai và những kỳ vọng trước mắt</span></div><div> &nbsp;</div><div> Với ý nghĩa là phần mềm quản lý website (chiếm tới 90% các giao tiếp và tương tác trực tiếp với người sử dụng trên môi trường internet), khi phát triển, NukeViet sẽ trở thành một công cụ truyền thông rất mạnh, có thể đem lại những hiệu quả to lớn khác. Nhóm phát triển sẽ phát huy lợi thế này để phát triển sản phẩm.</div><div> &nbsp;</div><div> Nhóm phát triển cũng muốn tăng cường các khả năng liên kết, chia sẻ và tích hợp dữ liệu giữa các hệ thống khác nhau nhằm tạo nên một mạng lưới lớn, rộng khắp và hoàn chỉnh, có thể huy động sức mạnh tổng lực, thực hiện các nhiệm vụ xã hội khác trên mã nguồn NukeViet của mình.</div><div> &nbsp;</div><div> NukeViet khi được kết hợp với xu thế phát triển của điện toán đám mây sẽ trở thành một nền tảng giúp phát triển nhiều hệ thống dịch vụ trực tuyến có thể thu hút nhiều người dùng với giá trị thương mại cao.</div><div> &nbsp;</div><div style=\"TEXT-ALIGN: center\"> <div> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\"><img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-3_46e98.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></span></div></div><div style=\"TEXT-ALIGN: center\"> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\">Giao diện soạn thảo nội dung trên NukeViet</span></div><div> &nbsp;</div><div> Với việc gửi sản phẩm dự thi tại <span style=\"FONT-STYLE: italic\">Giải thưởng Nhân Tài Đất Việt 2011</span>, nhóm tác giả của NukeViet hy vọng mã nguồn mở của mình sẽ đạt vị trí cao tại Giải thưởng, như một cách thức để quảng bá rộng rãi sản phẩm, được thừa nhận và hỗ trợ sử dụng trong các lĩnh vực mà nó có thể phục vụ tốt và đem lại hiệu quả kinh tế, xã hội cao như: lĩnh vực giáo dục, lĩnh vực hành chính… để các bộ-ban-ngành, các cơ quan hành chính, chính quyền địa phương nhìn thấy giá trị và hiệu quả to lớn của mã nguồn mở NukeViet để triển khai NukeViet phục vụ các cơ quan này. NukeViet sẽ giúp hiện thực hóa cải cách hành chính và góp phần đẩy nhanh thủ tục một cửa một cách tiết kiệm mà vẫn đạt hiệu quả cao nhất.</div><div> &nbsp;</div><div> Ngoài ra, uy tính của Giải thưởng, nhóm tác giả NukeViet hy vọng sẽ đem NukeViet đến nhiều người hơn, để cả xã hội được sử dụng thành quả lớn lao của bộ mã nguồn mở được coi là biểu tượng và đại diện tiểu biểu cho sự phát triển và thành công của mã nguồn mở Việt Nam. Không chỉ thế, mở ra cơ hội tiếp cận và học hỏi công nghệ cho hàng ngàn học sinh, sinh viên, qua đó có được các kiến thức đầy đủ về công nghệ web, về internet và vô số các kỹ năng làm việc trên máy tính khác mà có thể do vô tình hay cố ý, trong quá trình tìm hiểu, học tập và vận hành NukeViet mà họ đã có được.</div><div> &nbsp;</div><div> Với những ứng dụng rộng rãi mà NukeViet đã có được kể từ khi ra mắt và và trải qua thời gian dài phát triển, Hội đồng <span style=\"FONT-STYLE: italic\">Giám khảo Giải Thưởng Nhân &nbsp;Tài Đất Việt</span> đã đánh giá rất cao những ưu điểm và thế mạnh của NukeViet để đưa sản phẩm vào danh sách 17 sản phẩm sẽ tranh tài tại vòng Chung khảo của <span style=\"FONT-STYLE: italic\">Giải Thưởng Nhân Tài Đất Việt 2011</span> diễn ra vào ngày 17-18/11 tới đây.</div><div> &nbsp;</div><div> Bạn đọc có thể tìm hiểu thêm về NukeViet tại <span style=\"FONT-WEIGHT: bold\"><a href=\"http://nukeviet.vn/vi/news/Bao-chi-viet/\">http://nukeviet.vn/</a>.</span></div>', 'http://dantri.com.vn/c119/s119-537812/nukeviet-cong-cu-ma-nguon-mo-cho-cong-dong-thiet-ke-website-vn.htm', 1, 0, 1, 1, 1), 
(10, 'Cả hội trường như vỡ òa, rộn tiếng vỗ tay, tiếng cười nói chúc mừng các nhà khoa học, các nhóm tác giả đoạt Giải thưởng Nhân tài Đất Việt năm 2011. Năm thứ 7 liên tiếp, Giải thưởng đã phát hiện và tôn vinh nhiều tài năng của đất nước.<div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/01_b7d3f.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Sân khấu trước lễ trao giải.</span></div><div> &nbsp;</div><div align=\"center\"> &nbsp;</div><div align=\"left\"> Cơ cấu Giải thưởng của Nhân tài Đất Việt 2011 trong lĩnh vực CNTT bao gồm 2 hệ thống giải dành cho “Sản phẩm có tiềm năng ứng dụng” và “Sản phẩm đã ứng dụng rộng rãi trong thực tế”. Mỗi hệ thống giải sẽ có 1 giải Nhất, 1 giải Nhì và 1 giải Ba với trị giá giải thưởng tương đương là 100 triệu đồng, 50 triệu đồng và 30 triệu đồng cùng phần thưởng của các đơn vị tài trợ.</div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/03_f19bd.jpg\" width=\"350\" /></div> <div align=\"center\"> Nhiều tác giả, nhóm tác giả đến lễ trao giải từ rất sớm.</div></div><p> Giải thưởng Nhân tài Đất Việt 2011 trong lĩnh vực Khoa học Tự nhiên được gọi chính thức là Giải thưởng Khoa học Tự nhiên Việt Nam sẽ có tối đa 6 giải, trị giá 100 triệu đồng/giải dành cho các lĩnh vực: Toán học, Cơ học, Vật lý, Hoá học, Các khoa học về sự sống, Các khoa học về trái đất (gồm cả biển) và môi trường, và các lĩnh vực khoa học liên ngành hoặc đa ngành của hai hoặc nhiều ngành nói trên. Viện Khoa học và Công nghệ Việt Nam thành lập Hội đồng giám khảo gồm các nhà khoa học tự nhiên hàng đầu trong nước để thực hiện việc đánh giá và trao giải.</p><div> Sau thành công của việc trao Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y dược năm 2010, Ban Tổ chức tiếp tục tìm kiếm những chủ nhân xứng đáng cho Giải thưởng này trong năm 2011.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/07_78b85.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam Lê Khả Phiêu tới&nbsp;dự Lễ trao giải.</span></div><div> &nbsp;</div><div> 45 phút trước lễ trao giải, không khí tại Cung Văn hóa Hữu nghị Việt - Xô đã trở nên nhộn nhịp. Sảnh phía trước Cung gần như chật kín. Rất đông bạn trẻ yêu thích công nghệ thông tin, sinh viên các trường đại học đã đổ về đây, cùng với đó là những bó hoa tươi tắn sẽ được dành cho các tác giả, nhóm tác giả đoạt giải.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/09_aef87.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Phó Chủ tịch nước CHXHCN Việt Nam Nguyễn Thị Doan.</span></div><div> &nbsp;</div><div> Các vị khách quý cũng đến từ rất sớm. Tới tham dự lễ trao giải năm nay có ông Lê Khả Phiêu, nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam; bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCN Việt Nam; ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam; ông Nguyễn Bắc Son, Bộ trưởng Bộ Thông tin và Truyền thông; ông Đặng Ngọc Tùng, Chủ tịch Tổng Liên đoàn lao động Việt Nam; ông Phạm Văn Linh, Phó trưởng ban Tuyên giáo Trung ương; ông Đỗ Trung Tá, Phái viên của Thủ tướng Chính phủ về CNTT, Chủ tịch Hội đồng Khoa học công nghệ quốc gia; ông Nguyễn Quốc Triệu, nguyên Bộ trưởng Bộ Y tế, Trưởng Ban Bảo vệ Sức khỏe TƯ; bà Cù Thị Hậu, Chủ tịch Hội người cao tuổi Việt Nam; ông Lê Doãn Hợp, nguyên Bộ trưởng Bộ Thông tin Truyền thông, Chủ tịch Hội thông tin truyền thông số…</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/08_ba46c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Bộ trưởng Bộ Thông tin và Truyền thông Nguyễn Bắc Son.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/06_29592.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Giáo sư - Viện sỹ Nguyễn Văn Hiệu.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/04_051f2.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Bộ trưởng Bộ Y tế Nguyễn Quốc Triệu.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/05_c7ea4.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam.</span></div><p> Do tuổi cao, sức yếu hoặc bận công tác không đến tham dự lễ trao giải nhưng Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang cũng gửi lẵng hoa đến chúc mừng lễ trao giải.</p><div> Đúng 20h, Lễ trao giải bắt đầu với bài hát “Nhân tài Đất Việt” do ca sỹ Thái Thùy Linh cùng ca sĩ nhí và nhóm múa biểu diễn. Các nhóm tác giả tham dự Giải thưởng năm 2011 và những tác giả của các năm trước từ từ bước ra sân khấu trong tiếng vỗ tay tán dương của khán giả.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/12_74abf.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN15999_3e629.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Tiết mục mở màn Lễ trao giải.</span></div><p> Trước Lễ trao giải Giải thưởng Nhân tài Đất Việt năm 2011, Đại tướng Võ Nguyên Giáp, Chủ tịch danh dự Hội Khuyến học Việt Nam, đã gửi thư chúc mừng, khích lệ Ban tổ chức Giải thưởng cũng như các nhà khoa học, các tác giả tham dự.</p><blockquote> <p> <em><span style=\"FONT-STYLE: italic\">Hà Nội, ngày 16 tháng 11 năm 2011</span></em></p> <div> <em>Giải thưởng “Nhân tài đất Việt” do Hội Khuyến học Việt Nam khởi xướng đã bước vào năm thứ bảy (2005 - 2011) với ba lĩnh vực: Công nghệ thông tin, Khoa học tự nhiên và Y dược.</em></div></blockquote><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/thuDaituong1_767f4.jpg\" style=\"MARGIN: 5px\" width=\"400\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Thư của Đại tướng Võ Nguyên Giáp gửi BTC Giải thưởng Nhân tài đất Việt.</span></div><blockquote> <p> <em>Tôi gửi lời chúc mừng các nhà khoa học và các thí sinh được nhận giải thưởng “Nhân tài đất Việt” năm nay.</em></p> <p> <em>Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực.</em></p> <p> <em>Nhân ngày “Nhà giáo Việt Nam”, chúc Hội Khuyến học Việt nam, chúc các thầy giáo và cô giáo, với tâm huyết và trí tuệ của mình, sẽ đóng góp xứng đáng vào công cuộc đổi mới căn bản và toàn diện nền giáo dục nước nhà, để cho nền giáo dục Việt Nam thực sự là cội nguồn của nguyên khí quốc gia, đảm bảo cho mọi nhân cách và tài năng đất Việt được vun đắp và phát huy vì sự trường tồn, sự phát triển tiến bộ và bền vững của đất nước trong thời đại toàn cầu hóa và hội nhập quốc tế.</em></p> <p> <em>Chào thân ái,</em></p> <p> <strong><em>Chủ tịch danh dự Hội Khuyến học Việt Nam</em></strong></p> <p> <strong><em>Đại tướng Võ Nguyên Giáp</em></strong></p></blockquote><p> Phát biểu khai mạc Lễ trao giải, Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng Ban tổ chức, bày tỏ lời cám ơn chân thành về những tình cảm cao đẹp và sự quan tâm chăm sóc của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang đã và đang dành cho Nhân tài Đất Việt.</p><div> Nhà báo Phạm Huy Hoàn nhấn mạnh, Giải thưởng Nhân tài Đất Việt suốt 7 năm qua đều nhận được sự quan tâm của các vị lãnh đạo Đảng, Nhà nước và của toàn xã hội. Tại Lễ trao giải, Ban tổ chức luôn có vinh dự được đón tiếp&nbsp;các vị lãnh đạo&nbsp; Đảng và Nhà nước đến dự và trực tiếp trao Giải thưởng.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/15_4670c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Trưởng Ban tổ chức Phạm Huy Hoàn phát biểu khai mạc buổi lễ.</span></div><p> Năm 2011, Giải thưởng có 3 lĩnh vực được xét trao giải là CNTT, Khoa học tự nhiên và Y dược. Lĩnh&nbsp; vực CNTT đã đón nhận 204 sản phẩm tham dự từ mọi miền đất nước và cả nước ngoài như thí sinh Nguyễn Thái Bình từ bang California - Hoa Kỳ và một thí sinh ở Pháp cũng đăng ký tham gia.</p><div> “Cùng với lĩnh vực CNTT, năm nay, Hội đồng khoa học của Viện khoa học và công nghệ Việt Nam và Hội đồng khoa học - Bộ Y tế tiếp tục giới thiệu những nhà khoa học xuất&nbsp; sắc, có công trình nghiên cứu đem lại nhiều lợi ích cho xã hội trong lĩnh vực khoa học tự nhiên và lĩnh vực y dược. Đó là những bác sĩ tài năng, những nhà khoa học mẫn tuệ, những người đang ngày đêm thầm lặng cống hiến trí tuệ sáng tạo của mình cho xã hội trong công cuộc xây dựng đất nước.” - nhà báo Phạm Huy Hoàn nói.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/14_6e18f.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng BTC Giải thưởng và ông Phan Hoàng Đức, Phó TGĐ Tập đoàn VNPT nhận lẵng hoa chúc mừng của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang.</span></div><p> Cũng theo Trưởng Ban tổ chức Phạm Huy Hoàn, đến nay, vị Chủ tịch danh dự đầu tiên của Hội Khuyến học Việt Nam, Đại tướng Võ Nguyên Giáp, đã bước qua tuổi 100 nhưng vẫn luôn dõi theo và động viên từng bước phát triển của Giải thưởng Nhân tài Đất Việt. Đại tướng luôn quan tâm chăm sóc Giải thưởng ngay từ khi Giải thưởng&nbsp; mới ra đời cách đây 7 năm.</p><p> Trước lễ trao giải, Đại tướng Võ Nguyên Giáp đã gửi thư chúc mừng, động viên Ban tổ chức. Trong thư, Đại tướng viết: “Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực.</p><p> Sau phần khai mạc, cả hội trường hồi hội chờ đợi phút vinh danh các nhà khoa học và các tác giả, nhóm tác giả đoạt giải.</p><div> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Khoa học Tự nhiên Việt Nam </span>thuộc về 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ - Viện Vật lý, Viện Khoa học công nghệ Việt Nam với công trình “Nghiên cứu cấu trúc hạt nhân và các phản ứng hạt nhân”.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn_d4aae.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Hai nhà khoa học đã tiến hành thành công các nghiên cứu về phản ứng hạt nhân với nơtron, phản ứng quang hạt nhân, quang phân hạch và các phản ứng hạt nhân khác có cơ chế phức tạp trên các máy gia tốc như máy phát nơtron, Microtron và các máy gia tốc thẳng của Việt Nam và Quốc tế. Các nghiên cứu này đã góp phần làm sáng tỏ cấu trúc hạt nhân và cơ chế phản ứng hạt nhân, đồng thời cung cấp nhiều số liệu hạt nhân mới có giá trị cho Kho tàng số liệu hạt nhân.</p><p> GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ đã khai thác hiệu quả hai máy gia tốc đầu tiên của Việt Nam là máy phát nơtron NA-3-C và Microtron MT-17 trong nghiên cứu cơ bản, nghiên cứu ứng dụng và đào tạo nhân lực. Trên cơ sở các thiết bị này, hai nhà khoa học đã tiến hành thành công những nghiên cứu cơ bản thực nghiệm đầu tiên về phản ứng hạt nhân ở Việt Nam; nghiên cứu và phát triển các phương pháp phân tích hạt nhân hiện đại và áp dụng thành công ở Việt Nam.</p><div> Bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCNVN và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn2_e2865.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Phó Chủ tịch nước CHXHCNVN Nguyễn Thị Doan và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ.</span></div><p> GS.VS Nguyễn Văn Hiệu chia sẻ: “Cách đây không lâu, Chính phủ đã ký quyết định xây dựng nhà máy điện hạt nhân trong điều kiện đất nước còn nhỏ bé, nghèo khó và vì thế việc đào tạo nhân lực là nhiệm vụ số 1 hiện nay. Rất may, Việt Nam có 2 nhà khoa học cực kỳ tâm huyết và nổi tiếng trong cả nước cũng như trên thế giới. Hội đồng khoa học chúng tôi muốn xướng tên 2 nhà khoa học này để Chính phủ huy động cùng phát triển xây dựng nhà máy điện hạt nhân.”</p><p> GS.VS Hiệu nhấn mạnh, mặc dù điều kiện làm việc của 2 nhà khoa học không được quan tâm, làm việc trên những máy móc cũ kỹ được mua từ năm 1992 nhưng 2 ông vẫn xay mê cống hiến hết mình cho lĩnh Khoa học tự nhiên Việt Nam.</p><p> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y Dược:</span> 2 giải</p><div> <span style=\"FONT-WEIGHT: bold\">1.</span> Nhóm nghiên cứu của Bệnh viện Hữu nghị Việt - Đức với công trình <span style=\"FONT-STYLE: italic\">“Nghiên cứu triển khai ghép gan, thận, tim lấy từ người cho chết não”</span>.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y_3dca2.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><div> &nbsp;</div><div> Tại bệnh viện Việt Đức, tháng 4/2011, các ca ghép tạng từ nguồn cho là người bệnh chết não được triển khai liên tục. Với 4 người cho chết não hiến tạng, bệnh viện đã ghép tim cho một trường hợp,&nbsp;2 người được ghép gan, 8 người được ghép thận, 2 người được ghép van tim và tất cả các ca ghép này đều thành công, người bệnh được ghép đã có một cuộc sống tốt hơn với tình trạng sức khỏe ổn định.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y2_cb5a1.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Tổng Bí Ban chấp hành TW Đảng CSVN Lê Khả Phiêu và ông Vũ Văn Tiền, Chủ tịch Hội đồng quản trị Ngân hàng An Bình trao giải thưởng cho nhóm nghiên cứu của BV Hữu nghị Việt - Đức.</span></div><p> Công trong việc ghép tạng từ người cho chết não không chỉ thể hiện năng lực, trình độ, tay nghề của bác sĩ Việt Nam mà nó còn mang một ý nghĩa nhân văn to lớn, mang một thông điệp gửi đến những con người giàu lòng nhân ái với nghĩa cử cao đẹp đã hiến tạng để cứu sống những người bệnh khác.</p><p> <span style=\"FONT-WEIGHT: bold\">2.</span> Hội đồng ghép tim Bệnh viện Trung ương Huế với công trình nghiên cứu <span style=\"FONT-STYLE: italic\">“Triển khai ghép tim trên người lấy từ người cho chết não”</span>.</p><div> Đề tài được thực hiện dựa trên ca mổ ghép tim thành công lần đầu tiên ở Việt Nam của chính 100% đội ngũ y, bác sĩ của Bệnh viện Trung ương Huế đầu tháng 3/2011. Bệnh nhân được ghép tim thành công là anh Trần Mậu Đức (26 tuổi, ở phường Phú Hội, TP. Huế).</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y3_7768c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Hội đồng ghép tim BV Trung ương Huế nhận Giải thưởng Nhân tài Đất Việt.</span></div><p> Ghép tim từ người cho chết não đến người bị bệnh tim cần được ghép tim phải đảm bảo các yêu cầu: đánh giá chức năng các cơ quan; đánh giá tương hợp miễn dịch và phát hiện nguy cơ tiềm ẩn có thể xảy ra trong và sau khi ghép tim để từ đó có phương thức điều trị thích hợp. Có tới 30 xét nghiệm cận lâm sàng trung và cao cấp tiến hành cho cả người cho tim chết não và người sẽ nhận ghép tim tại hệ thống labo của bệnh viện.</p><p> ---------------------</p><p> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Nhân tài đất Việt Lĩnh vực Công nghệ thông tin.</span></p><p> <span style=\"FONT-STYLE: italic\">Hệ thống sản phẩm đã ứng dụng thực tế:</span></p><p> <span style=\"FONT-STYLE: italic\">Giải Nhất:</span> Không có.</p><p> <span style=\"FONT-STYLE: italic\">Giải Nhì:</span> Không có</p><p> <span style=\"FONT-STYLE: italic\">Giải Ba:</span> 3 giải, mỗi giải trị giá 30 triệu đồng.</p><div> <span style=\"FONT-WEIGHT: bold\">1.</span> <span style=\"FONT-STYLE: italic\">“Bộ cạc xử lý tín hiệu HDTV”</span> của nhóm HD Việt Nam.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/hdtv_13b10.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhóm HDTV Việt Nam lên nhận giải.</span></div><p> Đây là bộ cạc xử lý tín hiệu HDTV đầu tiên tại Việt Nam đạt tiêu chuẩn OpenGear. Bộ thiết bị bao gồm 2 sản phẩm là cạc khuếch đại phân chia tín hiệu HD DA và cạc xử lý tín hiệu HD FX1. Nhờ bộ cạc này mà người sử dụng cũng có thể điều chỉnh mức âm thanh hoặc video để tín hiệu của kênh tuân theo mức chuẩn và không phụ thuộc vào chương trình đầu vào.</p><div> <span style=\"FONT-WEIGHT: bold; FONT-STYLE: italic\">2.</span> <span style=\"FONT-STYLE: italic\">“Mã nguồn mở NukeViet”</span> của nhóm tác giả Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC).</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" alt=\"NukeViet nhận giải ba Nhân tài đất Việt 2011\" src=\"/nuke342/uploads/news/nukeviet-nhantaidatviet2011.jpg\" style=\"margin: 5px; width: 450px; height: 301px;\" /></div></div><p> NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp.</p><div> <span style=\"FONT-WEIGHT: bold\">3.</span> <span style=\"FONT-STYLE: italic\">“Hệ thống ngôi nhà thông minh homeON”</span> của nhóm Smart home group.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16132_82014.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Sản phẩm là kết quả từ những nghiên cứu miệt mài nhằm xây dựng một ngôi nhà thông minh, một cuộc sống xanh với tiêu chí: An toàn, tiện nghi, sang trọng và tiết kiệm năng lượng, hưởng ứng lời kêu gọi tiết kiệm năng lượng của Chính phủ.&nbsp;</p><p> <strong><span style=\"FONT-STYLE: italic\">* Hệ thống sản phẩm có tiềm năng ứng dụng:</span></strong></p><p> <span style=\"FONT-STYLE: italic\">Giải Nhất: </span>Không có.</p><div> <span style=\"FONT-STYLE: italic\">Giải Nhì:</span> trị giá 50 triệu đồng: <span style=\"FONT-STYLE: italic\">“Dịch vụ Thông tin và Tri thức du lịch ứng dụng cộng nghệ ngữ nghĩa - iCompanion”</span> của nhóm tác giả SIG.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/nhi_7eee0.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhóm tác giả SIG nhận giải Nhì Nhân tài đất Việt 2011 ở hệ thống sản phẩm có tiềm năng ứng dụng.</span></div><p> ICompanion là hệ thống thông tin đầu tiên ứng dụng công nghệ ngữ nghĩa trong lĩnh vực du lịch - với đặc thù khác biệt là cung cấp các dịch vụ tìm kiếm, gợi ý thông tin “thông minh” hơn, hướng người dùng và kết hợp khai thác các tính năng hiện đại của môi trường di động.</p><p> Đại diện nhóm SIG chia sẻ: “Tinh thần sáng tạo và lòng khát khao muốn được tạo ra các sản phẩm mới có khả năng ứng dụng cao trong thực tiễn luôn có trong lòng của những người trẻ Việt Nam. Cảm ơn ban tổ chức và những nhà tài trợ đã giúp chúng tôi có một sân chơi thú vị để khuyến khích và chắp cánh thực hiện ước mơ của mình. Xin cảm ơn trường ĐH Bách Khoa đã tạo ra một môi trường nghiên cứu và sáng tạo, gắn kết 5 thành viên trong nhóm.”</p><p> <span style=\"FONT-STYLE: italic\">Giải Ba:</span> 2 giải, mỗi giải trị giá 30 triệu đồng.</p><div> <span style=\"FONT-WEIGHT: bold\">1. </span><span style=\"FONT-STYLE: italic\">“Bộ điều khiển IPNET”</span> của nhóm IPNET</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16149_ed58d.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhà báo Phạm Huy Hoàn, Trưởng Ban Tổ chức Giải thưởng NTĐV, Tổng Biên tập báo điện tử Dân trí và ông Tạ Hữu Thanh - Phó TGĐ Jetstar Pacific trao giải cho nhóm IPNET.</span></div><p> Bằng cách sử dụng kiến thức thiên văn học để tính giờ mặt trời lặn và mọc tại vị trí cần chiếu sáng được sáng định bởi kinh độ, vĩ độ cao độ, hàng ngày sản phẩm sẽ tính lại thời gian cần bật/tắt đèn cho phù hợp với giờ mặt trời lặn/mọc.</p><div> <span style=\"FONT-WEIGHT: bold\">2.</span> <span style=\"FONT-STYLE: italic\">“Hệ thống lập kế hoạch xạ trị ung thư quản lý thông tin bệnh nhân trên web - LYNX”</span> của nhóm LYNX.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/3tiem-nang_32fee.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Đây là loại phần mềm hoàn toàn mới ở Việt Nam, là hệ thống lập kế hoạch và quản lý thông tin của bệnh nhân ung thư qua Internet (LYNX) dựa vào nền tảng Silverlight của Microsoft và kiến thức chuyên ngành Vật lý y học. LYNX giúp ích cho các nhà khoa học, bác sĩ, kỹ sư vật lý, bệnh nhân và mọi thành viên trong việc quản lý và theo dõi hệ thống xạ trị ung thư một cách tổng thể. LYNX có thể được sử dụng thông qua các thiết bị như máy tính cá nhân, máy tính bảng… và các trình duyệt Internet Explorer, Firefox, Chrome…</p><div> Chương trình trao giải đã được truyền hình trực tiếp trên VTV2 - Đài Truyền hình Việt Nam và tường thuật trực&nbsp;tuyến trên báo điện tử Dân trí từ 20h tối 20/11/2011.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0545_c898e.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0560_c995c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16199_36a5c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div align=\"center\"> <table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\"90%\"> <tbody> <tr> <td> <div> <span style=\"FONT-WEIGHT: bold\"><span style=\"FONT-WEIGHT: normal; FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Khởi xướng từ năm 2005, Giải thưởng Nhân tài Đất Việt đã phát hiện và tôn vinh nhiều tài năng trong lĩnh vực CNTT-TT, Khoa học tự nhiên và Y dược, trở thành một sân chơi bổ ích cho những người yêu thích CNTT. Mỗi năm, Giải thưởng ngày càng thu hút số lượng tác giả và sản phẩm tham gia đông đảo và nhận được sự quan tâm sâu sắc của lãnh đạo Đảng, Nhà nước cũng như công chúng.</span></span></div> <div> <span style=\"FONT-WEIGHT: bold\">&nbsp;</span></div> <div> <span style=\"FONT-WEIGHT: bold\"><span style=\"FONT-WEIGHT: normal; FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Đối tượng tham gia Giải thưởng trong lĩnh vực CNTT là những người Việt Nam ở mọi lứa tuổi, đang sinh sống trong cũng như ngoài nước. Năm 2006, Giải thưởng có sự tham gia của thí sinh đến từ 8 nước trên thế giới và 40 tỉnh thành của Việt Nam. Từ năm 2009, Giải thưởng được mở rộng sang lĩnh vực Khoa học tự nhiên, và năm 2010 là lĩnh vực Y dược, vinh danh những nhà khoa học trong các lĩnh vực này.</span>&nbsp;</span></div> <div> <span style=\"FONT-WEIGHT: bold\">&nbsp;</span></div> </td> </tr> </tbody> </table> </div></div>', 'http://dantri.com.vn/c119/s119-539911/nhan-tai-dat-viet-chap-canh-khat-khao-sang-tao.htm', 2, 0, 1, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_bodytext`
--

DROP TABLE IF EXISTS `vt_vi_news_bodytext`;
CREATE TABLE `vt_vi_news_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_bodytext`
--

INSERT INTO `vt_vi_news_bodytext` VALUES
(1, 'Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam. Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế. NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet. NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm xem chi tiết), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov xem chi tiết); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.'), 
(2, 'Câu chuyện của NukeViet và VINADES.,JSC Từ một trăn trở Giữa năm 2009, trước yêu cầu cấp thiết phải đổi mới và làm một cuộc cách mạng cho mã nguồn mở NukeViet, một cuộc thảo luận sôi nổi đã diễn ra với tiêu đề \"Lối đi nào để chuyên nghiệp hóa mã nguồn mở NukeViet\". Kết quả của cuộc thảo luận này là 55 bài viết với hàng chục ý kiến đóng góp đã được đưa ra. Các giải pháp về tài chính, nhân lực, phương hướng hoạt động được đem ra thảo luận. rockbuilc, Nkd833 đề xuất phương án thành lập doanh nghiệp chuyên quản NukeViet như một giải pháp toàn diện để giải quyết vấn đề chuyên nghiệp hóa NukeViet. Các vấn đề được các thành viên tham gia thảo luận và mổ xẻ thẳng thắn, nhiều ý kiến phản biện trái chiều cũng được đưa ra trên tinh thần xây dựng. Sau 2 tháng thảo luận, Ban Quản Trị đã có dự định... Gặp mặt Tháng 11, Sau khi tham khảo các ý kiến của mọi người trên diễn đàn, Anh Tú đã trực tiếp về Việt Nam. Một cuộc offline được tổ chức chớp nhoáng với sự tham gia của các thành viên chủ chốt tại Hà Nội. Các cuộc tìm hiểu và tiếp xúc được triển khai gấp rút trong giai đoạn này. Một mô hình - một lối đi Hướng đi chuyên nghiệp hóa việc phát triển NukeViet đã được anh Tú chọn lựa: \"Thành lập doanh nghiệp chuyên quản NukeViet\". Doanh nghiệp chuyên quản NukeViet được thành lập từ chính nhu cầu của cộng đồng nhằm chuyên nghiệp hóa NukeViet, vì vậy mô hình công ty cổ phần được chọn lựa để đáp ứng yêu cầu đó. Chịu trách nhiệm triển khai, laser đã lên phương án đầu tư, mục tiêu, kế hoạch phát triển ngắn và dài hạn. Triển khai thực hiện Tháng 1 năm 2010, việc thành lập đã được xúc tiến. Ngày 25/02/2010, trên các bản tin tiếng Anh và tiếng Việt xuất hiện bản tin \"Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam\". Đó là Công ty cổ phần Phát triển nguồn mở Việt Nam (VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY - VINADES.,JSC). Đây là một vài hình ảnh trong ngày khai trương: Anh Tú phát biểu khai trương VINADES.,JSC Anh Tú phát biểu khai trương VINADES.,JSC http://nukeviet.vn/uploads/spaw2/images/hung-phatbieu.jpg Anh Tú phát biểu khai trương VINADES.,JSC Nguyễn Hùng giới thiệu đôi nét về công ty, mục tiêu và phương hướng hoạt động. http://nukeviet.vn/uploads/spaw2/images/nangly.jpg Cùng nâng ly chúc mừng khai trương. Cùng nâng ly chúc mừng khai trương. ... và lời cảm ơn gửi tới cộng đồng VINADES.,JSC từ khi được thai nghén tới lúc chập chững những bước đi ban đầu đều có sự động viên, ủng hộ và đóng góp lớn nhỏ của cộng đồng NukeViet - Một cộng đồng gắn liền với những ký ức, những kỷ niệm buồn vui và mang trong mỗi thành viên một đam mê, một hoài bão lớn lao. \"Lửa thử vàng, gian nan thử sức\", mỗi khó khăn trả qua khiến cộng đồng NukeViet lớn dần lên, gắn kết với nhau bằng một sợi dây vô hình không thể chia cắt: đó là niềm đam mê với mã nguồn mở, với công nghệ web. VINADES.,JSC được tạo ra từ cộng đồng và sẽ cố gắng hết sức để hoạt động vì lợi ích của cộng đồng. http://nukeviet.vn/uploads/spaw2/images/anhvp2.jpg Văn phòng làm việc của VINADES.,JSC ở Hà Nội. http://nukeviet.vn/uploads/spaw2/images/anhvp3.jpg Một góc văn phòng nhìn từ trong ra ngoài. NukeViet 3.0 - Cuộc cách mạng của NukeViet Sau nhiều tháng triển khai, NukeViet 3.0 đã được định hình và dự định công bố bản beta trong thời gian gần. NukeViet 3.0 là phiên bản mang tính cách mạng của hệ thống NukeViet vì 100% các dòng code của NukeViet 3.0 đã được viết mới hoàn toàn chứ không sử dụng nền tảng cũ. Việc này đã ngốn rất nhiều thời gian và công sức của đội ngũ lập trình. Đó cũng là lý do vì sao bản 2.0 không được cải tiến nhiều trong thời gian qua. NukeViet 3.0 được xây dựng với mong muốn có một nền tảng ổn định để sau đó có thể đầu tư lâu dài, xây dựng một thư viện ứng dụng phong phú. VINADES.,JSC sẽ song hành cùng cộng đồng NukeViet trong việc hỗ trợ và phát triển NukeViet thành một mã nguồn mở hoạt động ở quy mô chuyên nghiệp. Đây là bước đi đầu tiên trong trong tiến trình chuyên nghiệp hóa này. Các ứng dụng bổ sung sẽ được xây dựng bài bản, chất lượng. Cộng đồng NukeViet sẽ không chỉ là cộng đồng người sử dụng mà sẽ được đầu tư về đào tạo để trở thành một cộng đồng lập trình mạnh. Thông tin chi tiết về dự án phát triển NukeViet 3.0 được cập nhật tại đây: http://nukeviet.vn/phpbb/viewforum.php?f=99 http://nukeviet.vn/phpbb/viewforum.php?f=99'), 
(6, 'THƯ MỜI HỢP TÁC TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN MÃ NGUỒN MỞ NUKEVIET   Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh. VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này. NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển. Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên. Phương thức hợp tác nhưsau: 1.Quảng cáo, trao đổi banner, liên kết website: a. Mô tả hình thức: - Quảng cáo trên website & hệ thống kênh truyền thông của 2 bên. - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet. b, Lợi ích: - Quảng bá rộng rãi cho đối tượng của 2 bên. - Giảm chi phí quảng bá cho 2 bên. c, Trách nhiệm: - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên. - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet. 2.Hợp tác cung cấp hosting thử nghiệm NukeViet: a. Mô tả hình thức: - Hai bên ký hợp đồng nguyên tắc & thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó: + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt. + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet. b. Lợi ích: - Mở rộng thị trường theo cả hướng đối tượng. - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh. c. Trách nhiệm: - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác. - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác. 3,Hợp tác nhân lực hỗ trợ người sử dụng: a, Mô tả hình thức: - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng. + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác. b, Lợi ích: - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên. - Tăng hiệu quả hỗ trợ khách hàng. c, Trách nhiệm: - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệu quả của sự hợp tác song phưong này. 4. Các hình thức khác: Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam. Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”. Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị. Thông tin liên hệ: CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC) Trụ sở chính: Phòng 1805 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội. Điện thoại: +84-4-85872007 Fax: +84-4-35500914 Website: http://www.vinades.vn/ www.vinades.vn – http://www.nukeviet.vn/ www.nukeviet.vn Email: mailto:contact@vinades.vn contact@vinades.vn'), 
(8, ' Giảm giá tới 90% giá module, ngày nào cũng là ngày \"mua chung\" trên webnhanh.vn! Như thông báo trên webnhanh.vn, chương trình \"http://webnhanh.vn/vi/thiet-ke-web/detail/Mua-chung-tren-Webnhanhvn-se-giam-gia-90-gia-module-da-cong-bo-245/ mua chung module\" nằm trong chính sách chung của webnhanh.vn trong việc hỗ trợ phát triển mã nguồn mở, giúp cho mọi người được hưởng những dịch vụ thiết kế website tốt nhất với chi phí thấp nhất. Tham gia chương trình này, bạn chỉ phải trả số tiền bằng 1/10 giá trị module mà vẫn được sở hữu module với tính năng hấp dẫn mà bạn mong muốn. Cụ thể, các module trong http://webnhanh.vn/vi/nvresources/cat/Modules-1/ kho module của webnhanh.vn đang chờ hoàn thiện sẽ được giảm giá tới 90% nếu khách hàng đăng ký mua chung module. Tuy nhiên sau 2 tháng thực hiện, Ban Quản Trị webnhanh.vn thấy rằng khả năng xuất hiện nhu cầu cùng mua chung 1 sản phẩm và dịch vụ có tính đặc thù như code dành cho web là rất thấp. Chính vì thế webnhanh.vn đã giảm giá đồng loạt các module trên webnhanh.vn để khách hàng có nhu cầu sẽ có nhiều cơ hội được sử dụng các module mà mình mong muốn cung cấp lên website. Đại đa số các module sẽ được giảm giá xuống mức giá siêu rẻ để đảm bảo mọi người đều có khả năng sử dụng. Đặc biệt với các module có mức giá từ 10-20 triệu đồng sẽ giảm giá xuống còn ở mức 1-5 triệu đồng. Giá rẻ hơn, nhiều giao diện hơn cho web Ngoài việc giảm giá http://webnhanh.vn/vi/nvresources/cat/Giao-dien-3/ các giao diện website do VINADES.,JSC thiết kế (từ mức giá 2 triệu đồng xuống còn 300 đến 700 ngàn đồng). Webnhanh.vn cũng sẽ cải thiện kho giao diện của mình bằng cách đưa vào sử dụng các mẫu giao diện của các nhà thiết kế giao diện khác với giá trung bình khoảng 300 ngàn đồng (chi phí chuyển template thành giao diện có thể cài đặt cho website). Khách hàng cũng có thể gửi mẫu giao diện (đã cắt HTML) để chúng tôi thực hiện việc ghép giao diện với mức giá 300-500 ngàn đồng (áp dụng mô hình giá chia sẻ của VINADES.,JSC trong http://vinades.vn/vi/news/San-pham/Thiet-ke-giao-dien-14/ thiết kế giao diện web (*)). Giảm giá các gói web dựng sẵn, nâng cao chất lượng và cấu hình dịch vụ Cơ cấu chất lượng sản phẩm và dịch vụ cũng thay đổi theo hướng nâng cao rõ rệt. Ngoài việc giảm giá các http://webnhanh.vn/vi/nvresources/package/ gói web dựng sẵn, webnhanh.vn đồng thời nâng cao chất lượng các dịch vụ đi kèm của các gói web này. Theo đó ngoài việc kéo dài thời gian bảo hành miễn phí lên 12 tháng, đồng thời webnhanh.vn cũng kéo dài thời gian sử dụng hosting miễn phí lên 12 tháng. Với mức hỗ trợ này, website thiết kế trên webnhanh.vn đảm bảo chất lượng cao và mức giá còn rẻ hơn cả các nhà cung cấp dịch vụ web giá rẻ. Đây là cơ hội rất lớn cho http://webnhanh.vn/vi/dealers/ các đại lý của webnhanh.vn để tạo nên lợi thế cạnh tranh về chất lượng và giá cả dịch vụ. (*) \"Giá chia sẻ\" là mức giá tiết kiệm cho khách hàng, nếu mua với mức giá này khách hàng sẽ tiết kiệm chi phí thiết kế giao diện một cách tối đa mà vẫn được toàn quyền sử dụng mẫu giao diện đã đặt hàng. Webnhanh.vn sẽ giữ lại mẫu giao diện này và đưa vào thư viện giao diện để cung cấp cho các khách hàng khác. Mô hình \"Giá chia sẻ\" sử dụng cho các khách hàng không quá khắt khe về việc đảm bảo tính duy nhất của mẫu giao diện đồng thời giúp webnhanh.vn làm phong phú thêm kho giao diện của mình.Chú ý: Ngoài việc cung cấp các gói web dựng sẵn với chi phí thấp phục vụ người dùng phổ thông, http://vinades.vn VINADES.,JSC vẫn duy trì dịch vụ thiết kế giao diện riêng và thiết kế website theo yêu cầu để phục vụ những khách hàng có nhu cầu riêng biệt và cao cấp hơn, khách hàng có nhu cầu vui lòng truy cập http://vinades.vn http://vinades.vn hoặc liên hệ nhân viên kinh doanh của VINADES.,JSC để được tư vấn và báo giá dịch vụ. Như vậy, cùng với việc tham gia cung cấp hosting chuyên nghiệp dành cho NukeViet của các nhà cung cấp hosting trong và ngoài nước như http://vinades.vn/vi/news/Doi-tac/VINADES-JSC-va-DIGISTAR-hop-tac-trong-viec-phat-trien-ma-nguon-mo-NukeViet-17/ DIGISTAR, http://nukeviet.vn/vi/news/the-gioi-cong-nghe/TMDHosting-cung-cap-dich-vu-hosting-chuyen-NukeViet-64/ TMDHosting hay http://nukeviet.vn/vi/news/the-gioi-cong-nghe/SiteGround-cung-cap-dich-vu-hosting-chuyen-NukeViet-59/ SiteGround, http://nukeviet.vn/vi/news/the-gioi-cong-nghe/website-dau-tien-thiet-ke-website-va-ban-code-chuyen-nghiep-danh-cho-NukeViet-67/ Webnhanh.vn là website đầu tiên có dịch vụ thiết kế website và bán code chuyên nghiệp dành riêng cho NukeViet. Sự chuyên nghiệp hóa trong các khâu từ phát triển đến cung cấp dịch vụ cho mã nguồn mở NukeViet sẽ mở ra một cơ hội phát triển mới cho người sử dụng web ở Việt Nam.'), 
(9, ' Nhắc đến các hệ thống quản trị nội dung (Content Management System – CMS) để quản lý các cổng thông tin điện tử trên Internet, không ít người sẽ nhắc đến các bộ công cụ như Joomla hay Wordpress. Tuy nhiên, có một sản phẩm hoàn toàn thuần Việt, do người Việt xây dựng không hề thua kém những sản phẩm trên cả về tính năng lẫn khả năng ứng dụng, đó là NukeViet của nhóm tác giả thuộc Công ty Cổ phần phát triển nguồn mở Việt Nam (VINADES). Với NukeViet, người dùng tại Việt Nam sẽ vượt qua các trở ngại về rào cản ngôn ngữ, có thể xây dựng và vận hành các trang web một cách dễ dàng nhất, đồng thời nhận được sự hỗ trợ của cộng đồng người dùng và các nhà phát triển cũng chính là người Việt Nam. Mới đây nhất, Ban giám khảo Giải thưởng Nhân Tài Đất Việt 2011 đã quyết định đưa NukeViet vào danh sách các sản phẩm đã vượt qua vòng sơ khảo để tranh tài tại vòng chung khảo của Giải Thưởng Nhân Tài Đất Việt 2011 diễn ra vào ngày 17-18/11 tới đây. Những ý tưởng giúp hình thành nên sản phẩm “thuần Việt” Theo chia sẻ của đại diện nhóm tác giả, năm 2004, anh Nguyễn Anh Tú, một lưu học sinh người Việt tại Nga với ý tưởng xây dựng một website để kết nối cộng đồng sinh viên du học đã sử dụng bộ CMS mã nguồn mở PHP-Nuke để thực hiện. Sau đó, anh Nguyễn Anh Tú đã phát triển và cải tiến bộ mã nguồn mở PHP-Nuke để chia sẻ cho các thành viên có nhu cầu xây dựng website một cách đơn giản và thuận tiện hơn. Được sự đón nhận của đông đảo người sử dụng, bộ mã nguồn đã liên tục được phát triển và trở thành một ứng dụng thuần Việt với tên gọi NukeViet. NukeViet đã nhanh chóng trở nên phổ biến trong giới các nhà xây dựng và phát triển website tại Việt Nam. http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-1_4b905.jpg Giao diện một website tin tức được xây dựng bằng NukeViet Trong quá trình phát triển NukeViet, có một điều đội ngũ kỹ thuật luôn trăn trở là làm sao để có thể nâng cao tỉ lệ đóng góp của người Việt vào trong mã nguồn sản phẩm. Chính vì ý thức được điều này nên mức độ thuần Việt của sản phẩm ngày càng được nâng cao trong từng phiên bản phát hành. Cho đến phiên bản 3.0 (phát hành tháng 10 năm 2010) thì NukeViet đã thực sự trở thành một sản phẩm mã nguồn mở riêng của Việt Nam với 100% dòng code được viết mới. Kể từ đây, cộng đồng mã nguồn mở Việt Nam đã có riêng một bộ mã nguồn thuần Việt, tự hào sánh bước ngang vai cùng các cộng đồng mã nguồn mở khác trên thế giới. NukeViet ra đời đã giúp cộng đồng mạng Việt Nam giải quyết nhu cầu và mong muốn có một bộ mã nguồn mở của riêng Việt Nam, giúp phát triển hệ thống website của người Việt một cách an toàn nhất, đảm bảo nhất. http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-2_600d0.jpg Một website bán hành trực tuyến xây dựng bằng NukeViet NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp. Khả năng ứng dụng và những ưu điểm của NukeViet Kể từ khi ra đời và trải qua một quá trình dài phát triển, NukeViet hiện được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp. NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block... NukeViet chủ yếu được sử dụng làm trang tin tức nhờ module News tích hợp sẵn trong NukeViet được viết rất công phu, nó lại đặc biệt phù hợp với yêu cầu và đặc điểm sử dụng cho hệ thống tin tức. NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng do đó thường được những đối tượng người dùng không chuyên ưa thích. http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-4_416a1.jpg Website phòng Giáo dục và Đào tạo Lạng Giang được xây dựng trên mã nguồn NukeViet NukeViet có mã nguồn mở do đó việc sử dụng NukeViet là hoàn toàn miễn phí cho tất cả mọi người trên thế giới. Từ phiên bản 2.0 trở về trước, đối tượng người dùng chủ yếu của NukeViet là người Việt vì những đặc điểm của bản thân mã nguồn (có nguồn gốc từ PHP-Nuke) và vì chính sách của nhóm phát triển là: \"hệ thống Portal dành cho người Việt\". Tuy nhiên, kể từ phiên bản 3.0, đội ngũ phát triển NukeViet định hướng đưa NukeViet ra cộng đồng quốc tế với hỗ trợ thêm nhiều ngôn ngữ. Trên thực tế, với những ưu điểm vượt trội của mình, NukeViet 3 đã được ứng dụng ở hàng ngàn website khác nhau. Đặc biệt, không ít các cơ quan, tổ chức của Nhà nước đã tin tưởng sử dụng mã nguồn NukeViet để xây dựng cổng thông tin điện tử của mình, như Cổng thông tin tích hợp 1 cửa cho Phòng giáo dục Lạng Giang, cổng thông tin 2 chiều - Công ty cổ phần đầu tư tài chính công đoàn dầu khí Việt Nam, Hệ thống tra cứu điểm, tra cứu văn bằng - Cổng thông tin Sở GD&ĐT Quảng Ninh, Website viện y học cổ truyền Quân Đội… Tất cả các dự án trên đều được khách hàng đánh giá rất cao về tính ứng dụng, hiệu quả do tiết kiệm chi phí và đáp ứng rất tốt nhu cầu sử dụng của các đơn vị. Hướng phát triển trong tương lai và những kỳ vọng trước mắt Với ý nghĩa là phần mềm quản lý website (chiếm tới 90% các giao tiếp và tương tác trực tiếp với người sử dụng trên môi trường internet), khi phát triển, NukeViet sẽ trở thành một công cụ truyền thông rất mạnh, có thể đem lại những hiệu quả to lớn khác. Nhóm phát triển sẽ phát huy lợi thế này để phát triển sản phẩm. Nhóm phát triển cũng muốn tăng cường các khả năng liên kết, chia sẻ và tích hợp dữ liệu giữa các hệ thống khác nhau nhằm tạo nên một mạng lưới lớn, rộng khắp và hoàn chỉnh, có thể huy động sức mạnh tổng lực, thực hiện các nhiệm vụ xã hội khác trên mã nguồn NukeViet của mình. NukeViet khi được kết hợp với xu thế phát triển của điện toán đám mây sẽ trở thành một nền tảng giúp phát triển nhiều hệ thống dịch vụ trực tuyến có thể thu hút nhiều người dùng với giá trị thương mại cao. http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-3_46e98.jpg Giao diện soạn thảo nội dung trên NukeViet Với việc gửi sản phẩm dự thi tại Giải thưởng Nhân Tài Đất Việt 2011, nhóm tác giả của NukeViet hy vọng mã nguồn mở của mình sẽ đạt vị trí cao tại Giải thưởng, như một cách thức để quảng bá rộng rãi sản phẩm, được thừa nhận và hỗ trợ sử dụng trong các lĩnh vực mà nó có thể phục vụ tốt và đem lại hiệu quả kinh tế, xã hội cao như: lĩnh vực giáo dục, lĩnh vực hành chính… để các bộ-ban-ngành, các cơ quan hành chính, chính quyền địa phương nhìn thấy giá trị và hiệu quả to lớn của mã nguồn mở NukeViet để triển khai NukeViet phục vụ các cơ quan này. NukeViet sẽ giúp hiện thực hóa cải cách hành chính và góp phần đẩy nhanh thủ tục một cửa một cách tiết kiệm mà vẫn đạt hiệu quả cao nhất. Ngoài ra, uy tính của Giải thưởng, nhóm tác giả NukeViet hy vọng sẽ đem NukeViet đến nhiều người hơn, để cả xã hội được sử dụng thành quả lớn lao của bộ mã nguồn mở được coi là biểu tượng và đại diện tiểu biểu cho sự phát triển và thành công của mã nguồn mở Việt Nam. Không chỉ thế, mở ra cơ hội tiếp cận và học hỏi công nghệ cho hàng ngàn học sinh, sinh viên, qua đó có được các kiến thức đầy đủ về công nghệ web, về internet và vô số các kỹ năng làm việc trên máy tính khác mà có thể do vô tình hay cố ý, trong quá trình tìm hiểu, học tập và vận hành NukeViet mà họ đã có được. Với những ứng dụng rộng rãi mà NukeViet đã có được kể từ khi ra mắt và và trải qua thời gian dài phát triển, Hội đồng Giám khảo Giải Thưởng Nhân Tài Đất Việt đã đánh giá rất cao những ưu điểm và thế mạnh của NukeViet để đưa sản phẩm vào danh sách 17 sản phẩm sẽ tranh tài tại vòng Chung khảo của Giải Thưởng Nhân Tài Đất Việt 2011 diễn ra vào ngày 17-18/11 tới đây. Bạn đọc có thể tìm hiểu thêm về NukeViet tại http://nukeviet.vn/vi/news/Bao-chi-viet/ http://nukeviet.vn/.'), 
(10, 'Cả hội trường như vỡ òa, rộn tiếng vỗ tay, tiếng cười nói chúc mừng các nhà khoa học, các nhóm tác giả đoạt Giải thưởng Nhân tài Đất Việt năm 2011. Năm thứ 7 liên tiếp, Giải thưởng đã phát hiện và tôn vinh nhiều tài năng của đất nước. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/01_b7d3f.jpg Sân khấu trước lễ trao giải. Cơ cấu Giải thưởng của Nhân tài Đất Việt 2011 trong lĩnh vực CNTT bao gồm 2 hệ thống giải dành cho “Sản phẩm có tiềm năng ứng dụng” và “Sản phẩm đã ứng dụng rộng rãi trong thực tế”. Mỗi hệ thống giải sẽ có 1 giải Nhất, 1 giải Nhì và 1 giải Ba với trị giá giải thưởng tương đương là 100 triệu đồng, 50 triệu đồng và 30 triệu đồng cùng phần thưởng của các đơn vị tài trợ. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/03_f19bd.jpg Nhiều tác giả, nhóm tác giả đến lễ trao giải từ rất sớm. Giải thưởng Nhân tài Đất Việt 2011 trong lĩnh vực Khoa học Tự nhiên được gọi chính thức là Giải thưởng Khoa học Tự nhiên Việt Nam sẽ có tối đa 6 giải, trị giá 100 triệu đồng/giải dành cho các lĩnh vực: Toán học, Cơ học, Vật lý, Hoá học, Các khoa học về sự sống, Các khoa học về trái đất (gồm cả biển) và môi trường, và các lĩnh vực khoa học liên ngành hoặc đa ngành của hai hoặc nhiều ngành nói trên. Viện Khoa học và Công nghệ Việt Nam thành lập Hội đồng giám khảo gồm các nhà khoa học tự nhiên hàng đầu trong nước để thực hiện việc đánh giá và trao giải. Sau thành công của việc trao Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y dược năm 2010, Ban Tổ chức tiếp tục tìm kiếm những chủ nhân xứng đáng cho Giải thưởng này trong năm 2011. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/07_78b85.jpg Nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam Lê Khả Phiêu tới dự Lễ trao giải. 45 phút trước lễ trao giải, không khí tại Cung Văn hóa Hữu nghị Việt - Xô đã trở nên nhộn nhịp. Sảnh phía trước Cung gần như chật kín. Rất đông bạn trẻ yêu thích công nghệ thông tin, sinh viên các trường đại học đã đổ về đây, cùng với đó là những bó hoa tươi tắn sẽ được dành cho các tác giả, nhóm tác giả đoạt giải. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/09_aef87.jpg Phó Chủ tịch nước CHXHCN Việt Nam Nguyễn Thị Doan. Các vị khách quý cũng đến từ rất sớm. Tới tham dự lễ trao giải năm nay có ông Lê Khả Phiêu, nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam; bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCN Việt Nam; ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam; ông Nguyễn Bắc Son, Bộ trưởng Bộ Thông tin và Truyền thông; ông Đặng Ngọc Tùng, Chủ tịch Tổng Liên đoàn lao động Việt Nam; ông Phạm Văn Linh, Phó trưởng ban Tuyên giáo Trung ương; ông Đỗ Trung Tá, Phái viên của Thủ tướng Chính phủ về CNTT, Chủ tịch Hội đồng Khoa học công nghệ quốc gia; ông Nguyễn Quốc Triệu, nguyên Bộ trưởng Bộ Y tế, Trưởng Ban Bảo vệ Sức khỏe TƯ; bà Cù Thị Hậu, Chủ tịch Hội người cao tuổi Việt Nam; ông Lê Doãn Hợp, nguyên Bộ trưởng Bộ Thông tin Truyền thông, Chủ tịch Hội thông tin truyền thông số… http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/08_ba46c.jpg Bộ trưởng Bộ Thông tin và Truyền thông Nguyễn Bắc Son. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/06_29592.jpg Giáo sư - Viện sỹ Nguyễn Văn Hiệu. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/04_051f2.jpg Nguyên Bộ trưởng Bộ Y tế Nguyễn Quốc Triệu. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/05_c7ea4.jpg Ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam. Do tuổi cao, sức yếu hoặc bận công tác không đến tham dự lễ trao giải nhưng Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang cũng gửi lẵng hoa đến chúc mừng lễ trao giải. Đúng 20h, Lễ trao giải bắt đầu với bài hát “Nhân tài Đất Việt” do ca sỹ Thái Thùy Linh cùng ca sĩ nhí và nhóm múa biểu diễn. Các nhóm tác giả tham dự Giải thưởng năm 2011 và những tác giả của các năm trước từ từ bước ra sân khấu trong tiếng vỗ tay tán dương của khán giả. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/12_74abf.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN15999_3e629.jpg Tiết mục mở màn Lễ trao giải. Trước Lễ trao giải Giải thưởng Nhân tài Đất Việt năm 2011, Đại tướng Võ Nguyên Giáp, Chủ tịch danh dự Hội Khuyến học Việt Nam, đã gửi thư chúc mừng, khích lệ Ban tổ chức Giải thưởng cũng như các nhà khoa học, các tác giả tham dự. Hà Nội, ngày 16 tháng 11 năm 2011 Giải thưởng “Nhân tài đất Việt” do Hội Khuyến học Việt Nam khởi xướng đã bước vào năm thứ bảy (2005 - 2011) với ba lĩnh vực: Công nghệ thông tin, Khoa học tự nhiên và Y dược. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/thuDaituong1_767f4.jpg Thư của Đại tướng Võ Nguyên Giáp gửi BTC Giải thưởng Nhân tài đất Việt. Tôi gửi lời chúc mừng các nhà khoa học và các thí sinh được nhận giải thưởng “Nhân tài đất Việt” năm nay. Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực. Nhân ngày “Nhà giáo Việt Nam”, chúc Hội Khuyến học Việt nam, chúc các thầy giáo và cô giáo, với tâm huyết và trí tuệ của mình, sẽ đóng góp xứng đáng vào công cuộc đổi mới căn bản và toàn diện nền giáo dục nước nhà, để cho nền giáo dục Việt Nam thực sự là cội nguồn của nguyên khí quốc gia, đảm bảo cho mọi nhân cách và tài năng đất Việt được vun đắp và phát huy vì sự trường tồn, sự phát triển tiến bộ và bền vững của đất nước trong thời đại toàn cầu hóa và hội nhập quốc tế. Chào thân ái, Chủ tịch danh dự Hội Khuyến học Việt Nam Đại tướng Võ Nguyên Giáp Phát biểu khai mạc Lễ trao giải, Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng Ban tổ chức, bày tỏ lời cám ơn chân thành về những tình cảm cao đẹp và sự quan tâm chăm sóc của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang đã và đang dành cho Nhân tài Đất Việt. Nhà báo Phạm Huy Hoàn nhấn mạnh, Giải thưởng Nhân tài Đất Việt suốt 7 năm qua đều nhận được sự quan tâm của các vị lãnh đạo Đảng, Nhà nước và của toàn xã hội. Tại Lễ trao giải, Ban tổ chức luôn có vinh dự được đón tiếp các vị lãnh đạo Đảng và Nhà nước đến dự và trực tiếp trao Giải thưởng. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/15_4670c.jpg Trưởng Ban tổ chức Phạm Huy Hoàn phát biểu khai mạc buổi lễ. Năm 2011, Giải thưởng có 3 lĩnh vực được xét trao giải là CNTT, Khoa học tự nhiên và Y dược. Lĩnh vực CNTT đã đón nhận 204 sản phẩm tham dự từ mọi miền đất nước và cả nước ngoài như thí sinh Nguyễn Thái Bình từ bang California - Hoa Kỳ và một thí sinh ở Pháp cũng đăng ký tham gia. “Cùng với lĩnh vực CNTT, năm nay, Hội đồng khoa học của Viện khoa học và công nghệ Việt Nam và Hội đồng khoa học - Bộ Y tế tiếp tục giới thiệu những nhà khoa học xuất sắc, có công trình nghiên cứu đem lại nhiều lợi ích cho xã hội trong lĩnh vực khoa học tự nhiên và lĩnh vực y dược. Đó là những bác sĩ tài năng, những nhà khoa học mẫn tuệ, những người đang ngày đêm thầm lặng cống hiến trí tuệ sáng tạo của mình cho xã hội trong công cuộc xây dựng đất nước.” - nhà báo Phạm Huy Hoàn nói. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/14_6e18f.jpg Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng BTC Giải thưởng và ông Phan Hoàng Đức, Phó TGĐ Tập đoàn VNPT nhận lẵng hoa chúc mừng của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang. Cũng theo Trưởng Ban tổ chức Phạm Huy Hoàn, đến nay, vị Chủ tịch danh dự đầu tiên của Hội Khuyến học Việt Nam, Đại tướng Võ Nguyên Giáp, đã bước qua tuổi 100 nhưng vẫn luôn dõi theo và động viên từng bước phát triển của Giải thưởng Nhân tài Đất Việt. Đại tướng luôn quan tâm chăm sóc Giải thưởng ngay từ khi Giải thưởng mới ra đời cách đây 7 năm. Trước lễ trao giải, Đại tướng Võ Nguyên Giáp đã gửi thư chúc mừng, động viên Ban tổ chức. Trong thư, Đại tướng viết: “Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực. Sau phần khai mạc, cả hội trường hồi hội chờ đợi phút vinh danh các nhà khoa học và các tác giả, nhóm tác giả đoạt giải. * Giải thưởng Khoa học Tự nhiên Việt Nam thuộc về 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ - Viện Vật lý, Viện Khoa học công nghệ Việt Nam với công trình “Nghiên cứu cấu trúc hạt nhân và các phản ứng hạt nhân”. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn_d4aae.jpg Hai nhà khoa học đã tiến hành thành công các nghiên cứu về phản ứng hạt nhân với nơtron, phản ứng quang hạt nhân, quang phân hạch và các phản ứng hạt nhân khác có cơ chế phức tạp trên các máy gia tốc như máy phát nơtron, Microtron và các máy gia tốc thẳng của Việt Nam và Quốc tế. Các nghiên cứu này đã góp phần làm sáng tỏ cấu trúc hạt nhân và cơ chế phản ứng hạt nhân, đồng thời cung cấp nhiều số liệu hạt nhân mới có giá trị cho Kho tàng số liệu hạt nhân. GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ đã khai thác hiệu quả hai máy gia tốc đầu tiên của Việt Nam là máy phát nơtron NA-3-C và Microtron MT-17 trong nghiên cứu cơ bản, nghiên cứu ứng dụng và đào tạo nhân lực. Trên cơ sở các thiết bị này, hai nhà khoa học đã tiến hành thành công những nghiên cứu cơ bản thực nghiệm đầu tiên về phản ứng hạt nhân ở Việt Nam; nghiên cứu và phát triển các phương pháp phân tích hạt nhân hiện đại và áp dụng thành công ở Việt Nam. Bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCNVN và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn2_e2865.jpg Phó Chủ tịch nước CHXHCNVN Nguyễn Thị Doan và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ. GS.VS Nguyễn Văn Hiệu chia sẻ: “Cách đây không lâu, Chính phủ đã ký quyết định xây dựng nhà máy điện hạt nhân trong điều kiện đất nước còn nhỏ bé, nghèo khó và vì thế việc đào tạo nhân lực là nhiệm vụ số 1 hiện nay. Rất may, Việt Nam có 2 nhà khoa học cực kỳ tâm huyết và nổi tiếng trong cả nước cũng như trên thế giới. Hội đồng khoa học chúng tôi muốn xướng tên 2 nhà khoa học này để Chính phủ huy động cùng phát triển xây dựng nhà máy điện hạt nhân.” GS.VS Hiệu nhấn mạnh, mặc dù điều kiện làm việc của 2 nhà khoa học không được quan tâm, làm việc trên những máy móc cũ kỹ được mua từ năm 1992 nhưng 2 ông vẫn xay mê cống hiến hết mình cho lĩnh Khoa học tự nhiên Việt Nam. * Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y Dược: 2 giải 1. Nhóm nghiên cứu của Bệnh viện Hữu nghị Việt - Đức với công trình “Nghiên cứu triển khai ghép gan, thận, tim lấy từ người cho chết não”. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y_3dca2.jpg Tại bệnh viện Việt Đức, tháng 4/2011, các ca ghép tạng từ nguồn cho là người bệnh chết não được triển khai liên tục. Với 4 người cho chết não hiến tạng, bệnh viện đã ghép tim cho một trường hợp, 2 người được ghép gan, 8 người được ghép thận, 2 người được ghép van tim và tất cả các ca ghép này đều thành công, người bệnh được ghép đã có một cuộc sống tốt hơn với tình trạng sức khỏe ổn định. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y2_cb5a1.jpg Nguyên Tổng Bí Ban chấp hành TW Đảng CSVN Lê Khả Phiêu và ông Vũ Văn Tiền, Chủ tịch Hội đồng quản trị Ngân hàng An Bình trao giải thưởng cho nhóm nghiên cứu của BV Hữu nghị Việt - Đức. Công trong việc ghép tạng từ người cho chết não không chỉ thể hiện năng lực, trình độ, tay nghề của bác sĩ Việt Nam mà nó còn mang một ý nghĩa nhân văn to lớn, mang một thông điệp gửi đến những con người giàu lòng nhân ái với nghĩa cử cao đẹp đã hiến tạng để cứu sống những người bệnh khác. 2. Hội đồng ghép tim Bệnh viện Trung ương Huế với công trình nghiên cứu “Triển khai ghép tim trên người lấy từ người cho chết não”. Đề tài được thực hiện dựa trên ca mổ ghép tim thành công lần đầu tiên ở Việt Nam của chính 100% đội ngũ y, bác sĩ của Bệnh viện Trung ương Huế đầu tháng 3/2011. Bệnh nhân được ghép tim thành công là anh Trần Mậu Đức (26 tuổi, ở phường Phú Hội, TP. Huế). http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y3_7768c.jpg Hội đồng ghép tim BV Trung ương Huế nhận Giải thưởng Nhân tài Đất Việt. Ghép tim từ người cho chết não đến người bị bệnh tim cần được ghép tim phải đảm bảo các yêu cầu: đánh giá chức năng các cơ quan; đánh giá tương hợp miễn dịch và phát hiện nguy cơ tiềm ẩn có thể xảy ra trong và sau khi ghép tim để từ đó có phương thức điều trị thích hợp. Có tới 30 xét nghiệm cận lâm sàng trung và cao cấp tiến hành cho cả người cho tim chết não và người sẽ nhận ghép tim tại hệ thống labo của bệnh viện. --------------------- * Giải thưởng Nhân tài đất Việt Lĩnh vực Công nghệ thông tin. Hệ thống sản phẩm đã ứng dụng thực tế: Giải Nhất: Không có. Giải Nhì: Không có Giải Ba: 3 giải, mỗi giải trị giá 30 triệu đồng. 1. “Bộ cạc xử lý tín hiệu HDTV” của nhóm HD Việt Nam. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/hdtv_13b10.jpg Nhóm HDTV Việt Nam lên nhận giải. Đây là bộ cạc xử lý tín hiệu HDTV đầu tiên tại Việt Nam đạt tiêu chuẩn OpenGear. Bộ thiết bị bao gồm 2 sản phẩm là cạc khuếch đại phân chia tín hiệu HD DA và cạc xử lý tín hiệu HD FX1. Nhờ bộ cạc này mà người sử dụng cũng có thể điều chỉnh mức âm thanh hoặc video để tín hiệu của kênh tuân theo mức chuẩn và không phụ thuộc vào chương trình đầu vào. 2. “Mã nguồn mở NukeViet” của nhóm tác giả Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC). /nuke342/uploads/news/nukeviet-nhantaidatviet2011.jpg NukeViet nhận giải ba Nhân tài đất Việt 2011 NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp. 3. “Hệ thống ngôi nhà thông minh homeON” của nhóm Smart home group. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16132_82014.jpg Sản phẩm là kết quả từ những nghiên cứu miệt mài nhằm xây dựng một ngôi nhà thông minh, một cuộc sống xanh với tiêu chí: An toàn, tiện nghi, sang trọng và tiết kiệm năng lượng, hưởng ứng lời kêu gọi tiết kiệm năng lượng của Chính phủ. * Hệ thống sản phẩm có tiềm năng ứng dụng: Giải Nhất: Không có. Giải Nhì: trị giá 50 triệu đồng: “Dịch vụ Thông tin và Tri thức du lịch ứng dụng cộng nghệ ngữ nghĩa - iCompanion” của nhóm tác giả SIG. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/nhi_7eee0.jpg Nhóm tác giả SIG nhận giải Nhì Nhân tài đất Việt 2011 ở hệ thống sản phẩm có tiềm năng ứng dụng. ICompanion là hệ thống thông tin đầu tiên ứng dụng công nghệ ngữ nghĩa trong lĩnh vực du lịch - với đặc thù khác biệt là cung cấp các dịch vụ tìm kiếm, gợi ý thông tin “thông minh” hơn, hướng người dùng và kết hợp khai thác các tính năng hiện đại của môi trường di động. Đại diện nhóm SIG chia sẻ: “Tinh thần sáng tạo và lòng khát khao muốn được tạo ra các sản phẩm mới có khả năng ứng dụng cao trong thực tiễn luôn có trong lòng của những người trẻ Việt Nam. Cảm ơn ban tổ chức và những nhà tài trợ đã giúp chúng tôi có một sân chơi thú vị để khuyến khích và chắp cánh thực hiện ước mơ của mình. Xin cảm ơn trường ĐH Bách Khoa đã tạo ra một môi trường nghiên cứu và sáng tạo, gắn kết 5 thành viên trong nhóm.” Giải Ba: 2 giải, mỗi giải trị giá 30 triệu đồng. 1. “Bộ điều khiển IPNET” của nhóm IPNET http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16149_ed58d.jpg Nhà báo Phạm Huy Hoàn, Trưởng Ban Tổ chức Giải thưởng NTĐV, Tổng Biên tập báo điện tử Dân trí và ông Tạ Hữu Thanh - Phó TGĐ Jetstar Pacific trao giải cho nhóm IPNET. Bằng cách sử dụng kiến thức thiên văn học để tính giờ mặt trời lặn và mọc tại vị trí cần chiếu sáng được sáng định bởi kinh độ, vĩ độ cao độ, hàng ngày sản phẩm sẽ tính lại thời gian cần bật/tắt đèn cho phù hợp với giờ mặt trời lặn/mọc. 2. “Hệ thống lập kế hoạch xạ trị ung thư quản lý thông tin bệnh nhân trên web - LYNX” của nhóm LYNX. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/3tiem-nang_32fee.jpg Đây là loại phần mềm hoàn toàn mới ở Việt Nam, là hệ thống lập kế hoạch và quản lý thông tin của bệnh nhân ung thư qua Internet (LYNX) dựa vào nền tảng Silverlight của Microsoft và kiến thức chuyên ngành Vật lý y học. LYNX giúp ích cho các nhà khoa học, bác sĩ, kỹ sư vật lý, bệnh nhân và mọi thành viên trong việc quản lý và theo dõi hệ thống xạ trị ung thư một cách tổng thể. LYNX có thể được sử dụng thông qua các thiết bị như máy tính cá nhân, máy tính bảng… và các trình duyệt Internet Explorer, Firefox, Chrome… Chương trình trao giải đã được truyền hình trực tiếp trên VTV2 - Đài Truyền hình Việt Nam và tường thuật trực tuyến trên báo điện tử Dân trí từ 20h tối 20/11/2011. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0545_c898e.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0560_c995c.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16199_36a5c.jpg Khởi xướng từ năm 2005, Giải thưởng Nhân tài Đất Việt đã phát hiện và tôn vinh nhiều tài năng trong lĩnh vực CNTT-TT, Khoa học tự nhiên và Y dược, trở thành một sân chơi bổ ích cho những người yêu thích CNTT. Mỗi năm, Giải thưởng ngày càng thu hút số lượng tác giả và sản phẩm tham gia đông đảo và nhận được sự quan tâm sâu sắc của lãnh đạo Đảng, Nhà nước cũng như công chúng. Đối tượng tham gia Giải thưởng trong lĩnh vực CNTT là những người Việt Nam ở mọi lứa tuổi, đang sinh sống trong cũng như ngoài nước. Năm 2006, Giải thưởng có sự tham gia của thí sinh đến từ 8 nước trên thế giới và 40 tỉnh thành của Việt Nam. Từ năm 2009, Giải thưởng được mở rộng sang lĩnh vực Khoa học tự nhiên, và năm 2010 là lĩnh vực Y dược, vinh danh những nhà khoa học trong các lĩnh vực này. ');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_cat`
--

DROP TABLE IF EXISTS `vt_vi_news_cat`;
CREATE TABLE `vt_vi_news_cat` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `titlesite` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `thumbnail` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=16  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_cat`
--

INSERT INTO `vt_vi_news_cat` VALUES
(1, 0, 'Tin tức du lịch', '', 'Tin-tuc-du-lich', '', '', '', 1, 1, 0, 'viewcat_page_new', 3, '8,12,9', 1, 4, '', '', 1274986690, 1418199330, 0, ''), 
(8, 1, 'Thông cáo báo chí', '', 'thong-cao-bao-chi', '', '', '', 1, 2, 1, 'viewcat_page_new', 0, '', 1, 4, '', '', 1274987105, 1274987244, 0, ''), 
(9, 1, 'Tin công nghệ', '', 'Tin-cong-nghe', '', '', '', 3, 4, 1, 'viewcat_page_new', 0, '', 1, 4, '', '', 1274987212, 1274987212, 0, ''), 
(10, 0, 'Dịch vụ xe du lịch', '', 'Dich-vu-xe-du-lich', '', '', '', 2, 5, 0, 'viewcat_grid_new', 3, '13,14,15', 1, 4, '', '', 1274987460, 1418199351, 0, ''), 
(12, 1, 'Bản tin nội bộ', '', 'Ban-tin-noi-bo', '', '', '', 2, 3, 1, 'viewcat_page_new', 0, '', 1, 4, '', '', 1274987902, 1274987902, 0, ''), 
(13, 10, 'XE 12 - 16 CHỖ', '', 'XE-12-16-CHO', '', '', '', 1, 6, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1353230549, 1353230549, 0, ''), 
(14, 10, 'XE 24 - 30 CHỖ', '', 'XE-24-30-CHO', '', '', '', 2, 7, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1353230560, 1353230560, 0, ''), 
(15, 10, 'XE 35 - 45 CHỖ', '', 'XE-35-45-CHO', '', '', '', 3, 8, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1353230574, 1353230574, 0, '');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_comments`
--

DROP TABLE IF EXISTS `vt_vi_news_comments`;
CREATE TABLE `vt_vi_news_comments` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `post_time` (`post_time`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_config_post`
--

DROP TABLE IF EXISTS `vt_vi_news_config_post`;
CREATE TABLE `vt_vi_news_config_post` (
  `pid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `member` tinyint(4) NOT NULL,
  `group_id` mediumint(9) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `member` (`member`,`group_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_config_post`
--

INSERT INTO `vt_vi_news_config_post` VALUES
(1, 0, 0, 0, 0, 0, 0), 
(2, 1, 0, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_rows`
--

DROP TABLE IF EXISTS `vt_vi_news_rows`;
CREATE TABLE `vt_vi_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_rows`
--

INSERT INTO `vt_vi_news_rows` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 'thumb/nangly.jpg|block/nangly.jpg', 1, 2, 1, 5, 0, 0, 0, 'nguồn mở, quen thuộc, cộng đồng, việt nam, hoạt động, gần đây, phổ biến, áp dụng, hầu hết, hết các, lĩnh vực, tin tức, thương mại điện, điện tử, cá nhân, hệ thống'), 
(2, 1, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', 'nukeviet3.jpg', 'NukeViet 3.0', 'thumb/nukeviet3.jpg|block/nukeviet3.jpg', 1, 2, 1, 5, 0, 0, 0, 'nền tảng, xây dựng, hoàn toàn, với những, công nghệ, tiên tiến, hiện nay, hứa hẹn, cách mạng, nguồn mở, việt nam, món quà, cảm ơn, chân thành, thành nhất, cộng đồng'), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 'thumb/hoptac.jpg|block/hoptac.jpg', 1, 2, 1, 6, 0, 0, 0, 'hiện tại, tiến hành, phát triển, phiên bản, thế hệ, hoàn toàn, tính năng, ưu việt, kinh phí, thiện chí, hợp tác, trân trọng, mời hợp tác, đối tác, các công ty, công ty, cung cấp, tên miền, các doanh, doanh nghiệp, quan tâm'), 
(8, 10, '9,10,13,14,15', 0, 1, 'laser', 3, 1310067949, 1353230671, 1, 1310067949, 0, 2, 'Webnhanh.vn - website dịch vụ chuyên nghiệp cho NukeViet chính thức ra mắt', 'Webnhanhvn-website-dich-vu-chuyen-nghiep-cho-NukeViet-chinh-thuc-ra-mat', 'Sau một thời gian đi vào hoạt động, Webnhanh.vn đã nhận được nhiều ủng hộ cùng sự quan tâm, góp ý của cộng đồng và khách hàng. Để đáp ứng mong mỏi của cộng đồng về một dịch vụ web chuyên nghiệp với mức giá tối thiểu, Webnhanh.vn đã thực hiện chiến dịch siêu khuyến mại Giảm giá tất cả các gói web dựng sẵn, module, block và giao diện (theme). Mức giảm giá cao nhất tới 90% giá so với trước tháng 7 năm 2011.', 'webnhanh-vn.jpg', '', 'thumb/webnhanh-vn.jpg|block/webnhanh-vn.jpg', 1, 2, 1, 2, 0, 0, 0, 'khai trương, khuyến mại, giảm giá, siêu khuyến mại, webnhanh, thiết kế website, giao diện web, thiết kế web'), 
(9, 8, '1,8', 0, 1, 'Phạm Thế Quang Huy', 4, 1322685396, 1418137360, 1, 1322685396, 0, 2, 'NukeViet - Công cụ mã nguồn mở cho cộng đồng thiết kế website Việt Nam', 'NukeViet-Cong-cu-ma-nguon-mo-cho-cong-dong-thiet-ke-website-Viet-Nam', '(Dân trí) - Là một trong những hệ quản trị nội dung nổi tiếng hàng đầu tại Việt Nam, NukeViet đã được áp dụng rộng rãi trong việc xây dựng nhiều trang báo điện tử và các cổng thông tin điện tử nổi tiếng tại Việt Nam. Mới đây nhất, NukeViet đã vượt qua vòng sơ khảo để tranh tài tại vòng chung khảo của Giải Thưởng Nhân Tài Đất Việt 2011', 'product_box.jpg', 'Sản phẩm dự thi Nhân tài Đất Việt 2011&#x3A; Mã nguồn mở NukeViet', 'thumb/product_box.jpg|block/product_box.jpg', 1, 2, 1, 3, 0, 0, 0, 'Nhân tài Đất Việt 2011, mã nguồn mở'), 
(10, 8, '1,8', 0, 1, '', 4, 1322685920, 1418222681, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'thumb/nukeviet-nhantaidatviet2011.jpg|block/nukeviet-nhantaidatviet2011.jpg', 1, 2, 1, 7, 0, 0, 0, 'Nhân tài đất Việt 2011, mã nguồn mở');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_sources`
--

DROP TABLE IF EXISTS `vt_vi_news_sources`;
CREATE TABLE `vt_vi_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_sources`
--

INSERT INTO `vt_vi_news_sources` VALUES
(1, 'Báo Hà Nội Mới', 'http://hanoimoi.com.vn', '', 1, 1274989177, 1274989177), 
(2, 'VINADES.,JSC', 'http://vinades.vn', '', 2, 1274989787, 1274989787), 
(3, 'NukeViet', 'http://nukeviet.vn', '', 2, 1274989787, 1274989787), 
(4, 'Báo điện tử Dân Trí', 'http://dantri.com.vn', '', 3, 1322685396, 1322685396);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_news_topics`
--

DROP TABLE IF EXISTS `vt_vi_news_topics`;
CREATE TABLE `vt_vi_news_topics` (
  `topicid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_news_topics`
--

INSERT INTO `vt_vi_news_topics` VALUES
(1, 'NukeViet 3', 'NukeViet-3', '', '', 'NukeViet 3', 1, 'NukeViet 3', 1274990212, 1274990212);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_popup`
--

DROP TABLE IF EXISTS `vt_vi_popup`;
CREATE TABLE `vt_vi_popup` (
  `config_name` varchar(30) NOT NULL,
  `config_value` mediumtext NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_popup`
--

INSERT INTO `vt_vi_popup` VALUES
('active', '1'), 
('timer_open', '1'), 
('timer_close', '0'), 
('popup_content', 'Popup content...');


-- ---------------------------------------


--
-- Table structure for table `vt_vi_referer_stats`
--

DROP TABLE IF EXISTS `vt_vi_referer_stats`;
CREATE TABLE `vt_vi_referer_stats` (
  `host` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_referer_stats`
--

INSERT INTO `vt_vi_referer_stats` VALUES
('l.facebook.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1418389596);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_searchkeys`
--

DROP TABLE IF EXISTS `vt_vi_searchkeys`;
CREATE TABLE `vt_vi_searchkeys` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `keys` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50) NOT NULL,
  KEY `id` (`id`),
  KEY `keys` (`keys`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `vt_vi_silide_silide`
--

DROP TABLE IF EXISTS `vt_vi_silide_silide`;
CREATE TABLE `vt_vi_silide_silide` (
  `id` int(220) NOT NULL AUTO_INCREMENT,
  `name` varchar(220) NOT NULL,
  `link` varchar(220) NOT NULL,
  `url` varchar(220) NOT NULL,
  `sapxep` int(20) NOT NULL,
  `khoa` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_silide_silide`
--

INSERT INTO `vt_vi_silide_silide` VALUES
(1, 'Banner1', 'banner.jpg', '', 1, 1), 
(2, 'Banner2', 'du-lich-tet-2015-dd97d284d1.jpg', '', 2, 1), 
(3, 'Banner3', 'du-lich-tet-duong-lich-2015-16657f3fe0.png', '', 3, 1), 
(4, 'Banner4', 'thue-xe-du-lich-tet1-43efc4f6c7.jpg', '', 4, 1);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_voting`
--

DROP TABLE IF EXISTS `vt_vi_voting`;
CREATE TABLE `vt_vi_voting` (
  `vid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL DEFAULT '',
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL,
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_voting`
--

INSERT INTO `vt_vi_voting` VALUES
(2, 'Bạn biết gì về NukeViet 3?', '', 1, 1, 0, '0', 1275318563, 0, 1), 
(3, 'Bạn quan tâm gì nhất ở mã nguồn mở?', '', 1, 1, 0, '0', 1275318589, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `vt_vi_voting_rows`
--

DROP TABLE IF EXISTS `vt_vi_voting_rows`;
CREATE TABLE `vt_vi_voting_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vt_vi_voting_rows`
--

INSERT INTO `vt_vi_voting_rows` VALUES
(5, 2, 'Một bộ sourcecode cho web hoàn toàn mới.', '', 0), 
(6, 2, 'Mã nguồn mở, sử dụng miễn phí.', '', 0), 
(7, 2, 'Sử dụng xHTML, CSS và hỗ trợ Ajax', '', 0), 
(8, 2, 'Tất cả các ý kiến trên', '', 0), 
(9, 3, 'Liên tục được cải tiến, sửa đổi bởi cả thế giới.', '', 0), 
(10, 3, 'Được sử dụng miễn phí không mất tiền.', '', 0), 
(11, 3, 'Được tự do khám phá, sửa đổi theo ý thích.', '', 0), 
(12, 3, 'Phù hợp để học tập, nghiên cứu vì được tự do sửa đổi theo ý thích.', '', 0), 
(13, 3, 'Tất cả các ý kiến trên', '', 0);